package my.example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ExampleServlet extends HttpServlet
{
    
    private static final long serialVersionUID = 1L;
    
    private int count = 0;
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    protected void doPost( HttpServletRequest req, HttpServletResponse resp )
    throws ServletException, IOException
    {

        doGet( req, resp );
        
    }
    

    /**
     * {@inheritDoc}
     */
    @Override
    protected void doGet( HttpServletRequest req, HttpServletResponse resp )
    throws ServletException, IOException
    {
    	    	
        req.getSession().setAttribute( "my.attribute", ++count );
        
        resp.getWriter().append( "<H3>OPERATION PERFORMED.</H3>" );
        resp.getWriter().append( "<H3>TAKE A LOOK AT THE CATALINA.OUT LOG FILE.</H3>" );
        
    }

}
