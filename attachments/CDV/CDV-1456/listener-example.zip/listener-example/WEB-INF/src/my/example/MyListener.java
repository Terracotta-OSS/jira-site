package my.example;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class MyListener implements HttpSessionListener,
								   HttpSessionBindingListener,
								   HttpSessionAttributeListener 
{

	@Override
	public void sessionCreated( HttpSessionEvent se )
	{
		
		System.out.println( " SESSION CREATED ::  " + se.getSession() );
		
	}

	@Override
	public void sessionDestroyed( HttpSessionEvent se )
	{
		
		System.out.println( " SESSION DESTROYED ::  " + se.getSession() );
		
	}

	@Override
	public void valueBound( HttpSessionBindingEvent se )
	{
		
		System.out.println( " VALUE BOUND ::  " + se.getName() + "=" + se.getValue() );
		
	}

	@Override
	public void valueUnbound( HttpSessionBindingEvent se )
	{
		
		System.out.println( " VALUE UNBOUND ::  " + se.getName() + "=" + se.getValue() );
		
	}

	@Override
	public void attributeAdded( HttpSessionBindingEvent se )
	{
		
		System.out.println( " ATTRIBUTE ADDED ::  " + se.getName() + "=" + se.getValue() );
		
	}

	@Override
	public void attributeRemoved( HttpSessionBindingEvent se )
	{
		
		System.out.println( " ATTRIBUTE REMOVED ::  " + se.getName() + "=" + se.getValue() );
		
	}

	@Override
	public void attributeReplaced( HttpSessionBindingEvent se )
	{
		
		System.out.println( " ATTRIBUTE REPLACED ::  " + se.getName() + "=" + se.getValue() );
		
	}

	
}
