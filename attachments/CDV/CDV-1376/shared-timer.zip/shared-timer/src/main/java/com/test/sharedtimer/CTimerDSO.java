/*
 * @(#)$RCSfile: CTimerDSO.java,v $ $Revision: 1.1 $ $Date: 2009/08/17 09:59:04 $ $Author: banton $ 
 * $Source: /usr/local/cvsroot/projects_src/components/accesspoint/webservice/src/main/java/hireright/applications/accesspoint/util/CTimerDSO.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CTimerDSO.java,v $
 *     Revision 1.1  2009/08/17 09:59:04  banton
 *     First Access Service with inmemory stored EntryPoint
 *
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.test.sharedtimer;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.terracotta.modules.annotations.AutolockRead;
import org.terracotta.modules.annotations.AutolockWrite;
import org.terracotta.modules.annotations.HonorTransient;
import org.terracotta.modules.annotations.InstrumentedClass;


/**
 * �������������� ������ ������� ��� ��������� ����������� �������� ���������� ��������.
 * ������ � ������������ (�.�. ����������� ����� ���������!)
 *
 * @author banton
 */
@InstrumentedClass
@HonorTransient
public class CTimerDSO
{
    /** stopping flag */
    boolean m_stopped = false;
    /** timeout value */
    long m_timeout;

    long tokenOwner = -1;

    transient Thread m_releaseThread=null;

    public CTimerDSO(long timeout)
    {
        this.m_timeout = timeout;
    }


    protected boolean isStopped()
    {
        return m_stopped;
    }

    @AutolockWrite
    public synchronized void setStopped(boolean stopped)
    {
        if (stopped==true)
            this.notifyAll();
        else
            activeTime=0;

        this.m_stopped = stopped;
    }

    @AutolockRead
    public synchronized long getTimeout()
    {
        return m_timeout;
    }

    @AutolockWrite
    public synchronized void setTimeout(long m_timeout)
    {
        this.m_timeout = m_timeout;
    }

    @AutolockWrite
    synchronized void initActiveTime()
    {
        if (activeTime==0)
            activeTime=System.currentTimeMillis();
    }

    @AutolockRead
    public synchronized long getWaitTime()
    {
        return activeTime-System.currentTimeMillis();
    }

    /**
     * Returns aquired token. If token id buisy wait a token;
     * @return
     *  -1 if timer stopped; other value - owned token
     */
    @AutolockWrite
    public synchronized long aquireToken()
    {
        while (!isStopped())
            {
            if (Thread.currentThread() == m_releaseThread)
                {
                m_releaseThread=null;
                return 0;
                }
            
            if (tokenOwner==-1L)
                {
                tokenOwner=Thread.currentThread().getId();
                activeTime += m_timeout;
                return tokenOwner;
                }
            else if (!isStopped())
                {
                if (LOGGER.isLoggable(Level.FINE))
                    LOGGER.log(Level.FINE, "Thread {0} wait token", new Object[] {Thread.currentThread().getName()} );
                
                try 
                    {
                    this.wait();
                    System.out.println("exit wait...");
                    }
                catch (InterruptedException ex) { LOGGER.log(Level.SEVERE, null, ex);  }
                }
            } // while

        return -1L;
    }

    public void releaseToken()
    {
        releaseToken(Thread.currentThread());
    }


    @AutolockWrite
    public synchronized void releaseToken(Thread currentThread)
    {
    long tockenId = currentThread.getId();
        LOGGER.entering(CTimerDSO.class.getName(), "releaseToken", tockenId);
        
    assert tokenOwner==tockenId : "tokenOwner==tockenId";

    if (tokenOwner==tockenId)
        {
        tokenOwner=-1L;
        this.notify();
        }
    else
        LOGGER.log(Level.SEVERE, "Releasing invalid token {1}", tockenId);

        LOGGER.exiting(CTimerDSO.class.getName(), "releaseToken");
    }


    /**
     * Cancel waiting for
     * @param thread
     */
    @AutolockWrite
    public synchronized void releaseThead(Thread thread)
    {
        LOGGER.entering(CTimerDSO.class.getName(), "releaseThead", thread.getName());

        m_releaseThread = thread;
        this.notifyAll();
        
        LOGGER.exiting(CTimerDSO.class.getName(), "releaseThead");
    }


    /** Next scheduled time */
    private long activeTime=0;

    private static final Logger LOGGER=Logger.getLogger(CTimerDSO.class.getName());

}
