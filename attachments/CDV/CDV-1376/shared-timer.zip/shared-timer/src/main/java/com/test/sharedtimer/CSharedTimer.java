/*
 * @(#)$RCSfile: CSharedTimer.java,v $ $Revision: 1.1 $ $Date: 2009/08/17 09:59:04 $ $Author: banton $ 
 * $Source: /usr/local/cvsroot/projects_src/components/accesspoint/webservice/src/main/java/hireright/applications/accesspoint/util/CSharedTimer.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *     $Log: CSharedTimer.java,v $
 *     Revision 1.1  2009/08/17 09:59:04  banton
 *     First Access Service with inmemory stored EntryPoint
 *
 */


package com.test.sharedtimer;

import com.tc.cluster.DsoCluster;
import com.tc.cluster.DsoClusterEvent;
import com.tc.cluster.DsoClusterListener;
import com.tc.injection.annotations.InjectedDsoInstance;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.midi.SysexMessage;
import org.terracotta.modules.annotations.HonorTransient;
import org.terracotta.modules.annotations.InstrumentedClass;
import org.terracotta.modules.annotations.Root;

/**
 * �������������� ������ ������� ��� ��������� ����������� �������� ���������� ��������.
 * ������ � ������������ (�.�. ����������� ����� ���������!)
 *
 * @author banton
 */
public class CSharedTimer
    extends Thread
{

    public static final long DEFAULT_TIMEOUT = 10000;  // 10 sec.

    long m_timeout=DEFAULT_TIMEOUT;

    boolean m_stop = true;

    // Time events handler
    TimerTask m_timerTask;

    /** Shared timer data object */
    @Root
    private CTimerDSO timerDSO;

    @InjectedDsoInstance
    private DsoCluster cluster;

    // Only for test purposes
    static CTimerDSO staticTimerDSO=null;

    public CSharedTimer(String name, TimerTask timerTask)
    {
        super(name);
        this.m_timerTask = timerTask;

    }

    public CSharedTimer(String name, TimerTask timerTask, long timeout)
    {
        super(name);
        this.m_timerTask = timerTask;
        this.m_timeout = timeout;

        // Only for test purposes
        if (staticTimerDSO!=null)
            timerDSO=staticTimerDSO;


        if (timerDSO==null)
            timerDSO = new CTimerDSO(m_timeout);
        else
            timerDSO.setTimeout(m_timeout);
    }

    @Override
    public void run()
    {
        timerDSO.initActiveTime();
        while (true)
            {
            synchronized(this)
                {
                if (m_stop)
                    break;
                state=ACQUIRE_STATE;
                }

            long token = timerDSO.aquireToken();
            if (token==-1L)
                break;
            else if (token==0L)
                continue;

            synchronized(this)
                {
                state=WAITE_STATE;
                // We can't use absolute time because nodes time on clater is not syncronized :(
                // long waitTime = timerDSO.getWaitTime();
                long waitTime = timerDSO.getTimeout();
                try
                    {
                    if (waitTime > 0)
                        {
                        if (LOGGER.isLoggable(Level.FINE))
                            LOGGER.log(Level.FINE, "Wait time {0}", new Object[] {waitTime} );
                        this.wait(waitTime);
                        }


                    }
                catch (InterruptedException ex)  {  }
                finally
                    {
                    if (cluster==null || cluster.areOperationsEnabled())
                        timerDSO.releaseToken();
                    }

                state = PROCESSING_STATE;

                if (!m_stop && m_timerTask!=null)
                    if (m_timerTask.scheduledExecutionTime() < 0)
                        break;
                    else
                        m_timerTask.run();
                } // synchronized(this)
            } // while
    }

    @Override
    public synchronized void start()
    {
        // Only for test purposes
        if (staticTimerDSO!=null)
            timerDSO=staticTimerDSO;

        if (timerDSO==null)
            timerDSO = new CTimerDSO(m_timeout);
        else
            timerDSO.setTimeout(m_timeout);

        m_stop=false;

        // Starting with Terracotta and not in test mode
        if (cluster!=null && staticTimerDSO==null)
            {
            if (cluster.areOperationsEnabled())
                super.start();
            cluster.addClusterListener(new DSOListener());
            }
        else
            super.start();
    }


    protected synchronized void postponedStart()
    {
        LOGGER.entering(getClass().getName(), "postponedStart");
        if (!m_stop && this.getState().equals(State.NEW))
            super.start();
        LOGGER.exiting(getClass().getName(), "postponedStart");
    }


    public void setStopped()
    {
        setStoppedInternal(false);
    }


    protected void setStoppedInternal(boolean isDSOCall)
    {
        LOGGER.entering(getClass().getName(), "setStoppedInternal");
    try
        {
        synchronized (this)
            {
            if (m_stop)
                return;

            m_stop=true;

            if (state == ACQUIRE_STATE)
                timerDSO.releaseThead(this);
            else if (state == WAITE_STATE)
                {
                if (isDSOCall)
                    timerDSO.releaseToken(this);
                this.notify();
                }
            }

        try
            { this.join(); }
        catch (InterruptedException ex)
            { LOGGER.log(Level.WARNING, null, ex);  }

        }
    finally
        {
        LOGGER.exiting(getClass().getName(), "setStopped");
        }

    }


    public synchronized void setTimerTask(TimerTask timerTask)
    {
        this.m_timerTask = timerTask;
    }

    static void setStaticTimerDSO(CTimerDSO staticTimerDSO)
    {
        CSharedTimer.staticTimerDSO = staticTimerDSO;
    }


    private int state=INVALID_STATE;

    private static final int INVALID_STATE    =-1;
    private static final int WAITE_STATE      =0;
    private static final int ACQUIRE_STATE    =1;
    private static final int PROCESSING_STATE =2;

    private static final Logger LOGGER=Logger.getLogger(CSharedTimer.class.getName());


    /**
     * Lestener for Terracotta event. Are created in start() method.
     */
    protected class DSOListener
        implements DsoClusterListener
    {
        boolean operationsEnabled=false;

        public void nodeJoined(DsoClusterEvent arg0)
        {
            // DO NOTHING
        }

        public void nodeLeft(DsoClusterEvent event)
        {
            if (event.getNode().equals(cluster.getCurrentNode()) && operationsEnabled)
                {
                CSharedTimer.this.setStoppedInternal(true);
                operationsEnabled=false;
                }
        }

        public void operationsEnabled(DsoClusterEvent event)
        {
            if (event.getNode().equals(cluster.getCurrentNode()))
                {
                operationsEnabled=true;
                CSharedTimer.this.postponedStart();
                }
            
        }

        public void operationsDisabled(DsoClusterEvent event)
        {
            if (event.getNode().equals(cluster.getCurrentNode()))
                {
                CSharedTimer.this.setStoppedInternal(true);
                operationsEnabled=false;
                }
        }
    }

}
