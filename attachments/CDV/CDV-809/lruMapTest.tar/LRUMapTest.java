/*
 * All content copyright (c) 2003-2008 Terracotta, Inc., except as may otherwise be noted in a separate copyright notice.  All rights reserved.
 */

import org.apache.commons.collections.map.LRUMap;

import java.util.Iterator;

public class LRUMapTest {

  private LRUMap map;

  public LRUMapTest() {
    map = new LRUMap();
  }

  public static void main(String[] args) {
    LRUMapTest lruMapTest = new LRUMapTest();
    String cmd = args.length == 1 ? args[0] : "";
    if ("print".equals(cmd)) {
      lruMapTest.print();
    } else if ("populate".equals(cmd)) {
      lruMapTest.populate();
    } else {
      System.err.println("Doing nothing as no print or populate on cmd line");
    }
  }

  private void print() {
    for (Iterator it = map.keySet().iterator(); it.hasNext();) {
      final Object key = it.next();
      System.err.println("key=" + key + " value=" + map.get(key));
    }
  }

  private synchronized void populate() {
    map.put("1", "one");
    map.put("2", "two");
  }
}
