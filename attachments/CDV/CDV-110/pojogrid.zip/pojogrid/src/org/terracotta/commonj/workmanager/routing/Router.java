/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import java.util.Map;
import java.util.concurrent.BlockingQueue;

import commonj.work.Work;
import commonj.work.WorkException;
import commonj.work.WorkListener;
import commonj.work.WorkRejectedException;

/**
 * Interface that all routers should implement in order to route the work 
 * to a specific routing ID (registered by a worker).
 * 
 * @author Jonas Bon&#233;r
 */
public interface Router<ID> {

  /**
   * Routes or reroutes a work item. Is responsible for putting the Work onto the "correct" queue 
   * according the the routing algorithm.
   * 
   * @param work the Work to be routed
   * 
   * @return the routable work item that is wrapping the Work
   * @throws {@link WorkException}
   * @throws {@link WorkRejectedException}
   */
  public RoutableWorkItem<ID> route(RoutableWorkItem<ID> workItem) throws WorkException, WorkRejectedException;

  /**
   * Routes the work. Is responsible for putting the Work onto the "correct" queue 
   * according the the routing algorithm.
   * 
   * @param work the Work to be routed
   * 
   * @return the routable work item that is wrapping the Work
   * @throws {@link WorkException}
   * @throws {@link WorkRejectedException}
   */
  public RoutableWorkItem<ID> route(Work work) throws WorkException, WorkRejectedException;

  /**
   * Routes the work. Is responsible for putting the Work onto the "correct" queue 
   * according the the routing algorithm.
   * 
   * @param work the Work to be routed
   * @param listener the WorkListener to monitor the status for the Work
   * 
   * @return the routable work item that is wrapping the Work
   * @throws {@link WorkException}
   * @throws {@link WorkRejectedException}
   */
  public RoutableWorkItem<ID> route(Work work, WorkListener listener) throws WorkException, WorkRejectedException;

  // ------ Default router implementations ------
  
  /**
   * Routes all work to the same single queue.
   */
  public static class SingleQueueRouter<ID> implements Router<ID> {
    private final ID m_singleQueueID;

    // the single work queue
    private final BlockingQueue<RoutableWorkItem<ID>> m_queue;

    public SingleQueueRouter(final WorkQueueManager<ID> queueManager, final ID singleQueueID) {
      m_singleQueueID = singleQueueID;
      m_queue = queueManager.getOrCreateQueueFor(m_singleQueueID);
    }
    
    public RoutableWorkItem<ID> route(final Work work) throws WorkRejectedException {
      return route(work, null);
    }

    public RoutableWorkItem<ID> route(final Work work, final WorkListener listener) throws WorkRejectedException {
      RoutableWorkItem<ID> workItem = new RoutableWorkItem<ID>(work, null, m_singleQueueID);
      try {
        m_queue.put(workItem);
        return workItem;
      } catch (InterruptedException e) {
        throw workItem.newWorkRejectedException(e);
      }
    }

    public RoutableWorkItem<ID> route(final RoutableWorkItem<ID> workItem) throws WorkRejectedException {
      try {
        m_queue.put(workItem);
        return workItem;
      } catch (InterruptedException e) {
        throw workItem.newWorkRejectedException(e);
      }
    }
  }
  
  /**
   * Round robin router. 
   * TODO need to handle work queue removal (in case of worker failure)
   */
  public static class RoundRobinRouter<ID> implements Router<ID> {
    
    private final WorkQueueManager<ID> m_queueManager;
    private final ID[] m_routingIDs;
    private int m_index = 0;

    public RoundRobinRouter(final WorkQueueManager<ID> queueManager, final ID[] routingIDs) {
      m_queueManager = queueManager;
      m_routingIDs = routingIDs;
      // create all queues upfront
      for (int i = 0; i < routingIDs.length; i++) {
        m_queueManager.getOrCreateQueueFor(routingIDs[i]);        
      }
    }
    
    public RoutableWorkItem<ID> route(final Work work) throws WorkException {
      return route(work, null);
    }

    public RoutableWorkItem<ID> route(final Work work, final WorkListener listener) throws WorkException {
      RoutableWorkItem<ID> workItem = createRoutableWorkItem(work, listener);
      m_queueManager.put(workItem, workItem.getRoutingID());
      return workItem;
    }

    public RoutableWorkItem<ID> route(final RoutableWorkItem<ID> workItem) throws WorkRejectedException, WorkException {
      m_queueManager.put(workItem, workItem.getRoutingID()); // TODO currently always rerouted to the original queue - not good if rerouted due to worker failure
      return workItem;
    }

    private synchronized RoutableWorkItem<ID> createRoutableWorkItem(
        final Work work, final WorkListener listener) {
      if (m_index == m_routingIDs.length) {
        m_index = 0;
      }
      return new RoutableWorkItem<ID>(work, listener, m_routingIDs[m_index++]);
    }
  }

  /**
   * Load balancing router, routes work to the shortest queue. 
   */
  public static class LoadBalancingRouter<ID> implements Router<ID> {
    
    private final WorkQueueManager<ID> m_queueManager;

    public LoadBalancingRouter(final WorkQueueManager<ID> queueManager, final ID[] routingIDs) {
      m_queueManager = queueManager;
      // create all queues upfront
      for (int i = 0; i < routingIDs.length; i++) {
        m_queueManager.getOrCreateQueueFor(routingIDs[i]);        
      }
    }
    
    public RoutableWorkItem<ID> route(final Work work) throws WorkException {
      return route(work, null);
    }

    public RoutableWorkItem<ID> route(final Work work, final WorkListener listener) throws WorkException {
      WorkQueueLength<ID> shortestQueue = getShortestWorkQueue();
      RoutableWorkItem<ID> workItem = new RoutableWorkItem<ID>(work, listener, shortestQueue.routingID);
      try {
        shortestQueue.workQueue.put(workItem);
      } catch (InterruptedException e) {
        throw workItem.newWorkRejectedException(e);
      }
      return workItem;
    }

    public RoutableWorkItem<ID> route(final RoutableWorkItem<ID> workItem) throws WorkRejectedException {
      WorkQueueLength<ID> shortestQueue = getShortestWorkQueue();
      synchronized (workItem) {
        workItem.setRoutingID(shortestQueue.routingID);        
      }
      try {
        shortestQueue.workQueue.put(workItem);
      } catch (InterruptedException e) {
        throw workItem.newWorkRejectedException(e);
      }
      return workItem;
    }

    private WorkQueueLength<ID> getShortestWorkQueue() {
      WorkQueueLength<ID> shortestQueue = new WorkQueueLength<ID>();
      
      int queueLengthForShortestQueue = Integer.MAX_VALUE;
      ID routingIDForShortestQueue = null;
      Map<ID, BlockingQueue<RoutableWorkItem<ID>>> queues = m_queueManager.getQueues();
      for (Map.Entry<ID, BlockingQueue<RoutableWorkItem<ID>>> entry: queues.entrySet()) {
        ID routingID = entry.getKey();
        BlockingQueue<RoutableWorkItem<ID>> queue = entry.getValue();
        int queueSize = queue.size();
        if (queueSize <= queueLengthForShortestQueue) {
          queueLengthForShortestQueue = queueSize;
          routingIDForShortestQueue = routingID;
        } 
      }
      shortestQueue.workQueue = m_queueManager.getOrCreateQueueFor(routingIDForShortestQueue);         
      shortestQueue.routingID = routingIDForShortestQueue;
      return shortestQueue;
    }
    
    private static class WorkQueueLength<ID> {
      public ID routingID;
      public BlockingQueue<RoutableWorkItem<ID>> workQueue;
      public int queueLength = Integer.MAX_VALUE;
    }
  }
}
