/*
 * Copyright (c) 2005-2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.singlequeue;

import commonj.work.Work;
import commonj.work.WorkEvent;
import commonj.work.WorkException;
import commonj.work.WorkRejectedException;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.terracotta.commonj.workmanager.DefaultWorkItem;
import org.terracotta.commonj.workmanager.Worker;

/**
 * Worker bean, recieves a work from the same single work queue. It grabs the
 * next pending work and executes it.
 * 
 * @author Jonas Bon&#233;r
 */
public class SingleQueueWorker implements Worker {

  protected final ExecutorService m_threadPool = Executors.newCachedThreadPool();
  protected final SingleWorkQueue m_queue;
  protected volatile boolean m_isRunning = true;

  public SingleQueueWorker(final SingleWorkQueue queue) {
    m_queue = queue;
  }

  /* (non-Javadoc)
   * @see org.terracotta.commonj.workmanager.simple.Worker#start()
   */
  public void start() throws WorkException {
    while (m_isRunning) {
      final DefaultWorkItem workItem = m_queue.take();
      final Work work = workItem.getResult();
      m_threadPool.execute(new Runnable() {
        public void run() {
          try {
            workItem.setStatus(WorkEvent.WORK_STARTED, null);
            work.run();
            workItem.setStatus(WorkEvent.WORK_COMPLETED, null);
          } catch (Throwable e) {
            workItem.setStatus(WorkEvent.WORK_REJECTED, new WorkRejectedException(e));
          }
        }
      });
    }
  }

  /* (non-Javadoc)
   * @see org.terracotta.commonj.workmanager.simple.Worker#stop()
   */
  public void stop() {
    m_threadPool.shutdown();
    m_isRunning = false;
  }
}
