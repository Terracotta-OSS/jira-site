/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;

import commonj.work.WorkException;

/**
 * @author Jonas Bon&#233;r
 */
public class WorkQueueTimeoutDetector<ID> {

  private static final int SLEEP_TIME_FOR_WORK_QUEUE_TIMEOUT_CHECKER = 5000;

  private final long m_workQueueTimeout;

  private final Router<ID> m_router;

  private final WorkQueueManager<ID> m_workQueueManager;

  private volatile boolean m_isRunning = true;

  private Thread m_timeoutDetectorThread;

  public WorkQueueTimeoutDetector(
      final long workQueueTimeout, 
      final Router<ID> router, 
      final WorkQueueManager<ID> workQueueManager) {
    m_workQueueTimeout = workQueueTimeout;
    m_router = router;
    m_workQueueManager = workQueueManager;
    
    m_timeoutDetectorThread = new Thread(
        new Runnable() {
            public void run() {
              System.out.println("### Starting work queue timeout detector");
              while (m_isRunning ) {
                try {
                  Thread.sleep(SLEEP_TIME_FOR_WORK_QUEUE_TIMEOUT_CHECKER);
                } catch (InterruptedException e) {
                  Thread.currentThread().interrupt();
                  throw new RuntimeException(e);
                }
                System.out.println("### Checking queue time out...)");      
                Set<BlockingQueue<RoutableWorkItem<ID>>> timedOutQueues = getTimedOutQueues();
                for (BlockingQueue<RoutableWorkItem<ID>> timedOutQueue : timedOutQueues) {
                  for (RoutableWorkItem<ID> workItem : timedOutQueue) {
                    try {
                      System.out.println("### rerouting work " + workItem);
                      m_router.route(workItem);
                    } catch (WorkException e) {
                      e.printStackTrace();
                      // TODO how to handle this?
                    }
                  }
                  timedOutQueue.clear();
                  timedOutQueue = null;
                }
              }
            }
    });
    m_timeoutDetectorThread.setName("Work Queue Timeout Detector");
    m_timeoutDetectorThread.setDaemon(true);
  }
  
  public void start() {
    m_timeoutDetectorThread.start();
  }

  private Set<BlockingQueue<RoutableWorkItem<ID>>> getTimedOutQueues() {
    final Set<BlockingQueue<RoutableWorkItem<ID>>> timedOutQueues = 
      new HashSet<BlockingQueue<RoutableWorkItem<ID>>>();
    for (Map.Entry<ID, BlockingQueue<RoutableWorkItem<ID>>> entry : 
      m_workQueueManager.getQueues().entrySet()) {
      ID routingID = entry.getKey();
      BlockingQueue<RoutableWorkItem<ID>> queue = entry.getValue();
      RoutableWorkItem<ID> workItem = queue.peek();
      if (workItem == null) {
        continue;
      }
      long timestamp = workItem.getTimestamp();
      if (timestamp == -1L) { // first time around
        synchronized (workItem) {
          workItem.setTimestamp(System.nanoTime());
          continue;          
        }
      }
      long waitingTime = System.nanoTime() - timestamp;
      if (waitingTime > m_workQueueTimeout) {
        System.out.println("worker(s) using routing ID [" + routingID + "] are assumed dead, rerouting the work");
        timedOutQueues.add(m_workQueueManager.getQueues().remove(routingID));
      }
    }
    return timedOutQueues;
  }

  public void shutdown() {
    m_isRunning = false;
    try {
      m_timeoutDetectorThread.join();
    } catch (InterruptedException e) {
      e.printStackTrace();
      Thread.currentThread().interrupt();
    }
  }
}
