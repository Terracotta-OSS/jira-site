/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import commonj.work.Work;
import commonj.work.WorkEvent;
import commonj.work.WorkException;
import commonj.work.WorkItem;
import commonj.work.WorkListener;

import org.terracotta.commonj.workmanager.AbstractWorkManager;

/**
 * XXX: WARNING - WORK IN PROGRESS - NOT WORKING YET.
 * 
 * A routing aware WorkerManager that uses an implementation of the Router interface to do 
 * the route work to different work queues.
 * 
 * @author Jonas Bon&#233;r
 */
public class WorkQueueTimeoutDetectingWorkManager<ID> extends AbstractWorkManager { 

  private static final int SLEEP_TIME_FOR_WORK_QUEUE_TIMEOUT_CHECKER = 5000;

  private final Map<ID, Queue<RoutableWorkItem<ID>>> m_workInProgress = 
    new HashMap<ID, Queue<RoutableWorkItem<ID>>>();
  private final long m_workQueueTimeout;
  private final Router<ID> m_router;
  private final WorkQueueManager<ID> m_workQueueManager;
  private volatile boolean m_isRunning = true;
  private final Thread m_timeoutDetectorThread;
  
  public WorkQueueTimeoutDetectingWorkManager(
      final long workQueueTimeout, 
      final Router<ID> router, 
      final WorkQueueManager<ID> workQueueManager) {
    m_router = router;
    m_workQueueTimeout = workQueueTimeout;
    m_workQueueManager = workQueueManager;
    
    m_timeoutDetectorThread = new Thread(new Runnable() {
      public void run() {
        while (m_isRunning ) {
          try {
            Thread.sleep(SLEEP_TIME_FOR_WORK_QUEUE_TIMEOUT_CHECKER);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
          }
          
          System.out.println("### Checking queue time out...)");      
          for (Map.Entry<ID, Queue<RoutableWorkItem<ID>>> entry : m_workInProgress.entrySet()) {
            ID routingID = entry.getKey();
            Queue<RoutableWorkItem<ID>> workItems = entry.getValue();            
            if (workItems.isEmpty()) {
              continue;
            }
            Collection<RoutableWorkItem<ID>> completedWork = new ArrayList<RoutableWorkItem<ID>>();
            for (Iterator<RoutableWorkItem<ID>> it = workItems.iterator(); it.hasNext();) {
              RoutableWorkItem<ID> workItem = it.next();
              if (workItem.getStatus() == WorkEvent.WORK_COMPLETED || 
                  workItem.getStatus() == WorkEvent.WORK_REJECTED) {
                completedWork.add(workItem);
              }              
            }
            workItems.remove(completedWork);
            
            if (workItems.isEmpty()) {
              continue;
            }
            RoutableWorkItem<ID> firstWorkItem = workItems.peek();
            if (firstWorkItem.getTimestamp() == Long.MAX_VALUE) { // not timestamped yet
              synchronized (firstWorkItem) {
                System.out.println("------- timestamping");
                firstWorkItem.setTimestamp(System.nanoTime());
                continue;                 
              }
            }
            
            if ((System.nanoTime() - firstWorkItem.getTimestamp() > m_workQueueTimeout)) {
              // has timed out
              m_workQueueManager.getQueues().remove(routingID);
              for (RoutableWorkItem<ID> workItem : workItems) {
                try {        
                  System.out.println("### rerouting work " + workItem);
                  synchronized (workItem) {
                    workItem.setTimestamp(Long.MAX_VALUE); // reset timestamp
                  }
                  m_router.route(workItem);
                } catch (WorkException e) {
                  e.printStackTrace();
                  // TODO how to handle this?
                }                            
              }
              workItems.clear();
            }            
          }
        }
      }
    });
    m_timeoutDetectorThread.setName("Work Queue Timeout Detector");
    m_timeoutDetectorThread.setDaemon(true); 
    m_timeoutDetectorThread.start();
  }

  public WorkItem schedule(final Work work) throws WorkException {
    return schedule(work, null);
  }

  public WorkItem schedule(final Work work, final WorkListener listener) throws WorkException {
    RoutableWorkItem<ID> workItem = m_router.route(work, listener);
    ID routingID = workItem.getRoutingID();
    Queue<RoutableWorkItem<ID>> workItems = m_workInProgress.get(routingID);
    if (workItems == null) {
      workItems = new LinkedList<RoutableWorkItem<ID>>();
      m_workInProgress.put(routingID, workItems);
    }
    workItems.add(workItem);
    return workItem;
  }

  public void stop() {
    m_isRunning = false;
  }
}