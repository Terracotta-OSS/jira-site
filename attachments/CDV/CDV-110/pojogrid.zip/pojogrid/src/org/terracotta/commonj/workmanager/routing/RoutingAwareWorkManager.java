/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import commonj.work.Work;
import commonj.work.WorkException;
import commonj.work.WorkItem;
import commonj.work.WorkListener;

import org.terracotta.commonj.workmanager.AbstractWorkManager;

/**
 * A routing aware WorkerManager that uses an implementation of the Router interface to do 
 * the route work to different work queues.
 * 
 * @author Jonas Bon&#233;r
 */
public class RoutingAwareWorkManager<ID> extends AbstractWorkManager { 

  private final Router<ID> m_router;

  public RoutingAwareWorkManager(final Router<ID> router) {
    m_router = router;
  }

  public WorkItem schedule(final Work work) throws WorkException {
    return m_router.route(work);
  }

  public WorkItem schedule(final Work work, final WorkListener listener) throws WorkException {
    return m_router.route(work, listener);
  }
}