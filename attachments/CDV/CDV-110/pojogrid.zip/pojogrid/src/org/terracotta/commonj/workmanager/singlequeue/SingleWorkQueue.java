/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.singlequeue;

import commonj.work.WorkException;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.terracotta.commonj.workmanager.DefaultWorkItem;

/**
 * Implements a single work queue which wraps a linked blocking queue.
 * 
 * @author Jonas Bon&#233;r
 */
public class SingleWorkQueue {
  
  // Terracotta Shared Root
  private final BlockingQueue<DefaultWorkItem> m_workQueue = new LinkedBlockingQueue<DefaultWorkItem>();

  public void put(final DefaultWorkItem workItem) throws WorkException {
    try {
      m_workQueue.put(workItem); // blocks if queue is full
    } catch (InterruptedException e) {
      throw workItem.newWorkRejectedException(e);
    }
  }
  
  public DefaultWorkItem peek() throws WorkException {
    return m_workQueue.peek(); // returns null if queue is empty
  }

  public DefaultWorkItem take() throws WorkException {
    try {
      return m_workQueue.take(); // blocks if queue is empty
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new WorkException(e);
    }
  }
}
