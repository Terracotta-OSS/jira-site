package org.terracotta.spider;

/**
 * @author Jonas Bon&#233;r
 */
public class PageNotFoundException extends RuntimeException {
 
  private static final long serialVersionUID = -3678135197004403049L;

  public PageNotFoundException(String msg) {
    super(msg);
  }
}
