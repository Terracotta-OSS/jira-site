/*
 * Copyright (c) 2005-2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.singlequeue;

import org.terracotta.commonj.workmanager.Worker;

/**
 * @author Jonas Bon&#233;r
 */
public class SingleQueueWorkerRunner {

  public static void main(String[] args) throws Exception {  
    System.out.println("-- starting worker...");
    System.out.println("-- kill it with ^C when finished");

    Worker worker = new SingleQueueWorker(new SingleWorkQueue());
    worker.start();
  }
}
