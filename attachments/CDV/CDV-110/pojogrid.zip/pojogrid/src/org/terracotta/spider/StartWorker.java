package org.terracotta.spider;

import org.terracotta.commonj.workmanager.Worker;
import org.terracotta.commonj.workmanager.routing.DefaultWorkQueueManager;
import org.terracotta.commonj.workmanager.routing.RoutingAwareWorker;
import org.terracotta.commonj.workmanager.routing.WorkQueueManager;

/**
 * @author Jonas Bon&#233;r
 */
public class StartWorker {
  public static final String SINGLE_QUEUE_ID = "SINGLE_QUEUE_ID";

  public static void main(String[] args) throws Exception {
    System.out.println("-- starting worker...");
    System.out.println("-- kill it with ^C when finished");
    String routingID = null;
    if (args.length != 0) {
      routingID = args[0];
    }
    if (routingID == null) {
      routingID = SINGLE_QUEUE_ID;
    }
    
    WorkQueueManager<String> workQueueManager = new DefaultWorkQueueManager<String>();
    Worker worker = new RoutingAwareWorker<String>(workQueueManager, routingID);
    worker.start();
  }
}
