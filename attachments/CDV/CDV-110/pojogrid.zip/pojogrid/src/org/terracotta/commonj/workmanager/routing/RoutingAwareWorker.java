/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.terracotta.commonj.workmanager.Worker;

import commonj.work.Work;
import commonj.work.WorkEvent;
import commonj.work.WorkException;
import commonj.work.WorkRejectedException;

/**
 * Worker that has an is aware of routing. Each instance of the RoutingAwareWorker class
 * has a routing ID and gets a unique work queue mapped to this routing ID.
 * 
 * @author Jonas Bon&#233;r
 * @author Gordon Rose
 */
public class RoutingAwareWorker<ID> implements Worker {

  protected BlockingQueue<RoutableWorkItem<ID>> m_queue;
  protected final ExecutorService m_threadPool = Executors.newCachedThreadPool();  
  protected final WorkQueueManager<ID> m_queueManager;
  protected volatile boolean m_isRunning = true;
  protected final ID m_routingID;
  
  private static final int WORKER_TIMEOUT_IN_SECONDS = 60;
  
  public RoutingAwareWorker(final WorkQueueManager<ID> queueManager, final ID routingID) {
    m_routingID = routingID;      
    m_queue = queueManager.getOrCreateQueueFor(m_routingID);
    m_queueManager = queueManager;
    System.out.println("Starting worker with routing ID: " + routingID);
  }

  public void start() throws WorkException {
    while (m_isRunning) {
      final RoutableWorkItem<ID> workItem;
      try {
        //workItem = m_queue.take();
      	workItem = m_queue.poll(WORKER_TIMEOUT_IN_SECONDS, TimeUnit.SECONDS);
      	if (workItem == null) {
      		System.out.println("Worker has waited " + String.valueOf(WORKER_TIMEOUT_IN_SECONDS) +
      				" seconds for new work. Stopping now.");
      		m_isRunning = false;
      	}
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw new WorkException(e);
      }
      
      if (workItem != null) {
      
	      final Work work = workItem.getResult();
	      m_threadPool.execute(new Runnable() {
	        public void run() {
	          try {
	            workItem.setStatus(WorkEvent.WORK_STARTED, null);
	            work.run();
	            workItem.setStatus(WorkEvent.WORK_COMPLETED, null);
	          } catch (Throwable e) {
	            workItem.setStatus(WorkEvent.WORK_REJECTED, new WorkRejectedException(e));
	          }
	        }
	      });
      
      } // -- if (workItem != null) 
    }
  }
 
  public void stop() {
    m_isRunning = false;
    m_threadPool.shutdown();
    m_queueManager.removeQueueFor(m_routingID);
  }
}
