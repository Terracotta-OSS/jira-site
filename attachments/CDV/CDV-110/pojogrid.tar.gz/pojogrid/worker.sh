#!/bin/sh
#
# All content copyright (c) 2003-2006 Terracotta, Inc.,
# except as may otherwise be noted in a separate copyright notice.
# All rights reserved

# The following line that sets the TOPDIR environment variable operates
# under the assumption that the folder in which this shell script
# resides is below the samples folder in the Terracotta installation
TOPDIR=../..

# The remaining commands will work properly as long as the the environment
# variable set above is correct

. "${TOPDIR}"/libexec/tc-functions.sh

tc_install_dir "${TOPDIR}"/..
tc_classpath "./classes:lib/commonj-twm.jar:lib/jericho-html-2.3.jar:lib/commons-cli-1.0.jar" true
tc_java_opts "-Xms128m -Xmx256m"

tc_java -classpath "${TC_CLASSPATH}" -Dtc.install-root="${TC_INSTALL_DIR}" ${TC_ALL_JAVA_OPTS} -Dtc.config=tc-config.xml org.terracotta.spider.StartWorker $1
