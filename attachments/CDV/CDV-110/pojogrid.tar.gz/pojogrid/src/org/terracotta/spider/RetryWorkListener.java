package org.terracotta.spider;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.terracotta.commonj.workmanager.routing.RoutableWorkItem;
import org.terracotta.commonj.workmanager.routing.DefaultWorkQueueManager;
import org.terracotta.commonj.workmanager.routing.Router;
import org.terracotta.commonj.workmanager.routing.RoutingAwareWorkManager;
import org.terracotta.commonj.workmanager.routing.WorkQueueManager;

import commonj.work.Work;
import commonj.work.WorkEvent;
import commonj.work.WorkException;
import commonj.work.WorkListener;
import commonj.work.WorkManager;
import commonj.work.WorkRejectedException;

/**
 * Work listener that retries work upon rejection.
 * 
 * @author Jonas Bon&#233;r
 */
public class RetryWorkListener implements WorkListener {

  private static final int MAX_NR_OF_RETRIES = 3;
  
  private final String m_routingIdForFailOverNode;
  private final Map<Work, Integer> m_retryCount = new ConcurrentHashMap<Work, Integer>();

  // work manager sends schedules all work to the fail-over worker
  private final WorkManager m_workManager = new RoutingAwareWorkManager<String>(
      new Router<String>() {
        private final WorkQueueManager<String> m_workQueueManager = new DefaultWorkQueueManager<String>();

        public RoutableWorkItem<String> route(final Work work, final WorkListener listener) throws WorkException {
          final RoutableWorkItem<String> workItem = new RoutableWorkItem<String>(
              work, RetryWorkListener.this, m_routingIdForFailOverNode);
          m_workQueueManager.put(workItem, m_routingIdForFailOverNode);
          return workItem;
        }

        public RoutableWorkItem<String> route(final Work work) throws WorkException {
          return route(work, null);
        }

        public RoutableWorkItem<String> route(final RoutableWorkItem<String> workItem) throws WorkException, WorkRejectedException {
          // not used
          throw new UnsupportedOperationException();
        }
      });

  public RetryWorkListener(final String routingIdForFailOverNode) {
    m_routingIdForFailOverNode = routingIdForFailOverNode;
  }
  
  public void workRejected(WorkEvent event) {
    try {
      Work rejectedWork = event.getWorkItem().getResult();

      if (!m_retryCount.containsKey(rejectedWork)) {
        m_retryCount.put(rejectedWork, 1);
      }
      int nrOfRetries = m_retryCount.get(rejectedWork);
      if (nrOfRetries <= MAX_NR_OF_RETRIES) {
        System.err.println("### RETRYING WORK: " + rejectedWork + " "
            + nrOfRetries + " time(s)...");

        // reschedule the work
        m_workManager.schedule(rejectedWork, this);

        m_retryCount.put(rejectedWork, ++nrOfRetries);
      } else {
        m_retryCount.remove(rejectedWork); // giving up on this work
      }
    } catch (WorkException e) {
    }
  }

  public void workAccepted(WorkEvent event) {
  }

  public void workCompleted(WorkEvent event) {
  }

  public void workStarted(WorkEvent event) {
  }

}
