/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import java.util.Map;
import java.util.concurrent.BlockingQueue;
import commonj.work.WorkException;

/**
 * Interface that all work queue managers should implement. Has methods for creating and removing 
 * work queues (mapped to a specific routing ID) as well as put new work items onto specific 
 * work queues.
 * 
 * @author Jonas Bon&#233;r
 */
public interface WorkQueueManager<ID> {

  /**
   * Creates a work queue for a specific routing ID, if the queue already exists then it 
   * simply returns it.
   * 
   * @param routingID the routing ID 
   * @return the work queue mapped to the routing ID
   */
  public BlockingQueue<RoutableWorkItem<ID>> getOrCreateQueueFor(ID routingID);

  /**
   * Removes the work queue for a specific routing ID.
   * 
   * @param routingID the routing ID
   */
  public void removeQueueFor(ID routingID);

  /**
   * Puts a RoutableWorkItem on the queue mapped to a specific routing ID.
   * 
   * @param workItem the work item
   * @param routingID the routing ID
   * @throws WorkException if the work item could not be put on the queue
   */
  public void put(RoutableWorkItem<ID> workItem, ID routingID) throws WorkException;

  /**
   * Returns the map with all the work queues.
   */
  public Map<ID, BlockingQueue<RoutableWorkItem<ID>>> getQueues();
}