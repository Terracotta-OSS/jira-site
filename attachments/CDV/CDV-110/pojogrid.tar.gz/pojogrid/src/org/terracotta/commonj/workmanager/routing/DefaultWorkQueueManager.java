/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import commonj.work.WorkException;

import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Default work queue manager that implements a routable work queue in which each 
 * work queue is mapped to a specific routing ID.
 * 
 * @author Jonas Bon&#233;r
 */
public class DefaultWorkQueueManager<ID> implements WorkQueueManager<ID> {
    
  protected volatile boolean m_isRunning = true;

  protected final Map<ID, BlockingQueue<RoutableWorkItem<ID>>> m_workQueues = 
    new ConcurrentHashMap<ID, BlockingQueue<RoutableWorkItem<ID>>>();

  /* (non-Javadoc)
   * @see org.terracotta.commonj.workmanager.routing.WorkQueueManager#createQueueFor(java.lang.String)
   */
  public BlockingQueue<RoutableWorkItem<ID>> getOrCreateQueueFor(final ID routingID) {
    if (routingID == null) {
      throw new IllegalArgumentException("routing ID is null");
    }
    synchronized (m_workQueues) {
      if (m_workQueues.containsKey(routingID)) {
        return m_workQueues.get(routingID);
      }
      BlockingQueue<RoutableWorkItem<ID>> newQueue = new LinkedBlockingQueue<RoutableWorkItem<ID>>();
      m_workQueues.put(routingID, newQueue);
      System.out.println("registering a new work queue for routing ID: " + routingID);
      return newQueue;
    }    
  }
  
  /* (non-Javadoc)
   * @see org.terracotta.commonj.workmanager.routing.WorkQueueManager#removeQueueFor(java.lang.String)
   */
  public void removeQueueFor(final ID routingID) {
    if (routingID == null) {
      throw new IllegalArgumentException("routing ID is null");
    }
    synchronized (m_workQueues) {
      if (!m_workQueues.containsKey(routingID)) {
        return;
      }
      m_workQueues.remove(routingID);
      System.out.println("unregistering the work queue for routing ID: " + routingID);
    }    
  }
    
  /* (non-Javadoc)
   * @see org.terracotta.commonj.workmanager.routing.WorkQueueManager#put(org.terracotta.commonj.workmanager.routing.RoutableWorkItem, java.lang.String)
   */
  public void put(final RoutableWorkItem<ID> workItem, final ID routingID) throws WorkException {
    BlockingQueue<RoutableWorkItem<ID>> queue = getOrCreateQueueFor(routingID);
    try {
      queue.put(workItem); // blocks if queue is full
    } catch (InterruptedException e) {
      throw workItem.newWorkRejectedException(e);
    }
  }

  public Map<ID, BlockingQueue<RoutableWorkItem<ID>>> getQueues() {
    return m_workQueues;
  }
  
  public void shutdown() {
    m_isRunning = false;
    m_workQueues.clear();
  }
}
