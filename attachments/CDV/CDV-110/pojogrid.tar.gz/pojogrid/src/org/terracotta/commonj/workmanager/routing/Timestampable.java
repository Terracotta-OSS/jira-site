/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

/**
 * @author Jonas Bon&#233;r
 */
public interface Timestampable {
  public long getTimestamp();
  public void setTimestamp(long time);
  
}
