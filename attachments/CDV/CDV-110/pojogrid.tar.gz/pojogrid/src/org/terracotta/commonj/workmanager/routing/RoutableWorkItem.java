/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.routing;

import org.terracotta.commonj.workmanager.DefaultWorkItem;

import commonj.work.Work;
import commonj.work.WorkListener;

/**
 * Routable implementation of the WorkItem abstraction. 
 * 
 * @author Jonas Bon&#233;r
 */
public class RoutableWorkItem<ID> extends DefaultWorkItem implements Routable<ID>, Timestampable {
  protected ID m_routingID;
  protected long m_timestamp = Long.MAX_VALUE; //System.nanoTime();
  
  public RoutableWorkItem(final Work work, final WorkListener workListener, final ID routingID) {
    super(work, workListener);
    m_routingID = routingID;
  }

  public ID getRoutingID() {
    return m_routingID;
  }

  public void setRoutingID(final ID routingID) {
    m_routingID = routingID;
  }

  public long getTimestamp() {
    return m_timestamp;
  }
  
  public void setTimestamp(long t) {
    m_timestamp = t;
  }
  
  public WorkListener getWorkListener() {
    return m_workListener;
  }
}