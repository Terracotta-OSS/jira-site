/*
 * Copyright (c) 2005 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager.singlequeue;

import org.terracotta.commonj.workmanager.AbstractWorkManager;
import org.terracotta.commonj.workmanager.DefaultWorkItem;

import commonj.work.Work;
import commonj.work.WorkException;
import commonj.work.WorkItem;
import commonj.work.WorkListener;

/**
 * Implementation of the WorkManager abstraction that is scheduling all work to the same
 * work single queue.
 * 
 * @author Jonas Bon&#233;r
 */
public class SingleQueueWorkManager extends AbstractWorkManager { 

  private final SingleWorkQueue m_queue;

  public SingleQueueWorkManager(final SingleWorkQueue queue) {
    m_queue = queue;
  }

  public WorkItem schedule(final Work work) throws WorkException {
    DefaultWorkItem workItem = new DefaultWorkItem(work, null);
    m_queue.put(workItem);
    return workItem;
  }

  public WorkItem schedule(final Work work, final WorkListener listener) throws WorkException {
    DefaultWorkItem workItem = new DefaultWorkItem(work, listener);
    m_queue.put(workItem);
    return workItem;
  }
}