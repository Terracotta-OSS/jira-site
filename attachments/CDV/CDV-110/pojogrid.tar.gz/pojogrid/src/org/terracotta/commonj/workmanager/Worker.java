/*
 * Copyright (c) 2006 Terracotta, Inc. All rights reserved.
 */
package org.terracotta.commonj.workmanager;

import commonj.work.WorkException;

/**
 * Standard Worker interface.
 * 
 * @author Jonas Bon&#233;r
 */
public interface Worker {

  public abstract void start() throws WorkException;

  public abstract void stop();
}