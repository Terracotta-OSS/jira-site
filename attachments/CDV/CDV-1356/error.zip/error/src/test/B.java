package test;

public class B {

	public Object field;

	public void mutate(B b) {
		new Sub().mutate(b);
	}

	private class Sub extends A {

		public void mutate(B b) {
			b.field = this;
		}
	}

}
