package test;

public class Main {

	private static final B root = new B();

	public static void main(String[] args) {
		if (root.field != null) {
			throw new AssertionError();
		}

		try {
			root.mutate(root);
			throw new AssertionError("mutated without a lock");
		} catch (Exception e) {
			// expected exception is UnlockedSharedObjectException
			if (!e.getClass().getName().equals(
					"com.tc.object.tx.UnlockedSharedObjectException")) {
				throw new RuntimeException(e);
			}
		}
	}
}
