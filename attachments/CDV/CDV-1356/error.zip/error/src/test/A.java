package test;

import java.util.concurrent.ConcurrentHashMap;

abstract public class A<K, V> extends ConcurrentHashMap<K, V> {
	//
}
