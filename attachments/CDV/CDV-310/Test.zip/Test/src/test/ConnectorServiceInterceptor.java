package test;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class ConnectorServiceInterceptor {

    @Around("execution(void test.ConnectorService.startConnector(long))")
    public void startConnector(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("i Start");
        pjp.proceed(pjp.getArgs());
    }

    @Around("execution(void test.ConnectorService.stopConnector(long))")
    public void stopConnector(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("i Stop");
        pjp.proceed(pjp.getArgs());
    }

    @Around("execution(void test.ConnectorService.removeConnector(long))")
    public void removeConnector(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("i Remove");
        Object[] args = pjp.getArgs();
        long id = (Long) args[0];
        pjp.proceed(pjp.getArgs());
        System.out.println(id);
    }

    @Around("execution(long test.ConnectorService.createConnector(..))")
    public Object createConnector(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("i Create");
        return pjp.proceed(pjp.getArgs());
    }

    @Around("execution(void test.ConnectorService.destroyConnector(long))")
    public void destroyConnector(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("i Destroy");
        pjp.proceed(pjp.getArgs());
    }
}
