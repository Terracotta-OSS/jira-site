package test;


public interface IConnectorService {
    void startConnector(long id) throws Exception;

    void stopConnector(long id) throws Exception;

    void destroyConnector(long id) throws Exception;

    long createConnector(String type, String namespace) throws Exception;

    void removeConnector(long id) throws Exception;

}
