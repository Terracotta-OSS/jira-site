package test;

public class ConnectorService implements IConnectorService {
    public void startConnector(long id) throws Exception {
        System.out.println("Start " + id);
    }

    public void stopConnector(long id) throws Exception {
        System.out.println("Stop " + id);
    }

    public void destroyConnector(long id) throws Exception {
        System.out.println("Destroy " + id);
    }

    public long createConnector(String type, String namespace) throws Exception {
        System.out.println("Create " + type + "," + namespace);
        return 1;
    }

    public void removeConnector(long id) throws Exception {
        System.out.println("Remove " + id);
        destroyConnector(id);
    }
}
