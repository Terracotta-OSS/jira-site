package simple.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SimpleDomain implements Serializable {

	private Map<Integer, Integer> visitCounts = new ConcurrentHashMap<Integer, Integer>();
	
	public void add(int k, int v) {
		visitCounts.put(k, v);
	}
	
	public Collection<Integer> getVisits() {
		ArrayList<Integer> list = new ArrayList<Integer>(visitCounts.values());
		Collections.sort(list);
		return list;
	}

	public void increment() {
		add(visitCounts.size(), visitCounts.size());
	}
}
