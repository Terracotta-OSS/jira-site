package simple.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import simple.domain.SimpleDomain;

public class SimpleService {
	
	private Map<Integer, SimpleDomain> visitCounts = new ConcurrentHashMap<Integer, SimpleDomain>();
	
	public SimpleDomain visit() {
		SimpleDomain simpleDomain = visitCounts.get(1);
		if (simpleDomain == null) {
			simpleDomain = new SimpleDomain();
			visitCounts.put(1, simpleDomain);
		}
		simpleDomain.increment();
		return simpleDomain;
	}

}
