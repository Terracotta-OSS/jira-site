package test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.Properties;
import java.util.UUID;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.xml.DOMConfigurator;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

/**
 * Servlet implementation class Test
 */
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public void init(ServletConfig config) throws ServletException {
		DOMConfigurator.configure(
				config.getServletContext().getRealPath("WEB-INF/log4j.xml"));
    	
    	super.init(config);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String schedulerName = UUID.randomUUID().toString();
			String schedulerId = UUID.randomUUID().toString();
			
			Properties properties = new Properties();
			properties.setProperty("org.quartz.scheduler.instanceName", schedulerName);
			properties.setProperty("org.quartz.scheduler.instanceId", schedulerId);
			properties.setProperty("org.quartz.threadPool.class", "org.quartz.simpl.SimpleThreadPool");
			properties.setProperty("org.quartz.jobStore.class", "org.quartz.simpl.RAMJobStore");
			properties.setProperty("org.quartz.threadPool.threadCount", "10");
			properties.setProperty("org.quartz.threadPool.threadPriority", "5");
			properties.setProperty("org.quartz.jobStore.misfireThreshold", "1000");
	
			StdSchedulerFactory schedulerFactory = new StdSchedulerFactory(properties);
			Scheduler scheduler = schedulerFactory.getScheduler();
			
			JobDetail jobDetail = new JobDetail("myJob", Scheduler.DEFAULT_GROUP, DummyJob.class);
			jobDetail.setRequestsRecovery(true);
			jobDetail.setDurability(true);
			
			CronTrigger trigger = new CronTrigger();
			trigger.setCronExpression("0/5 * * * * ?");
			trigger.setName("myTrigger");
			trigger.setJobName("myJob");
			trigger.setGroup(Scheduler.DEFAULT_GROUP);
			trigger.setMisfireInstruction(CronTrigger.MISFIRE_INSTRUCTION_DO_NOTHING);
			
			scheduler.start();
			
			if (scheduler.getJobDetail("myJob", Scheduler.DEFAULT_GROUP) == null) {
				scheduler.scheduleJob(jobDetail, trigger);
				System.out.println("Job Detail was null");
			} else {
				scheduler.rescheduleJob("myTrigger", Scheduler.DEFAULT_GROUP, trigger);
				System.out.println("Job Detail was NOT null");
			}
	
			System.out.println("Fdsafdssfd");
			Thread.sleep(300000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
