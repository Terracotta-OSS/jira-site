package test;

import java.text.ParseException;
import java.util.Properties;
import java.util.UUID;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			String schedulerName = UUID.randomUUID().toString();
			String schedulerId = UUID.randomUUID().toString();
			
			Properties properties = new Properties();
			properties.setProperty("org.quartz.scheduler.instanceName", schedulerName);
			properties.setProperty("org.quartz.scheduler.instanceId", schedulerId);
			properties.setProperty("org.quartz.threadPool.class", "org.quartz.simpl.SimpleThreadPool");
			properties.setProperty("org.quartz.jobStore.class", "org.quartz.simpl.RAMJobStore");
			properties.setProperty("org.quartz.threadPool.threadCount", "10");
			properties.setProperty("org.quartz.threadPool.threadPriority", "5");
			properties.setProperty("org.quartz.jobStore.misfireThreshold", "1000");
	
			StdSchedulerFactory schedulerFactory = new StdSchedulerFactory(properties);
			Scheduler scheduler = schedulerFactory.getScheduler();
			
			JobDetail jobDetail = new JobDetail("myJob", Scheduler.DEFAULT_GROUP, DummyJob.class);
			jobDetail.setRequestsRecovery(true);
			jobDetail.setDurability(true);
			
			CronTrigger trigger = new CronTrigger();
			trigger.setCronExpression("0/5 * * * * ?");
			trigger.setName("myTrigger");
			trigger.setJobName("myJob");
			trigger.setGroup(Scheduler.DEFAULT_GROUP);
			trigger.setMisfireInstruction(CronTrigger.MISFIRE_INSTRUCTION_DO_NOTHING);
			
			scheduler.start();
			
			if (scheduler.getJobDetail("myJob", Scheduler.DEFAULT_GROUP) == null) {
				System.out.println("Job Detail was null");
				scheduler.scheduleJob(jobDetail, trigger);
			} else {
				System.out.println("Job Detail was NOT null");
				scheduler.rescheduleJob("myTrigger", Scheduler.DEFAULT_GROUP, trigger);
			}
	
			System.out.println("Fdsafdssfd");
			Thread.sleep(300000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
