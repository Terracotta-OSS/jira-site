package test;
 
import java.util.Date;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
 
 public class DummyJob implements Job {
 
	private static final Logger logger = Logger.getLogger(DummyJob.class);
	
// 	@Override
 	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
 		logger.info("Executed!");
 		System.out.println("Excecuted at :"+new Date());
 	}
 
 }
