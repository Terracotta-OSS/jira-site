package test;

public class B extends A {

	private final Object field;

	public Object getField() {
		return field;
	}

	public B(Object o) {
		this.field = o;
	}

}
