package test;

public class Main {

	public static void main(String[] args) {
		B b = new B(new Object());
		System.err.println(b);
	}
}
