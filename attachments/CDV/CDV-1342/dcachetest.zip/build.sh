CLASSPATH=bin
CLASSPATH=/Users/amiller/Work/code/forge/projects/tim-distributed-cache/branches/tc-3.1/tim-distributed-cache/target/tim-distributed-cache-1.2.0-SNAPSHOT.jar

javac -cp $CLASSPATH src/dcachetest/*.java -d bin
