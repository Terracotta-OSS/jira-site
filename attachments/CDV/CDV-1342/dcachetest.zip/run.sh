CLASSPATH=bin
CLASSPATH=$CLASSPATH:/Users/amiller/Work/code/forge/projects/tim-distributed-cache/branches/tc-3.1/tim-distributed-cache/target/tim-distributed-cache-1.2.0-SNAPSHOT.jar
CLASSPATH=$CLASSPATH:/Users/amiller/Work/code/forge/projects/aggregate/tc-3.1/tim-concurrent-collections/tim-concurrent-collections/target/tim-concurrent-collections-1.2.0-SNAPSHOT.jar

dso-java.sh -cp $CLASSPATH dcachetest.Main $*
