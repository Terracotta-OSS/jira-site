Introduction:
=============================
The purpose of this document is to describe the problems being encountered at
Shine Technologies with our use of the Terracotta Server, and to outline the
contents of the zipped folder that contains this file.


The Problem:
=============================
A client of Shine Technologies is experiencing OutOfMemory issues in the TCServer 
with their installation of terracotta. They are running an application that 
was designed by Shine Technologies using the Master / Worker pattern.

I have tried to replicate the problem here at Shine HQ, but have not been able to
get the Terracotta Server to actually fail with an OutOfMemoryError.

However, the memory usage of the Terracotta Server does seem to grow over time
(see "memory usage.xls" spreadsheet) and at some point in time, the Terracotta
Server appears to no longer accept connections from Clients.

Here is a more detailed description of exactly what is happening...

(1) The Terracotta Server is started by issuing the following command from the
    bin directory...

    nohup ./start-tc-server.sh &

(2) The MemoryAnalyser (which produced the usage figures for the "memory usage.xls"
    spreadsheet) is started by issuing the following command from the
    bin directory...

    nohup ./batch_run.sh start-MRS-MemoryAnalyzer.sh &

(3) A cron task is scheduled to run the start-MRS-MeterDataWorkWorkRecognizer.sh
    Terracotta client every minute (see mrs.cron file in bin directory)

(4) The application is then left to run, and after a number of days (approx 3 to 4)
    the Terracotta Server appears to no longer accept any client connections.
    This in turn causes memory problems on the actual physical machine on which this
    is running as the cron continues to fire off client tasks every minute, 
    that cannot connect.

That in essence is the problem. I am hoping that if we can rectify my problem here, then 
that will translate to the same issues that our client is experiencing.

What I would like to know is....

(1) Can you reproduce the problem that I am experiencing?
(2) Is there a problem with the Terracotta Server, or have I coded or configured something
    incorrectly?
(3) Is there a configurable way to have a Terracotta client terminate itself if it fails to 
    connect to the Terracotta Server after a certain number of attempts or elapsed time, or
    is this something that I would need to be code?



The Contents:
=============================
README.txt
=== Description of problem and contents of zip file

memory usage.xls
=== Spreadsheet showing the memory usage of the Terracotta Server as erported by
    the MemoryAnalyser.

bin.tar.gz
=== Contains the Terracotta bin directory from our Terracotta
    installation. Details of the contents of this file are as follows...

bin/start-tc-server.sh
=== Script used to start the Terracotta server.

bin/start-MRS-MemoryAnalyzer.sh
=== Script used to start the MemoryAnalyser

bin/start-MRS-MeterDataWorkWorkRecognizer.sh
=== Script used to start the Terracotta client task

bin/tc-config.xml
=== Terracotta config file

bin/mrs.cron
=== File containing details of the cron task used to run our Terracotta client every
    minute.

bin/logs/start-MRS-MeterDataWorkWorkRecognizer.sh.log.20071118034001.30308
=== Log file for the last successful run of our Terracotta client

bin/logs/start-MRS-MeterDataWorkWorkRecognizer.sh.log.20071118034101.30387
=== Log file for the first unsuccessful run of our Terracotta client

bin/logs/terracotta-server.log
=== Log file for the Terracotta server

bin/logs/start-MRS-MemoryAnalyzer.sh.log.20071116062358.6653
=== Output of the MemoryAnalyser. Note, the exception at the top of this
    log file is that thrown at the point in time when the MemoryAnalyser
    fails to getUsage from the MemoryPoolMXBean's (see line 74 in 
    MemoryAnalyser).

bin/mrs/MRST.jar
=== Contains the java class and source files of the sample application.
