package com.terracottatest;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class SerializationTest {
	
	public static void main(String[] args) {
		
		try {
            System.out.println("Creating File/Object output stream...");
            FileOutputStream fileOut = new FileOutputStream("DataTypesTEST.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            System.out.println("Writing DataTypes.Enum Object...");
            out.writeObject(DataTypes.TEST);

            System.out.println("Closing all output streams...\n");
            out.close();
            fileOut.close();
            
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
