package com.terracottatest;

import java.io.Serializable;

public abstract class DataTypes implements Serializable {
	
	private DataTypes(int id, String name) {
    }
	
	public static final DataTypes TEST = new DataTypes(8, "TEST") {

        public Object convert(Object object) {
            return object;
        }

        public final boolean isCode() {
            return true;
        }
    };

}
