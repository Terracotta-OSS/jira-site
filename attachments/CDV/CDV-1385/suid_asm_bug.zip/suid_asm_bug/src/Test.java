import java.io.Serializable;

public abstract class Test implements Serializable {	
	public static final Test TEST = new Test() {};
}
