#!/bin/bash

echo "Cleaning Test Area..."
rm -f SerialTest.class ./src/*.class

echo "Compiling Test Class..."
${1}/bin/javac -classpath "./src/" src/Test.java
echo "Compiling Driver Class..."
${1}/bin/javac -classpath "asm-all-3.2.jar:./" SerialTest.java

echo "Running Test"
${1}/bin/java -classpath "asm-all-3.2.jar:./:./src/" SerialTest Test\$1
${1}/bin/serialver -classpath "./src/" Test\$1

echo "Cleaning Test Area..."
rm -f SerialTest.class ./src/*.class
