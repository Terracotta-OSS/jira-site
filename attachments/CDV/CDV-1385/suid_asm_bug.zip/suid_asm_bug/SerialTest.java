import org.objectweb.asm.ClassReader;
import org.objectweb.asm.commons.SerialVersionUIDAdder;
import org.objectweb.asm.util.TraceClassVisitor;

import java.io.PrintWriter;

public class SerialTest {
  public static void main(String[] args) throws Exception {
    ClassReader reader = new ClassReader(args[0]);
    SerialVersionUIDAdder adapter = new SerialVersionUIDAdder(new TraceClassVisitor(new PrintWriter(System.out)));
    reader.accept(adapter, 0);    
  }
}