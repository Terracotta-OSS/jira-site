package com.accenture.grids.al;

import com.accenture.grids.utils.Rand;

import java.util.LinkedList;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Initial Version by: arie.golos
 * Date: Sep 29, 2008
 * Time: 4:21:21 PM
 */
public class Scheduler extends Thread {

    private class EventRunnerThread extends Thread
    {
        private int threadId;
        private EventRunnerThread(int threadId)
        {
            setDaemon(true);
            this.threadId = threadId;
        }
        public void run() {
            try {
                while (true) {
                    sequencer.internalPhaseStart();
                    while (true) {
                       EventContext ec = removeEvent(timeTick);
                       if (ec != null) {
                            try {
                                ec.processEvent(threadId);
                            }
                            catch(Exception ex) {
                                ex.printStackTrace();
                            }
                            eventsProcessed.addAndGet(1);
                        }
                        else {
                            break;
                        }
                    }
                    sequencer.internalPhaseEnd();
                }
            }
            catch(Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private static ObjectFactory objectFactory;
    private int             timeTick;
    private long            eventsGenerated;
    private AtomicLong      eventsProcessed;
    private AtomicLong      remoteObjectsProcessed;
    private Sequencer       sequencer;
    private final TreeMap<Integer, LinkedList<EventContext>> eventMap;

    public Scheduler()
    {
        objectFactory = Config.getFactoryFromFactoryAlias(System.getProperty("object.factory.alias"));
        eventMap = new TreeMap<Integer, LinkedList<EventContext>>();
        sequencer = objectFactory.getSequencerInstance();
        eventsProcessed = new AtomicLong(0);
        remoteObjectsProcessed = new AtomicLong(0);
    }

    public void run()
    {

        RunParameters   rp = sequencer.getRunParameters();
        for(int i=0; i< rp.getMaxWorkersPerJvm();++i) {
            new EventRunnerThread(i).start();
        }
        long timeStart = System.currentTimeMillis();
        long oldRemObjects = 0;
        long processedEvents = 0;
        long oldEventsGenerated = 0;
        while(true) {
            sequencer.externalPhaseStart();
            if (timeTick%rp.getTimeTicksPerReport() == 0) {
//                int eventsQueueLength = 0;
                long newProcessedEvents = eventsProcessed.get();
//                for (LinkedList<EventContext> list : eventMap.values()) {
//                    eventsQueueLength += list.size();
//                }
//                System.out.println(String.format("Time tick: %d    Event queue size: %d", timeTick,eventsQueueLength));
//                System.out.println(String.format("Events Generated: %d    Events processed: %d", eventsGenerated - oldEventsGenerated, newProcessedEvents - processedEvents));
                long currentTime = System.currentTimeMillis();
                long processingTime = currentTime - timeStart;
                if(processingTime > 0) {
//                    System.out.println(String.format("Events processed per second: %d",  1000*(newProcessedEvents-processedEvents)/processingTime));
                    long newRemObjects = remoteObjectsProcessed.get();
//                    System.out.println(String.format("Remote objects generated per second: %f ",  1000D*(newRemObjects - oldRemObjects)/processingTime));
                    Stats.Record r = new Stats.Record(timeTick, (int)processingTime,
                            (int) (newProcessedEvents-processedEvents),
                            (int) (eventsGenerated - oldEventsGenerated), (int) (newRemObjects - oldRemObjects));
                    {
                    System.out.println(String.format("Tick interval: %7.3f    Processed Events: %7.2f  Events per millisecond: %f",
                            (double) processingTime/rp.getTimeTicksPerReport(),
                            (double) (newProcessedEvents-processedEvents)/rp.getTimeTicksPerReport(),
                            (double) (newProcessedEvents-processedEvents)/processingTime
                            ));
                    }
                    Stats.getInstance().addRecord(r, sequencer.getJvmIndex());
                    Stats.getInstance().newData(sequencer.getJvmIndex());
                    oldRemObjects = newRemObjects;
                    timeStart = currentTime;
                    processedEvents = newProcessedEvents;
                    oldEventsGenerated = eventsGenerated;
                }
            }
            timeTick++;
            sequencer.externalPhaseEnd();
            generateEvents();
        }
    }
    public int getJvmIndex()
    {
        return sequencer.getJvmIndex();
    }
    private void addEvent(Integer key, EventContext ec)
    {
        synchronized(eventMap) {
            LinkedList<EventContext> ll = eventMap.get(key);
            if (ll == null) {
                ll = new LinkedList<EventContext>();
                eventMap.put(key, ll);
            }
            ll.add(ec);
        }
    }
    private EventContext removeEvent(Integer key)
    {
        synchronized(eventMap) {
            LinkedList<EventContext> ll = eventMap.get(key);
            if(ll == null) return null;
            if (ll.size() != 0) {
                return ll.removeFirst();
            }
            if (ll.size() == 0) {
                eventMap.remove(key);
            }
            return null;
        }
    }
    private void generateEvents()
    {
        RunParameters   rp = sequencer.getRunParameters();
        int timeToRunAvg = rp.getAvgEventProcessingTime();
        int numEvents = Rand.getExponentValue(rp.getEventsExpMedian());
        int partSize = rp.getMaxObjects()/rp.getNumJvms();
        int jvmNumber = sequencer.getJvmIndex();
        int localObjectsStart = partSize*jvmNumber;
        int localObjectsEnd = localObjectsStart+partSize;
        for (int e=0; e<numEvents; ++e) {
            int objectMedian = jvmNumber * partSize + Rand.getNextInt(rp.getMaxObjects()/rp.getNumJvms());
            int numObjects = Rand.getExponentValue(rp.getObjectsPerEventExpMedian());
            OperationDescriptor[] descs = new OperationDescriptor[numObjects];
            for (int o=0; o<numObjects; ++o) {
                int objectId;
                boolean duplicateFound;
                do {
                    double d = Rand.nextDouble();
                    if (d > rp.getProbabilityOfRemoteObject() || rp.getNumJvms() == 1) {
                        objectId = Rand.getGaussianValue(objectMedian, rp.getGaussSigma(), localObjectsStart, localObjectsEnd);
                    }
                    else {
                        do {
                            objectId = Rand.getNextInt(rp.getMaxObjects());
                        }
                        while (objectId >= localObjectsStart && objectId < localObjectsEnd);
                        remoteObjectsProcessed.incrementAndGet();
                    }
                    duplicateFound = false;
                    for (int t=0; t<o; ++t) {
                        if (descs[t].getId() == objectId) {
                            duplicateFound = true;
                            break;
                        }
                    }
                } while (duplicateFound);
                
                double rand = Rand.nextDouble();
                Operation op;
                if( rand < rp.getProbabilityOfReadMax()) {
                    op = Operation.READ_OP;
                }
                else if ( rand < rp.getProbabilityOfWriteMax()) {
                    op = Operation.WRITE_OP;
                }
                else {
                    op = Operation.DELETE_OP;
                }
                descs[o] = objectFactory.createOperationDescriptor(objectId, op);
            }
            int eventTime = timeTick+1+Rand.getExponentValue(rp.getTimeExpMedian());
            EventContext ec = objectFactory.createEventContext(descs, eventTime, timeToRunAvg);
            synchronized(eventMap) {
                addEvent(eventTime, ec);
            }
        }
        eventsGenerated += numEvents;
    }
}
