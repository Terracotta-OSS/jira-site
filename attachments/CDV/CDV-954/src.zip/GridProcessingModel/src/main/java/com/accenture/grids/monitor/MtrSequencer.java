package com.accenture.grids.monitor;

import com.accenture.grids.al.Sequencer;
import com.accenture.grids.al.Config;
import com.accenture.grids.al.RunParameters;

import java.util.concurrent.CyclicBarrier;

/**
 * Initial Version by: arie.golos
 * Date: Oct 15, 2008
 * Time: 9:04:26 AM
 */
class MtrSequencer extends Sequencer
{
    public MtrSequencer()
    {
    }
    public int getJvmIndex()
    {
        return jvmIndex;
    }
    protected void reserveJvmIndex() {
    }
    public void internalPhaseStart()
    {
    }
    public void internalPhaseEnd()
    {
    }
    public void externalPhaseStart()
    {
    }
    public void externalPhaseEnd()
    {
    }
    public RunParameters getRunParameters()
    {
        return runParameters;
    }

}
