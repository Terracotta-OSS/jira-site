package com.accenture.grids.al;

import com.accenture.grids.utils.Rand;

/**
 * Initial Version by: arie.golos
 * Date: Sep 22, 2008
 * Time: 1:05:05 PM
 */
public abstract class DataObject {

    protected Integer id;         // The ID of this object
    protected int[] userData;   // List of user data

    protected DataObject(int id) {
        this.id = id;
        this.userData = new int[Config.getUserAreaSize()];
    }
    protected DataObject()
    {}
    public Integer getId() {
        return id;
    }

    public int[] getUserData() {
        return userData;
    }

    public void performBusinessComputation(Operation mode) {
        long timeStart = System.currentTimeMillis();
        int numItems = Rand.getNextInt(userData.length);
        int temp = 0;
        switch (mode) {
            case READ_OP: {
                for (int i = 0; i < numItems; ++i) {
                    temp += userData[i];
                }
                break;
            }
            case WRITE_OP: {
                for (int i = 0; i < numItems; ++i) {
                    userData[i]++;
                }
                break;
            }
            default:
                break;
        }
    }
}
