package com.accenture.grids.terra;

import com.accenture.grids.al.DataObject;
import com.accenture.grids.al.Sequencer;

import java.util.ArrayList;
import java.util.concurrent.*;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 2:32:36 PM
 */
public class TerraSequencer extends Sequencer implements Runnable{
    public static final int LOCK_AND_GET = 0;
    public static final int LOCK = 1;
    public static final int UNLOCK = 2;
    public static final int UPDATE_AND_UNLOCK = 3;
    public static final int DELETE = 4;

    public static class Request {
        public synchronized void setup(int requestId, int objectId)
        {
            this.requestId = requestId;
            this.objectId = objectId;
            this.completed = false;
        }
        public synchronized void setup(int requestId, int objectId, DataObject dto)
        {
            this.requestId = requestId;
            this.objectId = objectId;
            this.dataObject = dto;
            this.completed = false;
        }
        public synchronized boolean isCompleted()
        {
            return completed;
        }

        public synchronized void setCompleted(boolean completed) {
            this.completed = completed;
        }

        public synchronized int getObjectId() {
            return objectId;
        }

        public synchronized int getRequestId() {
            return requestId;
        }

        public synchronized DataObject getDataObject() {
            return dataObject;
        }

        public synchronized void setDataObject(DataObject dataObject) {
            this.dataObject = dataObject;
        }

        private boolean    completed;
        private int        requestId;
        private int        objectId;
        private DataObject dataObject;
    }

    public static class RequestRunner implements Runnable {
        private Request req;

        public RequestRunner(Request req) {
            this.req = req;
        }

        public void run() {
            synchronized (req) {
                int requestId = req.getRequestId();
                //System.out.println("Received request for ID "+req.getObjectId());
                switch (requestId) {
                    case LOCK_AND_GET: {
                        req.setDataObject(getJvmCacheInstance().lockAndGet(req.getObjectId()));
                        break;
                    }
                    case LOCK: {
                        getJvmCacheInstance().lock(req.getObjectId());
                        break;
                    }
                    case UPDATE_AND_UNLOCK: {
                        getJvmCacheInstance().updateAndUnlock(req.getDataObject());
                        break;
                    }
                    case UNLOCK: {
                        getJvmCacheInstance().unlock(req.getObjectId());
                        break;

                    }
                    case DELETE: {
                        getJvmCacheInstance().delete(req.getObjectId());
                        req.setDataObject(null);
                        break;

                    }
                    default:
                        System.err.println("Invalid request value");
                }
                req.setCompleted(true);
                //System.out.println("Notifying on ID "+req.getObjectId());
                req.notifyAll();

            }

        }
    }

    private final Executor executor = new ThreadPoolExecutor(16,  // Core pool size
            Math.max(getRunParameters().getNumJvms()*(getRunParameters().getMaxWorkersPerJvm()+1), 16),       //maximumPoolSize (+1 just in case I did not think of something)
            60,
            TimeUnit.SECONDS,
            new LinkedBlockingQueue<Runnable>());


    private static TerraSequencer root = new TerraSequencer();

    public static TerraSequencer getInstance() {
        return root;
    }

    public static TerraJvmCache getJvmCacheInstance() {
        return root.jvmCache;
    }

    private final ArrayList<BlockingQueue<Request>> inputQueues = new ArrayList<BlockingQueue<Request>>();
    private final Request[] requests = new Request[getRunParameters().getNumJvms()*getRunParameters().getMaxWorkersPerJvm()];
    private TerraJvmCache jvmCache;


    private TerraSequencer() {
        synchronized (inputQueues) {
            for (int i = 0; i < getRunParameters().getNumJvms(); ++i) {
                inputQueues.add(new LinkedBlockingQueue<Request>());
            }
        }
        synchronized (requests) {
            for (int i = 0; i < requests.length; ++i) {
                requests[i] = new Request();
            }
        }
        jvmCache = new TerraJvmCache(getJvmIndex());
        new Thread(this).start();
    }
    public void run()
    {
        while(true) {
            BlockingQueue<Request> reqQueue = inputQueues.get(getJvmIndex());
            Request req = null;
            try {
                req = reqQueue.take();
//                synchronized(req) {
//                    System.out.println("Received request for ID: "+req.getObjectId()+" request ID "+req.getRequestId());
//                }
            }
            catch (InterruptedException ex) {
                // Should not happen
            }
            executor.execute(new RequestRunner(req));
        }
    }
    DataObject lockAndGet(int id, int threadId) {

        DataObject ret = jvmCache.lockAndGet(id);
        if (ret == null) {
            Request req = requests[threadId+getRunParameters().getMaxWorkersPerJvm()*jvmIndex];
            req.setup(LOCK_AND_GET, id);
            BlockingQueue<Request> reqQueue = inputQueues.get(getRunParameters().idToJvmIndex(id));
            sendAndWait(reqQueue, req);
            return req.getDataObject();
        } else {
            return ret;
        }

    }

    void lock(int id, int threadId) {
        int ret = jvmCache.lock(id);
        if (ret == -1) {
            BlockingQueue<Request> reqQueue = inputQueues.get(getRunParameters().idToJvmIndex(id));
            Request req = requests[threadId+getRunParameters().getMaxWorkersPerJvm()*jvmIndex];
            req.setup(LOCK, id);
            sendAndWait(reqQueue, req);
        }
    }

    void unlock(int id, int threadId) {
        int ret = jvmCache.unlock(id);
        if (ret == -1) {
            BlockingQueue<Request> reqQueue = inputQueues.get(getRunParameters().idToJvmIndex(id));
            Request req = requests[threadId+getRunParameters().getMaxWorkersPerJvm()*jvmIndex];
            req.setup(UNLOCK, id);
            sendAndWait(reqQueue, req);
        }
    }

    void updateAndUnlock(DataObject dataObject, int threadId) {
        int ret = jvmCache.updateAndUnlock(dataObject);
        if (ret == -1) {
            BlockingQueue<Request> reqQueue = inputQueues.get(getRunParameters().idToJvmIndex(dataObject.getId()));
            Request req = requests[threadId+getRunParameters().getMaxWorkersPerJvm()*jvmIndex];
            req.setup(UPDATE_AND_UNLOCK, dataObject.getId(), dataObject);
            sendAndWait(reqQueue, req);
        }
    }

    void delete(int id, int threadId) {
        int ret = jvmCache.delete(id);
        if (ret == -1) {
            BlockingQueue<Request> reqQueue = inputQueues.get(getRunParameters().idToJvmIndex(id));
            Request req = requests[threadId+getRunParameters().getMaxWorkersPerJvm()*jvmIndex];
            req.setup(DELETE, id);
            sendAndWait(reqQueue, req);
        }
    }

    private void sendAndWait(BlockingQueue<Request> reqQueue, Request req) {
        try {
            reqQueue.put(req);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace(System.out);
        }

        long tm1 = System.currentTimeMillis(), tm2;
        synchronized (req) {
//            System.out.println("Request put on the queueu ID "+req.getObjectId()+"  request ID "+req.getRequestId());
            int count = 0;
            while( !req.isCompleted())  {
                try {
                    //tm1=System.currentTimeMillis();
                    req.wait(100);        // Wait on remote completion
                    //System.out.println("Out of wait on ID "+id);

                }
                catch (InterruptedException ex) {
                    System.out.println("Interrupted for ID "+req.getObjectId());
                }
                if (!req.isCompleted() && ((++count)%1000==0)) {
                    System.out.println("Request not completed normally for ID "+req.getObjectId()+" request ID "+req.getRequestId());
                }
            }
        }
        tm2 = System.currentTimeMillis();
        if (tm2 - tm1 > 5000) {
            System.out.println("Wait time is "+(tm2-tm1));
        }
        
    }
}
