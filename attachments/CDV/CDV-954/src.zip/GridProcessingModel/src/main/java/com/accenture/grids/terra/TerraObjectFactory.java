package com.accenture.grids.terra;

import com.accenture.grids.al.*;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 9:48:26 AM
 */
public class TerraObjectFactory implements ObjectFactory {
    public EventContext createEventContext(OperationDescriptor[] nodeOps, int timeTick,  int timeToRunAvg) {
        return new TerraEventContext(nodeOps, timeTick, timeToRunAvg);  
    }
    public OperationDescriptor createOperationDescriptor(int id, Operation operation) {
        return new TerraOperationDescriptor(id, operation);
    }
    public Sequencer getSequencerInstance() {
        return TerraSequencer.getInstance();
    }
}
