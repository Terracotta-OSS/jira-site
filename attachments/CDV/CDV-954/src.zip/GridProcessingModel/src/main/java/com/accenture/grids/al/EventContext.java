package com.accenture.grids.al;

/**
 * Initial Version by: arie.golos
 * Date: Sep 22, 2008
 * Time: 12:57:15 PM
 */
public abstract class EventContext {
    protected OperationDescriptor[]     descs;
    protected int                       timeTick;     // Virtual time tick of this event
    protected int                       timeToRunAvg;

    protected EventContext(OperationDescriptor[] descs, int timeTick, int timeToRunAvg)
    {
        this.timeTick = timeTick;
//        this.descs = new OperationDescriptor[descs.length];
//        System.arraycopy(descs, 0, this.descs, 0, descs.length);
        this.descs = descs;
        this.timeToRunAvg = timeToRunAvg;
    }
    public int getTimeTick() {
        return timeTick;
    }

    public abstract void processEvent(int threadId);
    
}
