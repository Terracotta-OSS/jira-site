import com.accenture.grids.utils.Rand;

/**
 * Initial Version by: arie.golos
 * Date: Oct 9, 2008
 * Time: 7:43:15 AM
 */
public class GaussTest {

    public static void main(String[] args)
    {
        double[] nums = new double[64];
        for(int i=0; i<1000000; ++i) {
            int objectMedian = 3000 + Rand.getNextInt(3000);
            int objectId = Rand.getGaussianValue(objectMedian, 300, 0, 12000);
            ++nums[objectId/250];
        }

        double sum = 0;
        for(double d : nums) {
            sum += d;
        }
        for (int i=0; i<nums.length; ++i) {
            nums[i] /= sum;
            System.out.println(String.format("%05d\t%f", i*250, nums[i]));
        }
    }
}
