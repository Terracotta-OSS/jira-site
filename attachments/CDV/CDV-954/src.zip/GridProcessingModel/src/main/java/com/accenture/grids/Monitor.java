package com.accenture.grids;

import com.accenture.grids.al.Scheduler;
import com.accenture.grids.al.Stats;
import com.accenture.grids.monitor.MainFrame;

import java.util.LinkedList;
import java.util.List;

/**
 * Initial Version by: arie.golos
 * Date: Oct 1, 2008
 * Time: 2:29:14 PM
 */
public class Monitor extends Scheduler
{
    public Monitor()
    {
    }
    public static void main(String[] args)
    {
        try {
            MainFrame tm = new MainFrame();
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
    }

}