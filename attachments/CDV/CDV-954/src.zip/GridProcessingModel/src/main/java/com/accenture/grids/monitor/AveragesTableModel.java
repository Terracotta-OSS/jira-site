package com.accenture.grids.monitor;

import com.accenture.grids.al.Stats;

import javax.swing.table.DefaultTableModel;
import java.util.LinkedList;

/**
 * Initial Version by: arie.golos
 * Date: Oct 14, 2008
 * Time: 4:54:57 PM
 */
class AveragesTableModel extends DefaultTableModel  {

    private static String[] HEADERS = {
            "JVM Name / Total",
            "Time Interval (ms)",
            "Events Generated (1/sec)",
            "Events Processed (1/sec)",
            "Remote Objects (1/sec)" };

    private final String[][]      values;
    private final int             numJvms;
    private final LinkedList[]    timeTickTime;
    private final LinkedList[]    eventsGenerated;
    private final LinkedList[]    eventsProcessed;
    private final LinkedList[]    remoteObjects;
    private static final int  MAX_LIST_SIZE = 200;
    static synchronized AveragesTableModel getInstance()
    {
        if(instance == null) {
            instance = new AveragesTableModel();
        }
        return instance;
    }
    private static AveragesTableModel   instance;
    private AveragesTableModel()
    {

        numJvms = ParamsModel.getInstance().getNumJvms();
        timeTickTime = new LinkedList[numJvms];
        eventsGenerated = new LinkedList[numJvms];
        eventsProcessed = new LinkedList[numJvms];
        remoteObjects = new LinkedList[numJvms];
        for(int i=0; i<numJvms; ++i) {
            timeTickTime[i] = new LinkedList();
            eventsGenerated[i] = new LinkedList();
            eventsProcessed[i] = new LinkedList();
            remoteObjects[i] = new LinkedList();
        }
        values = new String[numJvms+1][HEADERS.length];
        for(String[] vs : values) {
            for(int i = 0; i<vs.length; ++i) {
                vs[i] = "";
            }
        }
    }
    public int getRowCount() {
        return (numJvms+1);
    }

    public int getColumnCount() {
        return HEADERS.length;
    }

    public String getColumnName(int columnIndex) {
        return HEADERS[columnIndex];
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        return values[rowIndex][columnIndex];
    }

    private int updateCounter;
    public synchronized void newData(int jvmIndex, String name, Stats.Record r) {
        timeTickTime[jvmIndex].add((double)r.getTimeInterval());
        eventsGenerated[jvmIndex].add((double)r.getEventsGenerated());
        eventsProcessed[jvmIndex].add((double)r.getEventsProcessed());
        remoteObjects[jvmIndex].add((double)r.getRemoteObjectsRefs());
        if (timeTickTime[jvmIndex].size() == MAX_LIST_SIZE) {
            timeTickTime[jvmIndex].removeFirst();
            eventsGenerated[jvmIndex].removeFirst();
            eventsProcessed[jvmIndex].removeFirst();
            remoteObjects[jvmIndex].removeFirst();
        }
        values[jvmIndex][0] = name;
        if(++updateCounter == numJvms) {
            updateCounter = 0;
            values[numJvms][0] = "Total";
            computeValues();
            fireTableDataChanged();
        }
    }
    private void computeValues()
    {
        int ticksPerReport = ParamsModel.getInstance().getTimeTicksPerReport();
        int numReadings = timeTickTime[0].size();
        if (numReadings == 0) return;
        double totTimeTickTime = 0, totEventsGenerated = 0,
                totEventsProcessed = 0, totRemoteObjects = 0;
        double totStdTimeTickTime = 0, totStdEventsGenerated = 0,
                totStdEventsProcessed = 0, totStdRemoteObjects = 0;
        double avTimeTickTime[] = new double[numJvms], avEventsGenerated[] = new double[numJvms],
                avEventsProcessed[] = new double[numJvms], avRemoteObjects[] = new double[numJvms];
        double stdTimeTickTime[] = new double[numJvms], stdEventsGenerated[] = new double[numJvms],
                stdEventsProcessed[] = new double[numJvms], stdRemoteObjects[] = new double[numJvms];
        for(int i=0; i<numJvms; ++i) {
            for(Object o : timeTickTime[i]) {
                avTimeTickTime[i] += (Double) o;
            }
            avTimeTickTime[i] /= numReadings;
            for(Object o : eventsGenerated[i]) {
                avEventsGenerated[i] += (Double) o;
            }
            avEventsGenerated[i] /= numReadings;
            for(Object o : eventsProcessed[i]) {
                avEventsProcessed[i] += (Double) o;
            }
            avEventsProcessed[i] /= numReadings;
            for(Object o : remoteObjects[i]) {
                avRemoteObjects[i] += (Double) o;
            }
            avRemoteObjects[i] /= numReadings;
        }
        for(int i=0; i<numJvms; ++i) {
            for(Object o : timeTickTime[i]) {
                double v = (Double) o - avTimeTickTime[i];
                stdTimeTickTime[i] += v * v ;
            }
            stdTimeTickTime[i] /= numReadings;
            stdTimeTickTime[i] = Math.sqrt(stdTimeTickTime[i]);
            for(Object o : eventsGenerated[i]) {
                double v = (Double) o - avEventsGenerated[i];
                stdEventsGenerated[i] += v * v ;
            }
            stdEventsGenerated[i] /= numReadings;
            stdEventsGenerated[i] = Math.sqrt(stdEventsGenerated[i]);
            for(Object o : eventsProcessed[i]) {
                double v = (Double) o - avEventsProcessed[i];
                stdEventsProcessed[i] += v * v ;
            }
            stdEventsProcessed[i] /= numReadings;
            stdEventsProcessed[i] = Math.sqrt(stdEventsProcessed[i]);
            for(Object o : remoteObjects[i]) {
                double v = (Double) o - avRemoteObjects[i];
                stdRemoteObjects[i] += v * v ;
            }
            stdRemoteObjects[i] /= numReadings;
            stdRemoteObjects[i] = Math.sqrt(stdRemoteObjects[i]);
        }
        for(int i=0; i<numJvms; ++i) {
            double factor = avTimeTickTime[i] / 1000;
            values[i][1] = String.format("%8.2f  / %8.2f", avTimeTickTime[i]/ticksPerReport, stdTimeTickTime[i]/ticksPerReport);
            values[i][2] = String.format("%8.2f  / %8.2f", avEventsGenerated[i]/factor, stdEventsGenerated[i]/factor);
            values[i][3] = String.format("%8.2f  / %8.2f", avEventsProcessed[i]/factor, stdEventsProcessed[i]/factor);
            values[i][4] = String.format("%8.2f  / %8.2f", avRemoteObjects[i]/factor, stdRemoteObjects[i]/factor);
            totTimeTickTime += avTimeTickTime[i];
            totEventsGenerated += avEventsGenerated[i];
            totEventsProcessed += avEventsProcessed[i];
            totRemoteObjects += avRemoteObjects[i];
            totStdTimeTickTime += stdTimeTickTime[i]*stdTimeTickTime[i];
            totStdEventsGenerated += stdEventsGenerated[i]*stdEventsGenerated[i];
            totStdEventsProcessed += stdEventsProcessed[i]*stdEventsProcessed[i];
            totStdRemoteObjects += stdRemoteObjects[i]*stdRemoteObjects[i];
        }
        totTimeTickTime /= numJvms;
        totStdTimeTickTime = Math.sqrt(totStdTimeTickTime);
        totStdEventsGenerated = Math.sqrt(totStdEventsGenerated);
        totStdEventsProcessed = Math.sqrt(totStdEventsProcessed);
        totStdRemoteObjects = Math.sqrt(totStdRemoteObjects);
        double factor = totTimeTickTime/1000D;
        values[numJvms][1] = String.format("%8.2f  / %8.2f", totTimeTickTime/ticksPerReport, totStdTimeTickTime/ticksPerReport);
        values[numJvms][2] = String.format("%8.2f  / %8.2f", totEventsGenerated/factor, totStdEventsGenerated/factor);
        values[numJvms][3] = String.format("%8.2f  / %8.2f", totEventsProcessed/factor, totStdEventsProcessed/factor);
        values[numJvms][4] = String.format("%8.2f  / %8.2f", totRemoteObjects/factor, totStdRemoteObjects/factor);

    }
}