package com.accenture.grids.terra;

import com.accenture.grids.al.Config;
import com.accenture.grids.al.DataObject;
import com.accenture.grids.al.Operation;
import com.accenture.grids.utils.Rand;

/**
 * Initial Version by: arie.golos
 * Date: Sep 22, 2008
 * Time: 1:05:05 PM
 */
public class TerraDataObject extends DataObject {
    public TerraDataObject(int id) {
        super(id);
    }

}