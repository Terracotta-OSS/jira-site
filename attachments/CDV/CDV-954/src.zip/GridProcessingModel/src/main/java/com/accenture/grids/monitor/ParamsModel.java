package com.accenture.grids.monitor;

import com.accenture.grids.al.RunParameters;

/**
 * Initial Version by: arie.golos
 * Date: Oct 15, 2008
 * Time: 12:42:41 PM
 */
public class ParamsModel {
    private final MtrSequencer sequencer;
    private final RunParameters runParams;
    private final int maxObjects;
    private final int userAreaSize;
    private final int maxWorkersPerJvm;
    private final int numJvms;
    private double probabilityOfReadMax;
    private double probabilityOfWriteMax;
    private double probabilityOfRemoteObject;
    private int gaussSigma;
    private int timeExpMedian;
    private int eventsExpMedian;
    private int objectsPerEventExpMedian;
    private int timeTicksPerReport;
    private int avgEventProcessingTime;
    private static ParamsModel instance;

    public synchronized static ParamsModel getInstance() {
        if (instance == null) {
            instance = new ParamsModel();
        }
        return instance;
    }

    private ParamsModel() {
        sequencer = new MtrSequencer();
        runParams = sequencer.getRunParameters();
        numJvms = runParams.getNumJvms();
        maxObjects = runParams.getMaxObjects();
        userAreaSize = runParams.getUserAreaSize();
        maxWorkersPerJvm = runParams.getMaxWorkersPerJvm();
        refresh();

    }

    public void refresh() {
        synchronized (runParams) {
            probabilityOfReadMax = runParams.getProbabilityOfReadMax();
            probabilityOfWriteMax = runParams.getProbabilityOfWriteMax();
            probabilityOfRemoteObject = runParams.getProbabilityOfRemoteObject();
            gaussSigma = runParams.getGaussSigma();
            timeExpMedian = runParams.getTimeExpMedian();
            eventsExpMedian = runParams.getEventsExpMedian();
            objectsPerEventExpMedian = runParams.getObjectsPerEventExpMedian();
            timeTicksPerReport = runParams.getTimeTicksPerReport();
            avgEventProcessingTime = runParams.getAvgEventProcessingTime();
        }
    }

    public synchronized void update() {
        synchronized (runParams) {
            runParams.setProbabilityOfReadMax(probabilityOfReadMax);
            runParams.setProbabilityOfWriteMax(probabilityOfWriteMax);
            runParams.setProbabilityOfRemoteObject(probabilityOfRemoteObject);
            runParams.setGaussSigma(gaussSigma);
            runParams.setTimeExpMedian(timeExpMedian);
            runParams.setEventsExpMedian(eventsExpMedian);
            runParams.setObjectsPerEventExpMedian(objectsPerEventExpMedian);
            runParams.setTimeTicksPerReport(timeTicksPerReport);
            runParams.setAvgEventProcessingTime(avgEventProcessingTime);
        }
    }

    public int getMaxObjects() {
        return maxObjects;
    }

    public int getUserAreaSize() {
        return userAreaSize;
    }

    public int getMaxWorkersPerJvm() {
        return maxWorkersPerJvm;
    }

    public int getNumJvms() {
        return numJvms;
    }

    public double getProbabilityOfReadMax() {
        refresh();
        return probabilityOfReadMax;
    }

    public void setProbabilityOfReadMax(double probabilityOfReadMax) {
        this.probabilityOfReadMax = probabilityOfReadMax;
        update();
    }

    public double getProbabilityOfWriteMax() {
        refresh();
        return probabilityOfWriteMax;
    }

    public void setProbabilityOfWriteMax(double probabilityOfWriteMax) {
        this.probabilityOfWriteMax = probabilityOfWriteMax;
        update();
    }

    public double getProbabilityOfRemoteObject() {
        refresh();
        return probabilityOfRemoteObject;
    }

    public void setProbabilityOfRemoteObject(double probabilityOfRemoteObject) {
        this.probabilityOfRemoteObject = probabilityOfRemoteObject;
        update();
    }

    public int getGaussSigma() {
        refresh();
        return gaussSigma;
    }

    public void setGaussSigma(int gaussSigma) {
        this.gaussSigma = gaussSigma;
        update();
    }

    public int getTimeExpMedian() {
        refresh();
        return timeExpMedian;
    }

    public void setTimeExpMedian(int timeExpMedian) {
        this.timeExpMedian = timeExpMedian;
        update();
    }

    public int getEventsExpMedian() {
        refresh();
        return eventsExpMedian;
    }

    public void setEventsExpMedian(int eventsExpMedian) {
        this.eventsExpMedian = eventsExpMedian;
        update();
    }

    public int getObjectsPerEventExpMedian() {
        refresh();
        return objectsPerEventExpMedian;
    }

    public void setObjectsPerEventExpMedian(int objectsPerEventExpMedian) {
        this.objectsPerEventExpMedian = objectsPerEventExpMedian;
        update();
    }

    public int getTimeTicksPerReport() {
        refresh();
        return timeTicksPerReport;
    }

    public void setTimeTicksPerReport(int timeTicksPerReport) {
        this.timeTicksPerReport = timeTicksPerReport;
        update();
    }

    public int getAvgEventProcessingTime() {
        refresh();
        return avgEventProcessingTime;
    }

    public void setAvgEventProcessingTime(int avgEventProcessingTime) {
        this.avgEventProcessingTime = avgEventProcessingTime;
        update();
    }
}
