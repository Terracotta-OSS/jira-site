package com.accenture.grids.al;

/**
 * Initial Version by: arie.golos
 * Date: Oct 14, 2008
 * Time: 4:31:27 PM
 */
public interface StatsListener {

    public void newData(int jvmIndex);
}
