package com.accenture.grids;

import com.accenture.grids.al.Scheduler;
import com.accenture.grids.al.Stats;

import java.util.LinkedList;
import java.util.List;

/**
 * Initial Version by: arie.golos
 * Date: Oct 1, 2008
 * Time: 2:29:14 PM
 */
public class Main extends Scheduler
{
    public Main()
    {
    }
    public static void main(String[] args)
    {
        System.setProperty("object.factory.alias", args[0]);
        System.out.println("Object Factory Alias is '"+System.getProperty("object.factory.alias")+"'.");
        try {
            new Scheduler().start();
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
    }

}
