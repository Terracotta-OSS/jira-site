package com.accenture.grids.terra;

import com.accenture.grids.al.DataObject;
import com.accenture.grids.al.EventContext;
import com.accenture.grids.al.Operation;
import com.accenture.grids.al.OperationDescriptor;
import com.accenture.grids.utils.Rand;

import java.util.Arrays;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 7:50:32 AM
 */
public class TerraEventContext extends EventContext {

    public TerraEventContext(OperationDescriptor[] descs, int timeTick, int timeToRunAvg) {
        super(descs, timeTick, timeToRunAvg);
    }

    public void processEvent(int threadId) {
        long timeStart = System.nanoTime();
        Arrays.sort(descs, 0, descs.length);   // Sort descriptors in the order to avoid distributed deadlocks

        try {
            for (int i = 0; i < descs.length; i++) {
                OperationDescriptor d = descs[i];
                if (d.getOperation().equals(Operation.WRITE_OP) || d.getOperation().equals(Operation.READ_OP)) {
                    DataObject dataObject = TerraSequencer.getInstance().lockAndGet(d.getId(), threadId);
                    d.setUserObject(dataObject);
                    if (dataObject == null) {
                        System.out.println("Received null data object for ID "+d.getId());
                    }
                } else {  // Delete operation
                    TerraSequencer.getInstance().lock(d.getId(), threadId);
                }

            }
            for (int i = 0; i < descs.length; i++) {
                DataObject dataObject = (DataObject) descs[i].getUserObject();
                if (!descs[i].getOperation().equals(Operation.DELETE_OP)) {
                    synchronized (dataObject) {
                        dataObject.performBusinessComputation(descs[i].getOperation());
                    }
                }
            }
            double timeToRun = (2 * timeToRunAvg) * 1000;    // Compute in nanoseconds
            if (timeToRun > 1) {
                timeToRun = Rand.nextDouble()*timeToRun;
                long itime;
                do {
                    Math.tan(Rand.nextDouble());
                    itime = System.nanoTime() - timeStart;
                }
                while(((double)itime) < timeToRun);
            }

        }
        catch (Exception ex) {
            ex.printStackTrace(System.out);
        }
        finally {
            for (int i = 0; i < descs.length; i++) {
                OperationDescriptor d = descs[i];
//                TerraSequencer.getInstance().unlock(d.getId(), threadId);
                DataObject dataObject = (DataObject) descs[i].getUserObject();
                if (dataObject != null) {
                    if (descs[i].getOperation().equals(Operation.WRITE_OP)) {
                        TerraSequencer.getInstance().updateAndUnlock(dataObject, threadId);
                    } else if (descs[i].getOperation().equals(Operation.READ_OP)) {
                        TerraSequencer.getInstance().unlock(d.getId(), threadId);
                    }
                    else {
                        TerraSequencer.getInstance().delete(d.getId(), threadId); // Just in case
                    }
                }
                else {
                    TerraSequencer.getInstance().delete(d.getId(), threadId);
                }
            }
        }
    }
}
