package com.accenture.grids.chr;

import com.accenture.grids.al.DataObject;

import java.io.ObjectOutput;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.Externalizable;

/**
 * Initial Version by: arie.golos
 * Date: Sep 22, 2008
 * Time: 1:05:05 PM
 */
public class ChrDataObject extends DataObject implements Externalizable {
    public ChrDataObject(int id) {
        super(id);
    }
    public ChrDataObject()
    {}

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(id);
        out.writeObject(userData);
    }

    public void readExternal(ObjectInput in) throws IOException,
            ClassNotFoundException {
        id = (Integer) in.readObject();
        userData = (int[])in.readObject();
    }

}