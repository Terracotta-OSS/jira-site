package com.accenture.grids.monitor;

import com.accenture.grids.al.Stats;
import com.accenture.grids.al.StatsListener;

import javax.swing.*;
import java.awt.*;

/**
 * Initial Version by: arie.golos
 * Date: Oct 14, 2008
 * Time: 4:48:30 PM
 */
public class MainFrame extends JFrame  implements StatsListener {


    public MainFrame()
    {
        setTitle("Grid Monitor");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel top = new JPanel(new BorderLayout(4,4));
        setContentPane(top);

        JPanel north = new JPanel(new BorderLayout(4,4));
        SystemParamsTable ptable = new SystemParamsTable();
        Box bx = Box.createHorizontalBox();
        bx.add(Box.createGlue());
        bx.add(ptable);
        bx.add(Box.createGlue());
        north.add (BorderLayout.CENTER, bx);
        north.add(BorderLayout.NORTH, new JLabel("Run Parameters", JLabel.CENTER));
        north.add(BorderLayout.SOUTH, new JLabel("Latest Statistics Readings", JLabel.CENTER));

        CurrentStatsTable csTable;
        JScrollPane scroller = new JScrollPane(csTable=new CurrentStatsTable());
        Dimension d = csTable.getPreferredSize();
        d.height += 24;
        d.width += 24;
        scroller.setPreferredSize(d);
        JPanel south = new JPanel(new BorderLayout(4,4));
        south.add(BorderLayout.NORTH, new JLabel("Averages", JLabel.CENTER));
        AveragesTable avTable;
        JScrollPane scroller1 = new JScrollPane(avTable=new AveragesTable());
        d = avTable.getPreferredSize();
        d.height += 24;
        d.width += 24;
        scroller1.setPreferredSize(d);

        south.add(BorderLayout.CENTER,  scroller1);
        top.add(BorderLayout.NORTH, north);
        top.add(BorderLayout.SOUTH, south);
        top.add(BorderLayout.CENTER, scroller);
        

        Stats.getInstance().setListener(this);


        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainFrame.this.setSize(new Dimension(840, 340));
                MainFrame.this.setLocation(200,200);
                setVisible(true);
            }
        });

    }

    public void newData(int jvmIndex) {
        Stats st = Stats.getInstance();
        Stats.Record r = st.getLastRecord(jvmIndex);
        String name = st.getName(jvmIndex);
        CurrentStatsTableModel.getInstance().newData(jvmIndex, name, r);
        AveragesTableModel.getInstance().newData(jvmIndex, name, r);
    }
}
