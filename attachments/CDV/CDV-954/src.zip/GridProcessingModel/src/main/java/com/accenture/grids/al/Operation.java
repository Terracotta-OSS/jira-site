package com.accenture.grids.al;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 7:33:16 AM
 */
public enum Operation {
    READ_OP,
    WRITE_OP,
    DELETE_OP,
}
