package com.accenture.grids.al;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 7:43:50 AM
 */
abstract public class OperationDescriptor implements Comparable<OperationDescriptor> {

    protected Integer             id;         // Object ID
    protected Operation operation;  // Operation that needs to be performed on the userObject
    protected Object              userObject; // Node (set during the transaction execution), otherwise null

    public OperationDescriptor(int id, Operation operation) {
        this.id = id;
        this.operation = operation;
    }

    public OperationDescriptor() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public Object getUserObject() {
        return userObject;
    }

    public void setUserObject(Object node) {
        this.userObject = node;
    }
}
