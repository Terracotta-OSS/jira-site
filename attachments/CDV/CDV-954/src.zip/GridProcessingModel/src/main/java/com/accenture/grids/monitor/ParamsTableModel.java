package com.accenture.grids.monitor;

import javax.swing.table.DefaultTableModel;

/**
 * Initial Version by: arie.golos
 * Date: Oct 15, 2008
 * Time: 1:11:10 PM
 */
public class ParamsTableModel extends DefaultTableModel {

    final static String[] COLUMN_0 = {
                                "Number of Objects: ",
                                "Work Threads per JVM: ",
                                "Number of JVMs: ",
                                "Probability of Read: ",
                                "Probability of Write: ",
                                "Probability of Remote: ",
    };
   final static String[] COLUMN_2 = {
                                "Object Cluster Factor: ",
                                "Average Event Delay: ",
                                "Average Events per Tick: ",
                                "Average Objects per Event: ",
                                "Average Event Processing Time: ",
                                "Time Ticks per Stats Update: ",
   };

    public ParamsTableModel() {
    }
    public int getRowCount() {
        return COLUMN_0.length;
    }

    public int getColumnCount() {
        return 4;
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            return COLUMN_0[rowIndex];
        }
        if (columnIndex == 2) {
            return COLUMN_2[rowIndex];
        }
        if (columnIndex == 1) {
            switch (rowIndex) {
                case 0: return ParamsModel.getInstance().getMaxObjects();
                case 1: return ParamsModel.getInstance().getMaxWorkersPerJvm();
                case 2: return ParamsModel.getInstance().getNumJvms();
                case 3: return ParamsModel.getInstance().getProbabilityOfReadMax();
                case 4: return ParamsModel.getInstance().getProbabilityOfWriteMax()-ParamsModel.getInstance().getProbabilityOfReadMax();
                case 5: return ParamsModel.getInstance().getProbabilityOfRemoteObject();
                default: return "";
            }
        }
        if (columnIndex == 3) {
            switch (rowIndex) {
                case 0: return ParamsModel.getInstance().getGaussSigma();
                case 1: return ParamsModel.getInstance().getTimeExpMedian();
                case 2: return ParamsModel.getInstance().getEventsExpMedian();
                case 3: return ParamsModel.getInstance().getObjectsPerEventExpMedian();
                case 4: return ParamsModel.getInstance().getAvgEventProcessingTime();
                case 5: return ParamsModel.getInstance().getTimeTicksPerReport();
                default: return "";
            }
        }
        return "";
    }

}
