package com.accenture.grids.monitor;

import com.accenture.grids.al.RunParameters;
import com.accenture.grids.al.StatsListener;
import com.accenture.grids.al.Stats;

import javax.swing.table.DefaultTableModel;

/**
 * Initial Version by: arie.golos
 * Date: Oct 14, 2008
 * Time: 4:54:57 PM
 */
class CurrentStatsTableModel extends DefaultTableModel {

    private static String[] HEADERS = {
            "JVM Name",
            "Time Tick",
            "Time Interval (ms/tick)",
            "Events Generated",
            "Events Processed",
            "Remote Objects" };

    private final String[][]    values;
    private final int           numJvms;
    static synchronized CurrentStatsTableModel getInstance()
    {
        if(instance == null) {
            instance = new CurrentStatsTableModel();
        }
        return instance;
    }
    private static CurrentStatsTableModel   instance;
    private CurrentStatsTableModel()
    {

        numJvms = ParamsModel.getInstance().getNumJvms();
        values = new String[numJvms][HEADERS.length];
        for(String[] vs : values) {
            for(int i = 0; i<vs.length; ++i) {
                vs[i] = "";
            }
        }
    }
    public int getRowCount() {
        return numJvms;
    }

    public int getColumnCount() {
        return HEADERS.length;
    }

    public String getColumnName(int columnIndex) {
        return HEADERS[columnIndex];
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        if(rowIndex >=0 && rowIndex < numJvms) {
            return values[rowIndex][columnIndex];
        }
        return "";  
    }

    public synchronized void newData(int jvmIndex, String name, Stats.Record r) {
        int ticksPerReport = ParamsModel.getInstance().getTimeTicksPerReport();
        values[jvmIndex][0] = name;
        values[jvmIndex][1] = Integer.toString(r.getTimeTick());
        values[jvmIndex][2] = Long.toString(r.getTimeInterval()/ticksPerReport);
        values[jvmIndex][3] = Integer.toString(r.getEventsGenerated()/ticksPerReport);
        values[jvmIndex][4] = Integer.toString(r.getEventsProcessed()/ticksPerReport);
        values[jvmIndex][5] = Integer.toString(r.getRemoteObjectsRefs()/ticksPerReport);
        fireTableRowsUpdated(jvmIndex, jvmIndex);
    }
}
