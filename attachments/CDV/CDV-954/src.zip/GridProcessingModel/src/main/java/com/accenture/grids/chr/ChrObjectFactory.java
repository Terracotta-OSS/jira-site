package com.accenture.grids.chr;

import com.accenture.grids.al.*;
import com.accenture.grids.terra.TerraEventContext;
import com.accenture.grids.terra.TerraOperationDescriptor;
import com.accenture.grids.terra.TerraSequencer;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 9:48:26 AM
 */
public class ChrObjectFactory implements ObjectFactory {
    public EventContext createEventContext(OperationDescriptor[] nodeOps, int timeTick, int timeToRunAvg) {
        return new ChrEventContext(nodeOps, timeTick, timeToRunAvg);
    }
    public OperationDescriptor createOperationDescriptor(int id, Operation operation) {
        return new ChrOperationDescriptor(id, operation);
    }
    public Sequencer getSequencerInstance() {
        return ChrSequencer.getInstance();
    }
}