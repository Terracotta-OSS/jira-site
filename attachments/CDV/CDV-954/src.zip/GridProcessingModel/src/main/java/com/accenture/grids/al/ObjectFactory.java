package com.accenture.grids.al;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 9:31:03 AM
 */
public interface ObjectFactory {

    public abstract EventContext createEventContext(OperationDescriptor[] nodeOps, int timeTick, int timeToRunAvg);
    public abstract OperationDescriptor createOperationDescriptor(int id, Operation operation);
    public abstract Sequencer getSequencerInstance();
}
