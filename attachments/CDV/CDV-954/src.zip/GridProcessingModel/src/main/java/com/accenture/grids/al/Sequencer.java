package com.accenture.grids.al;

import java.util.BitSet;
import java.util.concurrent.*;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 2:32:36 PM
 */
public class Sequencer {
    protected final CyclicBarrier                     barrier;                       // Shared
    protected final BitSet                            reservationSet = new BitSet(Config.getNumJvms());     // Shared
    protected final RunParameters                     runParameters = new RunParameters();  // Shared
    protected int                                     jvmIndex;      // Not shared


    protected Sequencer()
    {
        barrier = new CyclicBarrier(Config.getNumJvms()*(Config.getMaxWorkersPerJvm()+1), null);
        reserveJvmIndex();
        System.out.println("JVM Index is "+jvmIndex);
    }
    public int getJvmIndex()
    {
        return jvmIndex;
    }
    protected void reserveJvmIndex() {
        synchronized (reservationSet) {
            for(int i=0; i<Config.getNumJvms(); ++i) {
                if(!reservationSet.get(i)) {
                    reservationSet.set(i);
                    jvmIndex = i;
                    return;
                }
            }
        }
        throw new RuntimeException("No free JVM number found");
    }
    public void internalPhaseStart()
    {
        await(2);
    }
    public void internalPhaseEnd()
    {
        // Empty method for terracotta
    }
    public void externalPhaseStart()
    {
        await(1);
    }
    public void externalPhaseEnd()
    {
        await(1);
    }
    public RunParameters getRunParameters()
    {
        return runParameters;
    }
    private void await(int numTimes)
    {
        try {
            for(int i=0; i<numTimes; ++i) {
                barrier.await();
            }
        }
        catch(InterruptedException ex) {
            ex.printStackTrace();
        }
        catch(BrokenBarrierException ex) {
            ex.printStackTrace();
        }
    }

}