package com.accenture.grids.al;

/**
 * Initial Version by: arie.golos
 * Date: Oct 13, 2008
 * Time: 2:48:56 PM
 */
public class RunParameters {
    private int maxObjects;
    private int userAreaSize;
    private double probabilityOfReadMax;
    private double probabilityOfWriteMax;
    private double probabilityOfRemoteObject;
    private int    gaussSigma;
    private int    timeExpMedian;
    private int    eventsExpMedian;
    private int    objectsPerEventExpMedian;
    private int    maxWorkersPerJvm;
    private int    numJvms;
    private int    timeTicksPerReport;
    private int    avgEventProcessingTime;

    public RunParameters()
    {
        maxObjects = Config.getMaxObjects();
        userAreaSize = Config.getUserAreaSize();
        probabilityOfReadMax = Config.getProbabilityOfReadMax();
        probabilityOfWriteMax = Config.getProbabilityOfWriteMax();
        probabilityOfRemoteObject = Config.getProbabilityOfRemoteObject();
        gaussSigma = Config.getGaussSigma();
        timeExpMedian = Config.getTimeExpMedian();
        eventsExpMedian = Config.getEventsExpMedian();
        objectsPerEventExpMedian = Config.getObjectsPerEventExpMedian();
        maxWorkersPerJvm = Config.getMaxWorkersPerJvm();
        numJvms = Config.getNumJvms();
        timeTicksPerReport = Config.getTimeTicksPerReport();
        avgEventProcessingTime = Config.getAvgEventProcessingTime();
    }
    public int idToJvmIndex(int id)
    {
        return id / (maxObjects/numJvms);
    }

    public synchronized int getMaxObjects() {
        return maxObjects;
    }

    public synchronized int getUserAreaSize() {
        return userAreaSize;
    }

    public synchronized double getProbabilityOfReadMax() {
        return probabilityOfReadMax;
    }

    public synchronized double getProbabilityOfWriteMax() {
        return probabilityOfWriteMax;
    }

    public synchronized int getGaussSigma() {
        return gaussSigma;
    }

    public synchronized double getProbabilityOfRemoteObject() {
        return probabilityOfRemoteObject;
    }

    public synchronized int getTimeExpMedian() {
        return timeExpMedian;
    }

    public synchronized int getMaxWorkersPerJvm() {
        return maxWorkersPerJvm;
    }

    public synchronized int getEventsExpMedian() {
        return eventsExpMedian;
    }

    public synchronized int getObjectsPerEventExpMedian() {
        return objectsPerEventExpMedian;
    }

    public synchronized int getNumJvms() {
        return numJvms;
    }

    public synchronized int getTimeTicksPerReport() {
        return timeTicksPerReport;
    }

    public synchronized int getAvgEventProcessingTime() {
        return avgEventProcessingTime;
    }

    public synchronized void setProbabilityOfReadMax(double probabilityOfReadMax) {
        this.probabilityOfReadMax = probabilityOfReadMax;
    }

    public synchronized void setProbabilityOfWriteMax(double probabilityOfWriteMax) {
        this.probabilityOfWriteMax = probabilityOfWriteMax;
    }

    public synchronized void setProbabilityOfRemoteObject(double probabilityOfRemoteObject) {
        this.probabilityOfRemoteObject = probabilityOfRemoteObject;
    }

    public synchronized void setGaussSigma(int gaussSigma) {
        this.gaussSigma = gaussSigma;
    }

    public synchronized void setTimeExpMedian(int timeExpMedian) {
        this.timeExpMedian = timeExpMedian;
    }

    public synchronized void setEventsExpMedian(int eventsExpMedian) {
        this.eventsExpMedian = eventsExpMedian;
    }

    public synchronized void setObjectsPerEventExpMedian(int objectsPerEventExpMedian) {
        this.objectsPerEventExpMedian = objectsPerEventExpMedian;
    }

    public synchronized void setTimeTicksPerReport(int timeTicksPerReport) {
        this.timeTicksPerReport = timeTicksPerReport;
    }

    public void setAvgEventProcessingTime(int avgEventProcessingTime) {
        this.avgEventProcessingTime = avgEventProcessingTime;
    }
}
