package com.accenture.grids.chr;

import com.accenture.grids.al.Operation;
import com.accenture.grids.al.OperationDescriptor;

/**
 * Initial Version by: arie.golos
 * Date: Sep 30, 2008
 * Time: 3:47:49 PM
 */
public class ChrOperationDescriptor extends OperationDescriptor {
    private boolean objectJustCreated;
    ChrOperationDescriptor(int id, Operation operation)
    {
        super(id, operation);
    }

    public boolean isObjectJustCreated() {
        return objectJustCreated;
    }

    public void setObjectJustCreated(boolean objectJustCreated) {
        this.objectJustCreated = objectJustCreated;
    }

    /**
     * Comparator for sorting in ascending order
     * @param od operation descriptor to compare to
     * @return +1, -1 or  0
     */
    public int compareTo(OperationDescriptor od) {
        if (od == null ) {
            throw new IllegalArgumentException("comparable object is null");
        }
        int p1 = id;
        int p2 = od.getId();
        if (p1 != p2) {
            return (p1 > p2) ? 1 : -1;
        }
        else {
            // Just in case in the future we want to implement read locks
            // As a secondary key, compare operations, so that modify operations come out earlier during the sort
            Operation op1 = this.getOperation();
            Operation op2 = od.getOperation();
            if (op1.equals(op2)) return 0;
            return (op1.equals(Operation.READ_OP))?1:-1;
        }
    }

}