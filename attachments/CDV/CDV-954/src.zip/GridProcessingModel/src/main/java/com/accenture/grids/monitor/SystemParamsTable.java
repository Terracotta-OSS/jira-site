package com.accenture.grids.monitor;

import javax.swing.*;
import javax.swing.table.TableColumn;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/**
 * Initial Version by: arie.golos
 * Date: Oct 15, 2008
 * Time: 1:56:50 PM
 */
public class SystemParamsTable extends JTable {

    SystemParamsTable()
    {
        super(new ParamsTableModel());
        MyRend r = new MyRend();
        TableColumn tc = getColumn("A");
        tc.setPreferredWidth(200);
        tc.setCellRenderer(r);
        tc.setIdentifier(0);

        tc = getColumn("B");
        tc.setPreferredWidth(60);
        tc.setHeaderValue("Mission");
        tc.setCellRenderer(r);
        tc.setIdentifier(1);


        tc = getColumn("C");
        tc.setPreferredWidth(200);
        tc.setCellRenderer(r);
        tc.setIdentifier(2);

        tc = getColumn("D");
        tc.setPreferredWidth(60);
        tc.setCellRenderer(r);
        tc.setIdentifier(3);

        setShowGrid(false);
        setMaximumSize(getPreferredSize());
        setBorder(BorderFactory.createLineBorder(Color.black, 1));

    }

    class MyRend extends DefaultTableCellRenderer {

        final Color BC = new Color(235, 235,235);
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if ((column & 1) == 0) {
                this.setHorizontalAlignment(JLabel.RIGHT);
                this.setBackground(BC);
            }
            else {
                this.setHorizontalAlignment(JLabel.LEFT);
                this.setBackground(Color.white);
            }
            final Font f = this.getFont().deriveFont(Font.BOLD);
            setFont(f);
            return this;
        }

    }

}
