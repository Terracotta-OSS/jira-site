package com.accenture.grids.monitor;

import javax.swing.*;

/**
 * Initial Version by: arie.golos
 * Date: Oct 16, 2008
 * Time: 10:38:43 AM
 */
public class AveragesTable extends JTable {
    AveragesTable()
    {
        super(AveragesTableModel.getInstance());
    }
}