package com.accenture.grids.utils;

import java.util.Random;

/**
 * Initial Version by: arie.golos
 * Date: Sep 22, 2008
 * Time: 1:26:36 PM
 */
public class Rand {
    private static Random gen = new Random();

    public static Random inst() {
        return gen;
    }
    public static int getNextInt(int max)
    {
        return gen.nextInt(max);
    }
    public static int getGaussianValue(int median, int dispersion, int rangeLow, int rangeHigh )
    {
        double v =  median + gen.nextGaussian() * dispersion;
        if (v < rangeLow) {
            do {
                v += (rangeHigh - rangeLow);
            } while(v < rangeLow);
        }
        else if (v >= rangeHigh) {
            do  {
                v -= (rangeHigh - rangeLow);
            } while(v >= rangeHigh);
        }
        return (int) v;
    }
    public static int getExponentValue(int median)
    {
        if (median <= 0) return 0;
        double p = 1D - 1D/median;
        int n = 0;
        while( gen.nextDouble() < p) n++;
        return n;

    }
    public static double nextDouble()
    {
        return gen.nextDouble();
    }
    public static void main(String[] args)
    {
        double[] gauss = new double[1000], exp = new double[1000];
        for(int i=0; i< 1000; i++) {
            gauss[i] = getGaussianValue(1000000, 25, 0, 0x10000000);
            exp[i] = getExponentValue(25);
        }
        double gav = 0, eav = 0;
        for(int i=0; i<1000; i++) {
            gav += gauss[i];
            eav += exp[i];
        }
        gav = gav/1000;
        eav = eav/1000;

        double gsig = 0, esig = 0;
        for(int i=0; i<1000; i++) {
            gsig += (gauss[i] - gav)*(gauss[i] - gav);
            esig += (exp[i] - eav)*(exp[i] - eav);
        }
        gsig = Math.sqrt(gsig/1000D);
        esig = Math.sqrt(esig/1000D);

        System.out.println("Gauss: av = "+gav+"     sigma = "+gsig);
        System.out.println("Expon: av = "+eav+"     sigma = "+esig);
    }
}
