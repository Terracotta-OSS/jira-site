package com.accenture.grids.al;

import java.util.LinkedList;
import java.util.List;

/**
 * Initial Version by: arie.golos
 * Date: Oct 14, 2008
 * Time: 8:57:48 AM
 */
public class Stats {
    public static class Record {
        public Record(int timeTick, int timeInterval, int eventsProcessed, int eventsGenerated, int remoteObjectsRefs) {
            this.timeTick = timeTick;
            this.timeInterval = timeInterval;
            this.eventsProcessed = eventsProcessed;
            this.eventsGenerated = eventsGenerated;
            this.remoteObjectsRefs = remoteObjectsRefs;
        }

        private int         timeTick;                   // Time tick number
        private int         timeInterval;               // Time length of the interval in ms
        private int         eventsProcessed;            // Number of events processed durin this interval
        private int         eventsGenerated;            // Number of events generated during this interval
        private int         remoteObjectsRefs;          // Number of remote object references generated

        public void print()
        {
            System.out.println(String.format("Time Tick: %d  Interval: %d (ms)  Events Processed: %d  Events Genarated: %d  Remote Objects: %d",
                    timeTick, timeInterval, eventsProcessed, eventsGenerated, remoteObjectsRefs));
        }

        public int getTimeTick() {
            return timeTick;
        }

        public long getTimeInterval() {
            return timeInterval;
        }

        public int getEventsProcessed() {
            return eventsProcessed;
        }

        public int getEventsGenerated() {
            return eventsGenerated;
        }

        public int getRemoteObjectsRefs() {
            return remoteObjectsRefs;
        }
    }
    private final LinkedList[]                          vectors = new LinkedList[Config.getNumJvms()];
    private transient StatsListener                     listener;
    private static final Stats                          instance = new Stats();
    public static final String[]                        names = new String[Config.getNumJvms()];
    public synchronized static Stats getInstance()
    {
        return instance;
    }
    private Stats() {
    }
    public synchronized void setName(String name, int jvmIndex)
    {
        names[jvmIndex] = name;
    }
    public synchronized String getName(int jvmIndex) {
        if(names[jvmIndex] == null) {
            return "JVM-"+jvmIndex;
        }
        return names[jvmIndex];
    }
    public synchronized void addRecord(Record r, int jvmIndex)
    {
        LinkedList<Record> list = getLinkedList(jvmIndex);
        if (list.size() == Config.getStatsArrayLength()) {
            list.removeFirst();
        }
        list.add(r);
    }
    public synchronized List<Record> getRecords(int jvmIndex)
    {
        LinkedList<Record> list = getLinkedList(jvmIndex);
        return (List<Record>) (list.clone());
    }
    public synchronized Record getLastRecord(int jvmIndex) {
        LinkedList<Record> list = getLinkedList(jvmIndex);
        if(list.size()>0) {
            return list.getLast();
        }
        return null;
    }
    private LinkedList<Record> getLinkedList(int jvmIndex) {
        LinkedList<Record> list = (LinkedList<Record>)(vectors[jvmIndex]);
        if (list == null) {
            vectors[jvmIndex] = list = new LinkedList<Record>();
        }
        return list;
    }
    public synchronized void newData(int jvmIndex)
    {
        if(listener != null) {
            listener.newData(jvmIndex);
        }
    }

    public synchronized StatsListener getListener() {
        return listener;
    }

    public synchronized void setListener(StatsListener listener) {
        this.listener = listener;
    }
}
