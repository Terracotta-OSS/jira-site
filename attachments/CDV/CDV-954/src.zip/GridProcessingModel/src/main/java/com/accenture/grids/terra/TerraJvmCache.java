package com.accenture.grids.terra;

import com.accenture.grids.al.DataObject;
import com.accenture.grids.al.RunParameters;
import com.accenture.grids.al.Config;

import java.util.HashMap;

/**
 * Initial Version by: arie.golos
 * Date: Oct 4, 2008
 * Time: 9:07:10 PM
 */
class TerraJvmCache {
    private static class MapEntry {
        private boolean     locked;
        private DataObject  dataObject;
        private int         accessIndex;
        private long[]      accessTime = new long[4];
        private String[]       accessCommand = new String[4];
        void saveCommand(String cmd)
        {
            accessTime[accessIndex] = System.currentTimeMillis();
            accessCommand[accessIndex] =  cmd;
            if (++accessIndex == 4) accessIndex = 0;
        }
        void printBuffer()
        {
            System.out.println("Access index "+accessIndex);
            for(int i=0; i<4; i++) {
                System.out.println("Access Time: "+accessTime[i]+"   Access Command: "+accessCommand[i]);
            }
        }
    }
    private final int objectsStart;
    private final int objectsEnd;
    private HashMap<Integer, MapEntry>            map;
    public TerraJvmCache(int jvmIndex)
    {
        int objectsInMap = Config.getMaxObjects()/Config.getNumJvms();
        objectsStart = jvmIndex * objectsInMap;
        objectsEnd = (jvmIndex+1) * objectsInMap;
        map = new HashMap<Integer, MapEntry>();
        synchronized(map) {
            for (int i=objectsStart; i<objectsEnd; ++i) {
                map.put(i, new MapEntry());
            }
        }
        System.out.println("TerraJvmCache: Object range:  "+objectsStart+" ... "+objectsEnd);
    }

    private boolean isMyId(int id) {
        return id >= objectsStart  && id < objectsEnd;
    }

    DataObject lockAndGet(int id) {
        if (isMyId(id)) {
            MapEntry e = map.get(id);
            synchronized (e) {
                while (true) {
                    if (!e.locked && e.dataObject == null) {
                        e.dataObject = new TerraDataObject(id);
                        e.locked = true;
                        e.saveCommand("lockAndGet-new ");
                        //System.out.println("lockAndGet: created data object for ID "+id);
                        break;
                    } else if (!e.locked) {
                        e.locked = true;
                        e.saveCommand("lockAndGet");
                        //System.out.println("lockAndGet: locked data object for ID "+id);
                        break;
                    } else { // Object is locked
                        long timeStart = System.currentTimeMillis();
                        try {
                            e.wait(50000);
                        }
                        catch (InterruptedException ex) {
                            //
                        }
                        if (System.currentTimeMillis() - timeStart > 49000) {
                            System.out.println("Timeout in wait for id " + id);
                            e.printBuffer();
                        }
                        else {
                            //System.out.println("Exiting lock and get for ID normally "+id);
                        }
                    }
                }
                return e.dataObject;
            }
        }
        else {
            return null;
        }
    }
    int lock(int id) {
        if (isMyId(id)) {
            MapEntry e = map.get(id);
            synchronized (e) {
                while (true) {
                    if (!e.locked) {
                        e.locked = true;
                        e.saveCommand("lock");
                        //System.out.println("lockAndGet: locked data object for ID "+id);
                        break;
                    } else { // Object is locked
                        long timeStart = System.currentTimeMillis();
                        try {
                            e.wait(5000);
                        }
                        catch (InterruptedException ex) {
                            //
                        }
                        if (System.currentTimeMillis() - timeStart > 4900) {
                            System.out.println("Timeout in wait for id " + e.dataObject.getId());
                            e.printBuffer();
                        }
                        else {
                            //System.out.println("Exiting lock and get for ID normally "+id);
                        }
                    }
                }
            }
            return id;
        }
        return -1;
    }

    int unlock(int id)
    {
        if (isMyId(id)) {
            //System.out.println("Local unlock for ID "+id);
            MapEntry e = map.get(id);
            synchronized (e) {
                e.locked = false;
                e.saveCommand("unlock");
                e.notifyAll();
            }
            return id;
        }
        else {
            //System.out.println("Remote unlock for ID "+id);
            return -1;
        }
    }
    int delete(int id)
    {
        if (isMyId(id)) {
            //System.out.println("Local unlock for ID "+id);
            MapEntry e = map.get(id);
            synchronized (e) {
                e.dataObject = null;
                e.locked = false;
                e.saveCommand("delete");
                e.notifyAll();
            }
            return id;
        }
        else {
            //System.out.println("Remote unlock for ID "+id);
            return -1;
        }
    }
    int updateAndUnlock(DataObject dn)
    {
        int id = dn.getId();
        if (isMyId(id)) {
            //System.out.println("Local updateAndUnlock for ID "+id);
            MapEntry e = map.get(id);
            synchronized (e) {
                e.dataObject = dn;
                e.locked = false;
                e.saveCommand("updateAndUnlock");
                e.notifyAll();
            }
            return 0;
        }
        else {
            //System.out.println("Remote updateAndUnlock for ID "+id);
            return -1;
        }
    }

}
