package com.accenture.grids.al;

import java.util.Properties;
import java.util.TreeMap;
import java.io.FileInputStream;

/**
 * Initial Version by: arie.golos
 * Date: Sep 22, 2008
 * Time: 1:34:19 PM
 */
public class Config {

    //private static int numObjectPartitions;
    private static int maxObjects;
    private static int userAreaSize;
    private static double probabilityOfReadMax;
    private static double probabilityOfWriteMax;
    private static double probabilityOfRemoteObject;
    private static int    gaussSigma;
    private static int    timeExpMedian;
    private static int    eventsExpMedian;
    private static int avgEventProcessingTime;
    private static int    objectsPerEventExpMedian;
    private static int    maxWorkersPerJvm;
    private static int    numJvms;
    private static int    timeTicksPerReport;
    private static int    statsArrayLength;
    private static TreeMap<String,String> factoryMap;
    static {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream("sim.properties"));
            maxObjects = Integer.parseInt(props.getProperty("max.objects").trim());
            userAreaSize = Integer.parseInt(props.getProperty("user.area.size").trim());
            probabilityOfReadMax = Double.parseDouble(props.getProperty("probability.of.read").trim());
            probabilityOfWriteMax = Double.parseDouble(props.getProperty("probability.of.write").trim()) + probabilityOfReadMax;
            probabilityOfRemoteObject = Double.parseDouble(props.getProperty("probability.of.remote.object").trim());
            gaussSigma = Integer.parseInt(props.getProperty("gauss.std.deviation").trim());
            timeExpMedian = Integer.parseInt(props.getProperty("time.exp.median").trim());
            //numObjectPartitions = Integer.parseInt(props.getProperty("object.partitions").trim());
            maxWorkersPerJvm = Integer.parseInt(props.getProperty("max.workers.per.jvm").trim());
            eventsExpMedian = Integer.parseInt(props.getProperty("events.exp.median").trim());
            objectsPerEventExpMedian = Integer.parseInt(props.getProperty("objects.per.event.exp.median").trim());
            numJvms = Integer.parseInt(props.getProperty("num.jvms").trim());
            timeTicksPerReport = Integer.parseInt(props.getProperty("time.ticks.per.report").trim());
            statsArrayLength = Integer.parseInt(props.getProperty("stats.array.length").trim());
            avgEventProcessingTime = Integer.parseInt(props.getProperty("avg.event.processing.time").trim());
            String temp = props.getProperty("object.factories").trim();
            if(temp == null) throw new IllegalArgumentException("object.factories string is not specified");
            String[] facts = temp.split("\\|");
            factoryMap = new TreeMap<String,String>();
            for(String fact :  facts) {
                String[] kv=fact.trim().split(", *");
                if(kv.length != 2) {
                    throw new IllegalArgumentException("object.factories string has incorrect syntax");
                }
                factoryMap.put(kv[0].trim(), kv[1].trim());
            }
        }
        catch (Exception iox) {
            iox.printStackTrace();
            System.err.println("Error in config properties syntax");
            System.exit(-1);

        }
    }

//    public static int idToPartitionIndex(int id)
//    {
//        return id % numObjectPartitions;
//    }
//    public static int idToPartitionId(int id) {
//        return idToPartitionIndex(id); // So that is negative
//    }
//
//    public static int getNumObjectPartitions() {
//        return numObjectPartitions;
//    }

    public static int idToJvmIndex(int id)
    {
        return id / (maxObjects/numJvms);
    }

    public static int getMaxObjects() {
        return maxObjects;
    }

    public static int getUserAreaSize() {
        return userAreaSize;
    }

    public static double getProbabilityOfReadMax() {
        return probabilityOfReadMax;
    }

    public static double getProbabilityOfWriteMax() {
        return probabilityOfWriteMax;
    }

    public static int getGaussSigma() {
        return gaussSigma;
    }

    public static double getProbabilityOfRemoteObject() {
        return probabilityOfRemoteObject;
    }

    public static int getTimeExpMedian() {
        return timeExpMedian;
    }

    public static int getMaxWorkersPerJvm() {
        return maxWorkersPerJvm;
    }

    public static int getEventsExpMedian() {
        return eventsExpMedian;
    }

    public static int getObjectsPerEventExpMedian() {
        return objectsPerEventExpMedian;
    }

    public static int getNumJvms() {
        return numJvms;
    }

    public static int getStatsArrayLength() {
        return statsArrayLength;
    }

    public static int getTimeTicksPerReport() {
        return timeTicksPerReport;
    }

    public static int getAvgEventProcessingTime() {
        return avgEventProcessingTime;
    }

    public static void main(String[] args) {
    }
    public static ObjectFactory getFactoryFromFactoryAlias(String fname)
    {
        String t = factoryMap.get(fname);
        try {
            Class clazz = Class.forName(t);
            return (ObjectFactory) clazz.newInstance();
        }
        catch(Exception ex) {
            ex.printStackTrace();
            System.exit(-1);
        }
        return null;
    }
}
