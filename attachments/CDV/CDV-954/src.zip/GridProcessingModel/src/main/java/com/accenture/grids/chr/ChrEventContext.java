package com.accenture.grids.chr;

import com.accenture.grids.al.DataObject;
import com.accenture.grids.al.EventContext;
import com.accenture.grids.al.OperationDescriptor;
import com.accenture.grids.al.Operation;
import com.accenture.grids.utils.Rand;
import com.tangosol.net.NamedCache;

import java.util.Arrays;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 7:50:32 AM
 */
public class ChrEventContext extends EventContext {

    public ChrEventContext(OperationDescriptor[] descs, int timeTick, int timeToRunAvg) {
        super(descs, timeTick, timeToRunAvg);
    }

    public void processEvent(int dummy) {
        long timeStart = System.nanoTime();
        Arrays.sort(descs, 0, descs.length);   // Sort descriptors in the order to avoid distributed deadlocks
        NamedCache cache = ChrSequencer.getInstance().getNamedCache();
        try {
            for (int i = 0; i < descs.length; i++) {
                ChrOperationDescriptor d = (ChrOperationDescriptor)descs[i];
                boolean locked =  cache.lock(d.getId(), 5000);
                if(!locked) {
                    throw new Exception("Lock not locked for ID "+d.getId());
                }
                DataObject dataObject = (DataObject) cache.get(d.getId());

                if (dataObject == null) {
                    dataObject = new ChrDataObject(d.getId());
                    d.setObjectJustCreated(true);
                }
                d.setUserObject(dataObject);
            }
            for (int i = 0; i < descs.length; i++) {
                DataObject dataObject = (DataObject) descs[i].getUserObject();
                Operation op = descs[i].getOperation();
                if (op.equals(Operation.READ_OP) || op.equals(Operation.WRITE_OP)) {
                    dataObject.performBusinessComputation(descs[i].getOperation());
                }
            }
            double timeToRun = (2 * timeToRunAvg) * 1000;    // Compute in nanoseconds
            if (timeToRun > 1) {
                timeToRun = Rand.nextDouble()*timeToRun;
                long itime;
                do {
                    Math.tan(Rand.nextDouble());
                    itime = System.nanoTime() - timeStart;
                }
                while(((double)itime) < timeToRun);
            }

            for (int i = 0; i < descs.length; i++) {
                ChrOperationDescriptor d = (ChrOperationDescriptor)descs[i];
                if (d.getOperation().equals(Operation.WRITE_OP)) {
                    cache.put(d.getId(), d.getUserObject());
                }
                else if (d.getOperation().equals(Operation.READ_OP) && d.isObjectJustCreated()) {
                    cache.put(d.getId(), d.getUserObject());
                }
                else if (d.getOperation().equals(Operation.DELETE_OP) && (!d.isObjectJustCreated())) {
                    cache.remove(d.getId());
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace(System.out);
        }
        finally {
            for (int i = 0; i < descs.length; i++) {    
                OperationDescriptor d = descs[i];
                cache.unlock(d.getId());
            }
        }
    }
}