package com.accenture.grids.chr;

import com.accenture.grids.al.Sequencer;
import com.tangosol.net.NamedCache;
import com.tangosol.net.CacheFactory;

/**
 * Initial Version by: arie.golos
 * Date: Sep 26, 2008
 * Time: 2:32:36 PM
 */
public class ChrSequencer extends Sequencer {
    private static ChrSequencer instance = new ChrSequencer();
    public static ChrSequencer getInstance() {
        return instance;
    }
    private final int objectsStart;
    private final int objectsEnd;
    private final NamedCache cache = CacheFactory.getCache("Data-Objects");
    public ChrSequencer()
    {
        int jvmIndex = getJvmIndex();
        int objectsInMap = getRunParameters().getMaxObjects()/getRunParameters().getNumJvms();
        objectsStart = jvmIndex * objectsInMap;
        objectsEnd = (jvmIndex+1) * objectsInMap;
        System.out.println("ChrSequencer: Object range:  "+objectsStart+" ... "+objectsEnd);
    }
    public NamedCache getNamedCache() {
        return cache;
    }
    boolean isMyId(int id) {
        return id >= objectsStart  && id < objectsEnd;
    }

}