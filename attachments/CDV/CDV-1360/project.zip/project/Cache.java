/**
 * 
 */
package com.terracotta.enumtest;

import java.util.EnumMap;
import java.util.Map;

class Cache {
	Map<Planet, Data> _map = new EnumMap<Planet, Data>(Planet.class);
	
		public synchronized boolean isEmpty() {
			return _map.isEmpty();
		}

		public synchronized void put(Planet key, Data value) {
			_map.put(key, value);
		}

		public synchronized Data get(Planet key) {
			return _map.get(key);
		}
}