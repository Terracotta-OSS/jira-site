package com.terracotta.enumtest;

public class Data {
	String name = "Earth Data";
	
	public String toString()	{
		return name;
	}
}
