package com.terracotta.enumtest;

import java.util.EnumMap;


public class EnumMapTest {
	public Cache CACHE = new Cache();
	public static void main(String[] args) {
		EnumMapTest enumMapTest = new EnumMapTest();
//		enumMapTest.CACHE.put(Planet.EARTH, null);
		Data data = enumMapTest.CACHE.get(Planet.EARTH);
		System.out.println(data);
	}
}
