package test;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;
import util.SpringHibernateUtil;

public class TestApp3 {
	private static ArrayList<Course> courses = new ArrayList<Course>();
	public static void main(String args[]) throws Exception{
        Session session = SpringHibernateUtil.getSessionFactory().openSession();
//        Transaction tx = session.beginTransaction();
//
//        Student s = new Student();
//        s.setCal(new Date());
//        s.setName("TestStudent4");
//        Course c1 = new Course();
//        c1.setName("TestCourse41");
//        s.addCourse(c1);
//        Course c2 = new Course();
//        c2.setName("TestCourse42");
////        s.addCourse(c2);
//        session.saveOrUpdate(s);
//        tx.commit();
        
        readData(session);
        session.close();
//        session = SpringHibernateUtil.getSessionFactory().openSession();
//        readData(session);
	}

	private static void readData(Session session) {
        Iterator it = session.createQuery("from test.Student s").setCacheable(true).list().iterator();
        long startTime = System.currentTimeMillis();
        while(it.hasNext()) {
        	Student s1 = (Student)it.next();
        	System.out.println("Name = " + s1.getName() + ", Date = " + s1.getName());
        	System.out.println("Date = " + s1.getCal());

        	Iterator itc = s1.getCourses().iterator();
        	while(itc.hasNext()) {
        		Course c = (Course)itc.next();
        		System.out.println("Course Name = " + c.getName());
        	}
        }
	}
//	public static void main(String args[]) {
//      Session session = SpringHibernateUtil.getSessionFactory().openSession();
////	    Iterator it = session.createQuery("from test.Course s").setCacheable(true).list().iterator();
////	    long startTime = System.currentTimeMillis();
////	    while(it.hasNext()) {
////	    	Course s1 = (Course)it.next();
////	    	synchronized(courses) {
////	    		courses.add(s1);
////	    	}
////	    }
//		for(int i = 0; i < courses.size(); i++) {
//			Course s1 = courses.get(i);
//			System.out.println(s1.getName());
////			synchronized(s1) {
////				s1 = (Course)session.merge(s1);
////			}
//			System.out.println(s1.getStudent().getName());
//		}
//	}
}
