package test;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import util.HibernateUtil;
import org.hibernate.*;
//330, 327
public class TestApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		SessionFactory sf = new AnnotationConfiguration().configure().addClass(test.Student.class).buildSessionFactory();
//		Session session = sf.openSession();
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

//        Student s = new Student();
//        s.setName("Test1");
//        s.setCal(new Date());	
//        s.setId(2);
//        session.save(s);
//
//        session.getTransaction().commit();
//        int id = s.getId();
//        session.close();		
//
//        session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Iterator it = session.createQuery("from test.Student s where s.name = 'Test1'" ).setCacheable(true).list().iterator();
        long startTime = System.currentTimeMillis();
        while(it.hasNext()) {
        	Student s1 = (Student)it.next();
        	System.out.println("Name = " + s1.getName() + ", Date = " + s1.getCal());
        	s1.setName("abc");
        }
        session.getTransaction().commit();
        System.out.println("Total Time = " + (System.currentTimeMillis() - startTime));
        session.close();
	}
	
//	public static void main(String[] args) throws Exception {
//		
//
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        List<Student> students = session.createQuery("from test.Student where student_id=26").setCacheable(true).setCacheRegion("abc.abc") .list();
//        for(int i = 0; i < students.size(); i++) {
//        	Student s = students.get(i);
////        Student s2 = (Student)session.get(Student.class, 26);
//        	System.out.println(s.getName());
//        }
//        Thread.sleep(1000000);
//        
//	}	

}
