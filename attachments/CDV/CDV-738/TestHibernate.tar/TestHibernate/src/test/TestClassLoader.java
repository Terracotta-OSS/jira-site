package test;

import java.net.URL;
import java.net.URLClassLoader;

public class TestClassLoader extends URLClassLoader{
	
	public TestClassLoader(ClassLoader parent) {
		super(new URL[0],parent);
	}

}
