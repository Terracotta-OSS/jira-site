package test;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class Student {
	private int id;
	private String name;
	private Date cal;
	private Set<Course> courses = new HashSet<Course>();
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setCal(Date cal) {
		this.cal = cal;
	}
	
	public Date getCal() {
		return cal;
	}
	
	public void setCourses(Set courses) {
		this.courses = courses;
	}
	
	public Set getCourses() {
		return courses;
	}
	
	public void addCourse(Course course) {
		this.courses.add(course);
		course.setStudent(this);
	}
}
