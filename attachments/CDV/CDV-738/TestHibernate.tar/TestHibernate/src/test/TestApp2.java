package test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestApp2 {

	/**
	 * @param args
	 */
	private static List temp;
	public static void main(String[] args) throws Exception {
		temp = new ArrayList();
		if(args != null) {
			synchronized(temp) {
				temp.add(1);
				temp.add(2);
				temp.add(3);
				temp.add(4);
				temp.add(5);
			}
			
			iterate();
		}
		else {
			synchronized(temp) {
				temp.add(100);
			}
		}
	}
	
	public static void iterate() throws Exception{
		Iterator it = temp.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			System.in.read();
		}
	}

}
