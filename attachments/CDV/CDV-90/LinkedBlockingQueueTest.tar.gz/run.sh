#!/bin/bash

function runWithoutTC() {
    echo "Running in non-tc mode"
    java -cp lbqt.jar com.tctest.concurrent.LinkedBlockingQueueTest 0
}

function runWithTC() {
    echo "Running in TC mode"
    let count=0
    while [ "$count" != "$1" ]
    do
        ./tc/dso/bin/dso-java.sh -Dtc.classloader.writeToDisk=true -cp lbqt.jar -Dtc.config=tc-config.xml com.tctest.concurrent.LinkedBlockingQueueTest $count &
        let count=$count+1
    done
}

if [ "$1" == "0" ]; then
    runWithoutTC
else
    runWithTC $1
fi
