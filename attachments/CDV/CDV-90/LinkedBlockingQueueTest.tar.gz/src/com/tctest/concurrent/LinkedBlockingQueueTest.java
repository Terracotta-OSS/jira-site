package com.tctest.concurrent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class LinkedBlockingQueueTest implements Runnable {

	private static final int NO_OF_OBJECTS = 2000;

	// root
	private final LinkedBlockingQueue queue = new LinkedBlockingQueue();

	private final int nodeID;

	private final SimpleDateFormat dateFormat = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss,SSS");

	public LinkedBlockingQueueTest(int nodeID) {
		this.nodeID = nodeID;
	}

	public static void main(String[] args) {
		if (args.length < 1) {
			System.err.println("Please pass in a node number");
			System.exit(1);
		}
		LinkedBlockingQueueTest test = new LinkedBlockingQueueTest(Integer
				.parseInt(args[0]));
		test.runTest();
	}

	public void runTest() {
		if(nodeID == 0) {
			populateQueue();
		} else {
			waitForPopulation();
			startReaders();
		}
	}

	private void waitForPopulation() {
		synchronized (queue) {
			while (queue.size() == 0) { // Explicitly not doing spin lock for a reason
				try {
					queue.wait(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void startReaders() {
		log("Starting Readers");
		int count = 5;
		while (count-- > 0) {
			Thread t = new Thread(this, "Reader-" + count);
			t.start();
		}
	}

	private void populateQueue() {
		if (nodeID == 0) {
			log("Populating queue");
			int count = NO_OF_OBJECTS;
			while (count-- > 0) {
				queue.add(new Long(count));
			}
			log("Population done");
			notifyPopulationComplete();
		} else {
			waitForPopulation();
		}
	}

	private void notifyPopulationComplete() {
		synchronized (queue) {
			queue.notifyAll();
		}
	}

	private void log(String message) {
		System.out.println("Node ID : " + nodeID + " Thread : "
				+ Thread.currentThread().getName() + " : "
				+ dateFormat.format(new Date()) + " : " + message);
	}

	public void run() {
		Object o = null;
		long timeTaken = 0;
		int count = 0;
		while (true) {
			long t1 = System.currentTimeMillis();
			try {
				o = queue.poll(3000, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			long t2 = System.currentTimeMillis();
			if (o == null) {
				break;
			}
			timeTaken += (t2 - t1);
			count++;
		}
		log("time taken = " + timeTaken + " ms count = " + count + " Avg = "
				+ (count != 0 ? (timeTaken / count) + " ms" : "NA"));
	}
}
