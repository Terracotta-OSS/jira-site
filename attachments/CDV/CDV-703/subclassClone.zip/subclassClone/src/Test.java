import java.util.ArrayList;

public class Test {

    private static final MyList<Object> root = new MyList<Object>();

    public static void main(String[] args) {
        Object clone = root.clone();
        if (!(clone instanceof MyList)) {
            throw new AssertionError("wrong type: "
                    + clone.getClass().getName());
        }
    }

    private static class MyList<E> extends ArrayList<E> {
        private final int field = 3; // must be here to force delegate instrumentation

        public int getField() {
            return field;
        }
    }
}
