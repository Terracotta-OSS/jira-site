package test;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class Foo {

	private final static ConcurrentMap<Object, Object> root = new ConcurrentHashMap<Object, Object>();

	public static void main(String[] args) {
		Parent p = new Parent();
		root.put("key", p.makeInner());
	}

	static class Parent {

		Inner makeInner() {
			return new Inner();
		}

		class Inner {
			//
		}
	}

}
