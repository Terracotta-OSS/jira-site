package test;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class TestRRWL {

	private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void test() {
		lock.writeLock().lock();
		System.out.println("locked " + name);
		lock.writeLock().unlock();
		System.out.println("unlocked " + name);
	}
}
