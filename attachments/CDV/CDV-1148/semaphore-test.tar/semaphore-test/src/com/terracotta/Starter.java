package com.terracotta;

public class Starter {
	public static void main(String[] args) throws Exception	{
		Thread getThread = new Thread(new Job(0));
		Thread getThread1 = new Thread(new Job(0));
		Thread putThread = new Thread(new Job(1));
		String signal = args[0];
		System.out.println("Signal input is : "+signal);
		if("get".equals(signal)){
			getThread.start();
			getThread1.start();
		}
		if("put".equals(signal)){
			putThread.start();
		}
//		getThread.join();
//		putThread.join();
//		getThread1.join();
	}
}
