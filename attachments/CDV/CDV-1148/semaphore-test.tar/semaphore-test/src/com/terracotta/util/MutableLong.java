package com.terracotta.util;

public class MutableLong {

	private long longValue;

	public MutableLong(long longValue) {
		this.longValue = longValue;
	}

	public void increment(long l) {
		longValue = longValue + l;
	}

	public void decrement(long l) {
		longValue = longValue - l;
	}

	public boolean isLessLessEqualTo(long l) {
		return longValue <= l;
	}

	public boolean isGreaterThan(long l) {
		return longValue > l;
	}

	public long longValue() {
		return longValue;
	}
}
