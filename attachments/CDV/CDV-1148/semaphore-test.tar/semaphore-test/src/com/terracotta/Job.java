package com.terracotta;

public class Job implements Runnable {

	public static final int GET = 0;
	public static final int PUT = 0;
	private int type = GET;
	private static Pool pool = new Pool();

	public Job(int type) {
		this.type = type;
	}

	public void run() {
		switch (type) {
		case 0: {
			try {
				System.out.println("The type was : "+type);
				System.out.println("Object obtained from pool is : "+pool.getItem());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			break;
		}
		case 1: {
			try {
				Thread.currentThread().sleep(15000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("The type was : "+type);
			pool.putItem("Object1");
			System.out.println("Object1 was put back in the pool");
			break;
		}
		default :	{
			System.out.println("Type Mismatch : "+type);
		}
		}
	}

}
