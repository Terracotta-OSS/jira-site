package com.terracotta;

import com.terracotta.util.Semaphore;

public class Pool {

	public Pool()	{
		items[0] = "Object1";
	}
	private static final int MAX_AVAILABLE = 1;
	private final Semaphore available = new Semaphore(MAX_AVAILABLE);

	public Object getItem() throws InterruptedException {
		available.acquire();
		return getNextAvailableItem();
	}

	public void putItem(Object x) {
		System.out.println("In putItem");
		if (markAsUnused(x))	{
			System.out.println("Here");
			available.release();
		}
	}

	// Not a particularly efficient data structure; just for demo

	protected Object[] items = new Object[MAX_AVAILABLE];
	protected boolean[] used = new boolean[MAX_AVAILABLE];

	protected synchronized Object getNextAvailableItem() {
		for (int i = 0; i < MAX_AVAILABLE; ++i) {
			if (!used[i]) {
				System.out.println("Here 1");
				used[i] = true;
				return items[i];
			}
		}
		return null; // not reached
	}

	protected synchronized boolean markAsUnused(Object item) {
		for (int i = 0; i < MAX_AVAILABLE; ++i) {
			if (item.equals(items[i])) {
				if (used[i]) {
					used[i] = false;
					return true;
				} else
					return false;
			}
		}
		return false;
	}

}
