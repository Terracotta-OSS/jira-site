/**
 * Test harness application.
 */
public class App {
	private ObjectWithFields object;

	public static void main(String[] args) {
		App app = new App();
		System.out.println("object is " + app.object);
	}

	public App() {
		if (object == null) {
			System.out.println("Creating new ObjectWithFields");
			object = new ObjectWithFields();
		} else {
			System.out.println("ObjectWithFields already exists");
		}
	}
}
