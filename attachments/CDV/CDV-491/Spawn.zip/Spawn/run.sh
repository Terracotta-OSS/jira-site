#!/bin/bash
#set -x

target=${1:-L1}

TC_HOME=/export1/dev/hhuynh/terracotta-2.4.5
export JAVA_HOME=/shares/terra/jdk/linux/hotspot1.5.0_12

if [ -z $TC_HOME ]; then
  echo "TC_HOME is not defined!"
  exit 1
fi

cd `dirname $0`
#clean up
rm -rf target/terracotta/*

l2_jvmargs="-XX:+HeapDumpOnOutOfMemoryError"
l1_jvmargs="-XX:+HeapDumpOnOutOfMemoryError -Dtc.config=localhost:9510"

workdir=`dirname $0`
classpath="target/classes"
if [ `uname | grep CYGWIN` ]; then
  classpath=`cygpath -w -p $classpath`
fi
stderr=stderr.txt
stdout=stdout.txt

# start L2
if [ $target = "L2" ]; then
  echo "starting L2"
  JAVA_OPTS=$l2_jvmargs $TC_HOME/bin/start-tc-server.sh -f $workdir/tc-config.xml 2>$stderr 1>$stdout &
  echo "Server proccess id: $!" > pid.txt
fi

# start L1's
if [ $target = "L1" ]; then
  echo "starting L1"
  $TC_HOME/bin/dso-java.sh $l1_jvmargs -cp $classpath tc.qa.Spawn 2>>$stderr 1>>$stdout &
  echo "L1 proccess id: $!" >> pid.txt
fi

