package tc.qa;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Spawn {
  private Map map = new HashMap();
  
  public void run() {
    synchronized (map) {
      map.put("timestamp", new Date());
    }
  }
  
  public static void main(String[] args) {
      new Spawn().run();
  }
}