import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class TestServlet extends HttpServlet {

  private Model model = new Model();

  @Override
  public void init() throws ServletException {
    model.getObjects().put("abc", new Object());
  }

  @Override
  public void destroy() {
    System.out.println("TestServlet destroy");
    // NOTE: deadlock at this point, TC tries to lock concurrent map in Model but
    // ClientLockManagerImpl is already shutting down and waits infinitely
    model.getObjects().get("abc");
  }
}
