import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.terracotta.modules.annotations.Root;

public class Model {

  @Root
  protected final ConcurrentMap<String, Object> objects =
      new ConcurrentHashMap<String, Object>();

  public ConcurrentMap<String, Object> getObjects() {
    return objects;
  }
}
