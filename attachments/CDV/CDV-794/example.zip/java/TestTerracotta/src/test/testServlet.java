package test;

import org.apache.log4j.Logger;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;

public class testServlet
    extends HttpServlet
{
  private static final Logger LOG = Logger.getLogger ("test");
  protected void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
      throws ServletException, IOException
  {
    httpServletResponse.sendRedirect("http://www.sandstone.com.au");
    if (httpServletResponse.isCommitted()) {
      LOG.debug("isCommitted returns TRUE");
    } else {
      LOG.debug("isCommitted returns FALSE");
    }
  }
}
