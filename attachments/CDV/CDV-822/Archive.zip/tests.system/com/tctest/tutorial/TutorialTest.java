/*
 * All content copyright (c) 2008 Terracotta, Inc., except as may otherwise be noted in a separate copyright notice.  All rights reserved.
 */
package com.tctest.tutorial;

import com.tctest.TestConfigurator;
import com.tctest.TransparentTestBase;
import com.tctest.TransparentTestIface;


public class TutorialTest extends TransparentTestBase implements TestConfigurator {

  protected Class getApplicationClass() {
    return TutorialTestApp.class;
  }

  public void doSetUp(TransparentTestIface t) throws Exception {
    t.getTransparentAppConfig().setClientCount(2);
    t.initializeTestRunner();
  }
  
}
