/*
 * All content copyright (c) 2008 Terracotta, Inc., except as may otherwise be noted in a separate copyright notice. All
 * rights reserved.
 */
package com.tctest.tutorial;

//import com.tc.object.config.ConfigLockLevel;
import com.tc.object.config.ConfigVisitor;
import com.tc.object.config.DSOClientConfigHelper;
import com.tc.object.config.TransparencyClassSpec;
import com.tc.simulator.app.ApplicationConfig;
import com.tc.simulator.listener.ListenerProvider;
import com.tc.util.Assert;
import com.tctest.runner.AbstractTransparentApp;

public class TutorialTestApp extends AbstractTransparentApp {

  private A root;

  public TutorialTestApp(String appId, ApplicationConfig cfg, ListenerProvider listenerProvider) {
    super(appId, cfg, listenerProvider);
  }

  public static void visitL1DSOConfig(ConfigVisitor visitor, DSOClientConfigHelper config) {
    String testClass = TutorialTestApp.class.getName();
    TransparencyClassSpec spec = config.getOrCreateSpec(testClass);
    spec.addRoot("root", "root");
    // intentionally missing autolock
    //config.addAutolock("* " + testClass + ".run()", ConfigLockLevel.WRITE);
    config.addIncludePattern(A.class.getName());
  }

  public void run() {
    root = new A();
    try {
      // attempt to mutate without a shared lock
      root.o = new Object();
    } catch (Throwable t) {
      // ignore unlocked object exception
    }
    Assert.assertNotNull(root.o);
  }

}

class A {
  Object o;

  A() {
    o = this;
  }
}

