import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

public class LockTest2 {
   private static LockTest2 s_instance = new LockTest2();
   
   private final ReentrantReadWriteLock m_lock = new ReentrantReadWriteLock();
   
   private void blockOnTwoResources() throws InterruptedException {
      lock();
      Object o = new Object();
      synchronized (o) {
         o.wait();
      }
      // problem also occurs w/ new Semaphore(0).acquire();
   }

   private void lock() {
      getLock().lock();
   }

   private boolean tryLock() {
      return getLock().tryLock();
   }

   private void unlock() {
      getLock().unlock();
   }

   private boolean isLocked() {
      return m_lock.isWriteLocked();
   }

   private WriteLock getLock() {
      return m_lock.writeLock();
   }

   private void verifyFirstResourceBlocked1() throws InterruptedException {
      Thread.sleep(2000);
      System.out.println("test 1: " + this + ".isLocked() is " + (isLocked() ? "ok" : "BAD!"));
   }
   
   private void verifyFirstResourceBlocked2() throws InterruptedException {
      Thread.sleep(4000);
      boolean bLockable = tryLock();
      if (bLockable) {
         unlock();
      }
      System.out.println("test 2: " + this + ".tryLock() is " + (! bLockable ? "ok" : "BAD!"));
   }

   @Override
   public String toString() {
      return "[isLocked=" + isLocked() + "]";
   }

   /**
    * @param args
    */
   public static void main(String [] args) throws Throwable {
      Thread t1 = new Thread() {
         @Override
         public void run() {
            try {
               s_instance.blockOnTwoResources();
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      };
      Thread t2 = new Thread() {
         @Override
         public void run() {
            try {
               s_instance.verifyFirstResourceBlocked1();
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      };
      Thread t3 = new Thread() {
         @Override
         public void run() {
            try {
               s_instance.verifyFirstResourceBlocked2();
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      };
      t1.start();
      t2.start();
      t3.start();
   }
}
