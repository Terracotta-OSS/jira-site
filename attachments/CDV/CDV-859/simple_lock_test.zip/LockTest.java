import java.util.concurrent.locks.ReentrantLock;

public class LockTest {
   private static LockTest s_instance = new LockTest();
   
   private final ReentrantLock m_lock = new ReentrantLock();
   
   private void blockOnTwoResources() throws InterruptedException {
      m_lock.lock();
      Object o = new Object();
      synchronized (o) {
         o.wait();
      }
      // problem also occurs w/ new Semaphore(0).acquire();
   }

   private void verifyFirstResourceBlocked1() throws InterruptedException {
      Thread.sleep(2000);
      System.out.println("test 1: " + this + ".isLocked() is " + (m_lock.isLocked() ? "ok" : "BAD!"));
   }
   
   private void verifyFirstResourceBlocked2() throws InterruptedException {
      Thread.sleep(4000);
      boolean bLockable = m_lock.tryLock();
      if (bLockable) {
         m_lock.unlock();
      }
      System.out.println("test 2: " + this + ".tryLock() is " + (! bLockable ? "ok" : "BAD!"));
   }

   @Override
   public String toString() {
      return "[isLocked=" + m_lock.isLocked() + "]";
   }

   /**
    * @param args
    */
   public static void main(String [] args) throws Throwable {
      Thread t1 = new Thread() {
         @Override
         public void run() {
            try {
               s_instance.blockOnTwoResources();
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      };
      Thread t2 = new Thread() {
         @Override
         public void run() {
            try {
               s_instance.verifyFirstResourceBlocked1();
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      };
      Thread t3 = new Thread() {
         @Override
         public void run() {
            try {
               s_instance.verifyFirstResourceBlocked2();
            } catch (Throwable t) {
               t.printStackTrace();
            }
         }
      };
      t1.start();
      t2.start();
      t3.start();
   }
}
