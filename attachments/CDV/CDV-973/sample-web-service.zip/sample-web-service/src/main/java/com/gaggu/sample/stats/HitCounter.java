package com.gaggu.sample.stats;

import org.terracotta.modules.annotations.InstrumentedClass;
import org.terracotta.modules.annotations.Root;

@InstrumentedClass
public class HitCounter {
	@Root
	private int count;
	
	public int getCount() {
		return count;
	}
	
	public int increment() {
		++count;
		return count;
	}
}
