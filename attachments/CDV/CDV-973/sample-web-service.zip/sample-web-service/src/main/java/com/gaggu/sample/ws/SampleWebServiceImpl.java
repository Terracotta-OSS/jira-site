package com.gaggu.sample.ws;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import com.gaggu.sample.stats.HitCounter;

//WS
@WebService(name = "SampleWebService", serviceName = "SampleWebService", targetNamespace = "ws.sample.gaggu.com", endpointInterface = "com.gaggu.sample.ws.SampleWebService")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL, parameterStyle = SOAPBinding.ParameterStyle.BARE)
// EJB
@Stateless
@Remote(SampleWebService.class)
public class SampleWebServiceImpl implements SampleWebService {
	private HitCounter hitCounter = new HitCounter();

	public boolean isAlive() {
		return true;
	}

	public void registerHit() {
		hitCounter.increment();
	}

}
