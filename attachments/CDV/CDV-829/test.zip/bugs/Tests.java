package bugs;
 
 import java.util.concurrent.LinkedBlockingQueue;
 
 public class Tests {
 	public static class Buggy<T> extends LinkedBlockingQueue<T> {
 		private final Buggy<T> m_myself = this;
 	}
 
 	public static class BuggyHackedToBeOkay<T> extends LinkedBlockingQueue<T> {
 		private final BuggyHackedToBeOkay<T> m_myself = this;
 		public boolean equals(Object other) { return this == other; }
 	}
 
 	public static class Okay {
 		private final Okay m_myself = this;
 	}
 
 	public static void main(String [] args) {
 		Object [] objs = new Object [] { new Buggy(), new Okay(), new BuggyHackedToBeOkay() };
 
 		for (Object o : objs) {
 			System.out.println(o.getClass() + " equals() is reflexive? " + (o.equals(o) ? "yes" : "no"));
 		}
 	}
 }
