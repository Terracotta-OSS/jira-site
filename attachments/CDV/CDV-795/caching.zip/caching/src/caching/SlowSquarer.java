package caching;

public class SlowSquarer implements Squarer {

  public int square(int in) {
    sleepSeconds(3);        // make it slow
    return in*in;
  }
  
  private void sleepSeconds(int seconds) {
    try {
      Thread.sleep(seconds*1000); 
    } catch(InterruptedException e) {
      // ignore for this demo
    }
  }
}
