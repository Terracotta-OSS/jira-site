package caching;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

  private Squarer squarer;
  
  public void setSquarer(Squarer squarer) {
    this.squarer = squarer;
  }
  
  public void start() {
    int count = 10;
    System.out.println("Starting calls to squarer");
    long start = System.currentTimeMillis();
    for(int i=0; i<count; i++) {
      squarer.square(10);
    }
    long end = System.currentTimeMillis();
    System.out.println("Finished " + count + " calls");
    
    long elapsed = end-start;
    System.out.println("Elapsed = " + elapsed);
    System.out.println("Average = " + (elapsed / count) + " ms");
  }

  public static void main(String[] args) {
    ApplicationContext ctx = new ClassPathXmlApplicationContext("app.xml");
    Main main = (Main) ctx.getBean("main");
    main.start();
  }
  

}
