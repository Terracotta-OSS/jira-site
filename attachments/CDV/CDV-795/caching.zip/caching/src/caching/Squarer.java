package caching;

public interface Squarer {

  int square(int in);
}
