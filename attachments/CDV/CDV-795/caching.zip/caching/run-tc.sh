#!/bin/sh

export LIBS=/Users/amiller/Work/Components

export CP=./bin
export CP=$CP:$LIBS/spring-framework-2.0.8/dist/spring.jar
export CP=$CP:$LIBS/commons-logging-1.1.1/commons-logging-1.1.1.jar
export CP=$CP:$LIBS/spring-modules-0.9-with-dependencies/spring-modules-cache.jar
export CP=$CP:$LIBS/ehcache-1.3.0/ehcache-1.3.0.jar
export CP=$CP:$LIBS/jsr107/jsr107cache-1.0.jar

dso-java.sh -cp $CP caching.Main
