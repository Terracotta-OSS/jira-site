package com.comptel.pcc.prototype;

import java.util.Collection;
import net.sf.ehcache.CacheEntry;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.writer.CacheWriter;
import net.sf.ehcache.writer.writebehind.operations.SingleOperationType;

public class FileCacheWriter implements CacheWriter {

    @Override
    public void init() {
        System.out.println(">>>>>>>>>>>>>>>>>>>>> FileCacheWriter is initialized");
    }

    @Override
    public void dispose() throws CacheException {
        System.out.println(">>>>>>>>>>>>>>>>>>>>> FileCacheWriter is disposed");
    }

    @Override
    public void write(Element element) throws CacheException {
        System.out.println(">>>>>>>>>>>>>>>>>>>>> FileCacheWriter write " + element);
    }

    @Override
    public void writeAll(Collection<Element> elements) throws CacheException {
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> FileCacheWriter writeAll " + elements.size());
    }

    @Override
    public void delete(CacheEntry entry) throws CacheException {
    }

    @Override
    public void deleteAll(Collection<CacheEntry> entries) throws CacheException {
    }

    public CacheWriter clone(Ehcache ehch) throws CloneNotSupportedException {
       throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void throwAway(Element elmnt, SingleOperationType sot, RuntimeException re) {
        re.printStackTrace();
    }
}