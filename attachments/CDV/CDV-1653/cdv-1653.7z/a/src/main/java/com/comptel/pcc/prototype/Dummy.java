package com.comptel.pcc.prototype;

import java.net.URL;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheWriterConfiguration;

public class Dummy {

    private Dummy() {
    }

    private CacheManager createCacheManager() {
        URL configurationURL = getClass().getResource("/acc-client-pcc-ehcache_3.xml");
        return CacheManager.newInstance(configurationURL);
    }

    public static void main(String[] args) throws InterruptedException {
        Dummy client = new Dummy();
        CacheManager cacheManager = client.createCacheManager();
        Cache cache = cacheManager.getCache("account-datastore");
        for (int i = 0; i < 200; i++) {
            System.out.println("Putting element " + i + "...");
            cache.putWithWriter(new Element(i, i));

            //Thread.sleep(500);
        }
        cache.flush();
        System.out.println("Done!");
    }
}
