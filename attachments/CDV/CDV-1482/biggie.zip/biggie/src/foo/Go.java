package foo;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Go {

	private static final Map<String, Object> root = new ConcurrentHashMap<String, Object>();

	public static void main(String[] args) {
		root.put("test", new SubBigDecimal("42"));
		root.put("test", new SubBigInteger("37"));
	}

	private static class SubBigDecimal extends BigDecimal {

		private static final long serialVersionUID = 1L;

		public SubBigDecimal(String val) {
			super(val);
		}
	}

	private static class SubBigInteger extends BigInteger {

		private static final long serialVersionUID = 1L;

		public SubBigInteger(String val) {
			super(val);
		}
	}

}
