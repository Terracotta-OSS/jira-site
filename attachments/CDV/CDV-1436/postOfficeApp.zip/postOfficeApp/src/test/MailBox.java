package test;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import com.tc.cluster.DsoCluster;
import com.tc.cluster.DsoClusterEvent;
import com.tc.cluster.DsoClusterListener;
import com.tc.injection.annotations.InjectedDsoInstance;

public class MailBox implements DsoClusterListener {

	@InjectedDsoInstance
	private DsoCluster cluster;

	private final int boxId;
	private final int numOfClients;

	private final Map<Integer, LinkedBlockingQueue<Integer>> mailBoxMap = new ConcurrentHashMap<Integer, LinkedBlockingQueue<Integer>>();

	public MailBox(int boxId, int numOfClients) {
		this.boxId = boxId;
		this.numOfClients = numOfClients;

		if (this.boxId == 0) {
			for (int i = 0; i < this.numOfClients; i++) {
				this.mailBoxMap.put(i, new LinkedBlockingQueue<Integer>());
			}
		}

		cluster.addClusterListener(this);
	}

	public void start() {
		Thread consumer = new Thread(new Consumer(this.boxId, this.mailBoxMap),
				"Consumer " + this.boxId);
		consumer.start();
		if (this.boxId == 0) {
			int mailNumber = 0;
			while (true) {
				for (int i = 0; i < this.numOfClients; i++) {
					this.mailBoxMap.get(i).add(mailNumber);
				}
				mailNumber++;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		try {
			consumer.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static class Consumer implements Runnable {
		private final int boxId;
		private final Map<Integer, LinkedBlockingQueue<Integer>> mailBoxMap;

		public Consumer(int boxId,
				Map<Integer, LinkedBlockingQueue<Integer>> mailBoxMap) {
			this.boxId = boxId;
			this.mailBoxMap = mailBoxMap;
		}

		public void run() {
			LinkedBlockingQueue<Integer> mailQueue = this.mailBoxMap
					.get(this.boxId);

			while (true) {
				try {
					int mailNumber = mailQueue.take();
					Thread.sleep(500);
					if (mailNumber % 10 == 0) {
						System.out.println("client " + this.boxId
								+ " got mail number " + mailNumber);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}

	public void nodeJoined(DsoClusterEvent event) {
		System.out.println("The node " + event.getNode()
				+ " joined the cluster");
	}

	public void nodeLeft(DsoClusterEvent event) {
		System.out.println("The node " + event.getNode() + " left the cluster");
	}

	public void operationsDisabled(DsoClusterEvent event) {
		System.out.println("The node " + event.getNode()
				+ "has ceased operations.");
	}

	public void operationsEnabled(DsoClusterEvent event) {
		System.out.println("The node " + event.getNode()
				+ "has started operations.");
	}
}
