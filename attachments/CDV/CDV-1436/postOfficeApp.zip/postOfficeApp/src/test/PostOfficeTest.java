package test;

public class PostOfficeTest {

	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("usage <clientid> <num of clients> ");
			System.exit(-1);
		}
		MailBox mailBox = new MailBox(Integer.parseInt(args[0]), Integer
				.parseInt(args[1]));
		mailBox.start();
	}
}
