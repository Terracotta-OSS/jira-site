package example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public TestServlet() {
		//
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.err.println(request.getClass().getName());

		HttpSession session = request.getSession(true);

		System.err.println(session.getClass().getName());
		System.err.println(session.getId());

		while (request instanceof HttpServletRequestWrapper) {
			request = (HttpServletRequest) ((HttpServletRequestWrapper) request)
					.getRequest();
			System.err.println("unwrapped to " + request.getClass().getName());
		}

		session = request.getSession(true);

		System.err.println(session.getClass().getName());
		System.err.println(session.getId());
	}
}
