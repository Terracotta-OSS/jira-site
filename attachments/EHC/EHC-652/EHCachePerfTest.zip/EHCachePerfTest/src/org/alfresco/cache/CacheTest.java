package org.alfresco.cache;

import java.net.URL;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.Status;

/**
 * @author Derek Hulley, Alfresco Software
 */
public class CacheTest
{
    private static final String CACHE_CONFIG = "/org/alfresco/cache/cache-test-config.xml";
    private static final String CACHE_NAME = "cache1";
    
    private CacheManager cacheManager;
    private Ehcache cache;
    
    public void setUp() throws Exception
    {
        URL configUrl = getClass().getResource(CACHE_CONFIG);
        if (configUrl == null)
        {
            throw new RuntimeException("Unabled to find config: " + CACHE_CONFIG);
        }
        cacheManager = new CacheManager(configUrl);
        cache = cacheManager.getEhcache(CACHE_NAME);
        // Check that it is not linked to a disk store
        if (cache.getCacheConfiguration().isOverflowToDisk())
        {
            throw new RuntimeException("This test is not intended for disk-persistent caches");
        }
    }
    
    public void tearDown()
    {
        if (cacheManager != null && cacheManager.getStatus().equals(Status.STATUS_UNINITIALISED))
        {
            cacheManager.shutdown();
        }
    }
    
    /**
     * Preloads the cache, then removes and re-adds each value
     * 
     * @return Returns the time it took in <b>nanoseconds</b>.
     */
    public long runPerformanceTestOnCache(Ehcache cache, int objectCount)
    {
        // preload
        for (int i = 0; i < objectCount; i++)
        {
            String key = Integer.toString(i);
            Integer value = new Integer(i);
            Element element = new Element(key, value);
            cache.put(element);
        }
        
        // start timer
        long start = System.nanoTime();
        for (int i = 0; i < objectCount; i++)
        {
            String key = Integer.toString(i);
            cache.remove(key);
            // add a new value
            key = Integer.toString(i + objectCount);
            Integer value = new Integer(i + objectCount);
            Element element = new Element(key, value);
            cache.put(element);
        }
        // stop
        long stop = System.nanoTime();
        
        return (stop - start);
    }
    
    /**
     * Tests a straight Ehcache adapter against a transactional cache both in and out
     * of a transaction.  This is done repeatedly, pushing the count up.
     */
    public void testPerformance() throws Exception
    {
        for (int i = 0; i < 6; i++)
        {
            int count = (int) Math.pow(10D, (double)i);
            
            // test standalone
            long timePlain = runPerformanceTestOnCache(cache, count);
            
            // report
            System.out.println("Cache performance test: \n" +
                    "   count: " + count + "\n" +
                    "   direct: " + timePlain/((long)count) + " ns\\count"); 
        }
    }
    
    /**
     * @see #testPerformance()
     */
    public static void main(String ... args)
    {
        CacheTest test = new CacheTest();
        try
        {
            System.out.println("Press any key to run test with new LRU ...");
            System.in.read();

            test.setUp();

            System.out.println("** New LRU **");
            test.testPerformance();
        }
        catch (Throwable e)
        {
            e.printStackTrace();
        }
        finally
        {
            test.tearDown();
        }

        test = new CacheTest();
        try
        {
            System.out.println("Press any key to run test with old LRU ...");
            System.in.read();
            
            System.setProperty("net.sf.ehcache.use.classic.lru", "true");
            test.setUp();
            
            System.out.println("** Old LRU **");
            test.testPerformance();
            
            System.out.println("Press any key to shutdown ...");
            System.in.read();
        }
        catch (Throwable e)
        {
            e.printStackTrace();
        }
        finally
        {
            test.tearDown();
        }
    }
}
