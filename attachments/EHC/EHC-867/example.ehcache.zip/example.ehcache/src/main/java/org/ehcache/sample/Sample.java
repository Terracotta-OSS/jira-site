package org.ehcache.sample;

import java.util.concurrent.CyclicBarrier;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.TransactionController;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.CacheConfiguration.TransactionalMode;
import net.sf.ehcache.config.Configuration;

public class Sample
{
	private CacheManager cacheManager;
	private Ehcache cache;
	private TransactionController transactionManager;
	private CyclicBarrier start;
	private CyclicBarrier end;

	public void start(int threads)
	{
		start = new CyclicBarrier(threads);
		end = new CyclicBarrier(threads + 1);
		initializeCache();
		this.transactionManager = cacheManager.getTransactionController();
		for(int i = 0;i < threads;i++)
		{
			(new Thread(new Runnable()
			{
				public void run()
				{
					try
					{
						start.await();
						getAll();
						getAll();
						end.await();
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
			})).start();
		}
		try
		{
			end.await();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private Element getCacheElement(int i)
	{
		Element e = (Element)cache.get(i);
		if(e == null)
		{
			e = new Element(i,"Element " + i);
			cache.put(e);
			try
			{
				Thread.sleep(50);
			}
			catch(Exception ignored)
			{
			}
		}
		return(e);
	}

	private void getAll()
	{
		transactionManager.begin();
		try
		{
			for(int i = 0;i < 100;i++)
			{
				System.out.println(Thread.currentThread().getName() + ":" + getCacheElement(i));
			}
		}
		finally
		{
			transactionManager.commit();
		}
	}

	private void initializeCache()
	{

		Configuration cacheManagerConfig = new Configuration();
		cacheManagerConfig.addDefaultCache(new CacheConfiguration());
		CacheConfiguration cacheConfig = new CacheConfiguration("cache",-1);
		cacheConfig.setTimeToIdleSeconds(0L);
		cacheConfig.setTimeToLiveSeconds(1L);
		cacheConfig.transactionalMode(TransactionalMode.LOCAL);
		cacheManagerConfig.addCache(cacheConfig);
		cacheManager = new CacheManager(cacheManagerConfig);
		cache = cacheManager.getEhcache("cache");
	}

	public final static void main(String[] args) throws Exception
	{
		new Sample().start(3);
	}
}
