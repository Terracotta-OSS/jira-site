package test.ehcache;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * Extension for {@link java.io.ByteArrayOutputStream} which allows to serialize ByteArrayOutputStream.
 */
public class SerializableByteArrayOutputStream extends ByteArrayOutputStream implements Serializable {
    private static final int BUFFER_SIZE = 1024;

    private void writeObject(ObjectOutputStream out) throws IOException {
        this.writeTo(out);
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        byte[] bytes = new byte[BUFFER_SIZE];
        int bytesRead = 1;
        while (bytesRead > 0) {
            bytesRead = in.read(bytes);
            if (bytesRead > 0) {
                this.write(bytes, 0, bytesRead);
            }
        }
    }
}
