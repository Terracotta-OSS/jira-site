package test.ehcache;

/**
 * @author ihrytsyuk
 */
public class CacheTestConstants {

    public static final Integer TEST_DELAY = 300;
    public static final Integer TEST_STATISTICS_DELAY = 60000;
    public static final Integer TEST_THREADS_COUNT = 150;


    public static final String SHORT_STRING_CACHE_KEY = "ShortStringResultKey";
    public static final String LONG_STRING_CACHE_KEY = "LongStringResultKey";
    public static final String INTEGER_CACHE_KEY = "IntegerResultKey";
    public static final String BA_CACHE_KEY = "ByteArrayOutputStreamResultKey";
    public static final String EXPECTED_SHORT_STRING_RESULT = "10";
    public static final String EXPECTED_LONG_STRING_RESULT = CacheUtils.generateLongString(236793);
    public static final Integer EXPECTED_INTEGER_RESULT = 1001;
    public static final SerializableByteArrayOutputStream EXPECTED_BA_RESULT = CacheUtils.generateLongSerializableByteArrayOutputStream(216773);


}
