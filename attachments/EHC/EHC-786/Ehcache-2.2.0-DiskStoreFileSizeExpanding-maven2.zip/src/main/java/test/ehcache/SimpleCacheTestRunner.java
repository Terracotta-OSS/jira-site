package test.ehcache;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Runs cache test.
 */
public class SimpleCacheTestRunner {
    private static final Logger LOG = LoggerFactory.getLogger(SimpleCacheTestRunner.class);
    private static final Logger LOG_ERROR = LoggerFactory.getLogger("ErrorSimpleCacheTestRunner");
    private static final Ehcache MAIN_CACHE = CacheManager.getInstance().getEhcache("test.METHOD_CACHE");
    private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(CacheTestConstants.TEST_THREADS_COUNT * 4);

    /**
     * Please periodically  check if cache-test-error.log contains error messages.
     */
    public static void main(String[] args) throws InterruptedException {
        LOG.info("Started testing...");
        LOG_ERROR.info("Started testing...");
        LOG_ERROR.info("Error messages will appear here:");

        new Timer("Test Timer").schedule(new TimerTask() {
            public void run() {
                for (int i = 0; i < CacheTestConstants.TEST_THREADS_COUNT; i++) {
                    EXECUTOR_SERVICE.submit(new CacheTestShortStringRunnable());
                    EXECUTOR_SERVICE.submit(new CacheTestIntegerRunnable());
                    EXECUTOR_SERVICE.submit(new CacheTestLongStringRunnable());
                    EXECUTOR_SERVICE.submit(new CacheTestSerializableByteArrayOutputStreamRunnable());
                }
            }
        }, 0, CacheTestConstants.TEST_DELAY);

        new Timer("PrintStatistics Timer").schedule(new TimerTask() {
            public void run() {
                String stat = CacheUtils.getCacheStatistics(MAIN_CACHE);
                LOG.info(stat);
            }
        }, 0, CacheTestConstants.TEST_STATISTICS_DELAY);
    }

    static class BaseCacheTestRunnable<T> implements Runnable {
        private final String m_key;
        private final T m_expectedResult;

        BaseCacheTestRunnable(String key, T expectedResult) {
            m_key = key;
            m_expectedResult = expectedResult;
        }

        public void run() {
            try {
                LOG.debug("Looking for key [{}]", m_key);
                Element element = MAIN_CACHE.get(m_key);
                if (element == null) {
                    MAIN_CACHE.put(new Element(m_key, m_expectedResult));
                } else {
                    T value;
                    value = (T) element.getObjectValue();
                    if (!m_expectedResult.toString().equals(value.toString())) {
                        LOG_ERROR.error("ERROR: got wrong result. Expected element for key [{}] but got for key [{}]", m_key, element.getKey());
                    }
                }
            } catch (Exception e) {
                LOG_ERROR.error("GOT Exception: ", e);
            }
        }
    }

    static class CacheTestShortStringRunnable extends BaseCacheTestRunnable<String> {
        CacheTestShortStringRunnable() {
            super(CacheTestConstants.SHORT_STRING_CACHE_KEY, CacheTestConstants.EXPECTED_SHORT_STRING_RESULT);
        }
    }

    static class CacheTestLongStringRunnable extends BaseCacheTestRunnable<String> {
        CacheTestLongStringRunnable() {
            super(CacheTestConstants.LONG_STRING_CACHE_KEY, CacheTestConstants.EXPECTED_LONG_STRING_RESULT);
        }
    }

    static class CacheTestIntegerRunnable extends BaseCacheTestRunnable<Integer> {
        CacheTestIntegerRunnable() {
            super(CacheTestConstants.INTEGER_CACHE_KEY, CacheTestConstants.EXPECTED_INTEGER_RESULT);
        }
    }

    static class CacheTestSerializableByteArrayOutputStreamRunnable extends BaseCacheTestRunnable<SerializableByteArrayOutputStream> {
        CacheTestSerializableByteArrayOutputStreamRunnable() {
            super(CacheTestConstants.BA_CACHE_KEY, CacheTestConstants.EXPECTED_BA_RESULT);
        }
    }


}
