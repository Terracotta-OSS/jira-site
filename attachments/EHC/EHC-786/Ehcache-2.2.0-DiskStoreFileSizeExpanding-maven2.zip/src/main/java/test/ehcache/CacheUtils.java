package test.ehcache;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Statistics;
import net.sf.ehcache.statistics.LiveCacheStatistics;

/**
 * @author ihrytsyuk
 */
public class CacheUtils {

    public static SerializableByteArrayOutputStream generateLongSerializableByteArrayOutputStream(int charsCount) {
        SerializableByteArrayOutputStream serializableByteArrayOutputStream = new SerializableByteArrayOutputStream();
        for (int i = 0; i < charsCount; i++) {
            serializableByteArrayOutputStream.write('c');
            if (i % 60 == 0) {
                serializableByteArrayOutputStream.write('\n');
            }
        }
        return serializableByteArrayOutputStream;
    }

    public static String getCacheStatistics(Ehcache cache) {
        StringBuilder result = new StringBuilder();
        cache.setStatisticsAccuracy(Statistics.STATISTICS_ACCURACY_BEST_EFFORT);
        LiveCacheStatistics liveCacheStatistics = cache.getLiveCacheStatistics();
        float successRate = 0.0f;

        result.append("CacheName=").append(liveCacheStatistics.getCacheName()).append("; ");
        result.append("AverageGetTimeMillis=").append(liveCacheStatistics.getAverageGetTimeMillis()).append("; ");
        result.append("CacheHitCount=").append(liveCacheStatistics.getCacheHitCount()).append("; ");
        result.append("UpdateCount=").append(liveCacheStatistics.getUpdateCount()).append("; ");
        result.append("PutCount=").append(liveCacheStatistics.getPutCount()).append("; ");
        result.append("ExpiredCount=").append(liveCacheStatistics.getExpiredCount()).append("; ");
        result.append("EvictedCount=").append(liveCacheStatistics.getEvictedCount()).append("; ");
        result.append("InMemoryHitCount=").append(liveCacheStatistics.getInMemoryHitCount()).append("; ");
        result.append("OnDiskHitCount=").append(liveCacheStatistics.getOnDiskHitCount()).append("; ");
        result.append("Size=").append(liveCacheStatistics.getSize()).append("; ");
        result.append("CacheMissCount=").append(liveCacheStatistics.getCacheMissCount()).append("; ");

        float totalHits = liveCacheStatistics.getCacheMissCount() + liveCacheStatistics.getCacheHitCount();
        if (totalHits != 0) {
            successRate = liveCacheStatistics.getCacheHitCount() / totalHits;
        }
        result.append("SuccessRate=").append(successRate).append("; ");
        return result.toString();
    }

    public static String generateLongString(int charsCount) {
        StringBuilder result = new StringBuilder(charsCount);
        for (int i = 0; i < charsCount; i++) {
            result.append('L');
            if (i % 60 == 0) {
                result.append('\n');
            }
        }
        return result.toString();
    }
}
