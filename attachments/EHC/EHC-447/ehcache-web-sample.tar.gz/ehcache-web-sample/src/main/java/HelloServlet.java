import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		resp.setContentType("text/html");
		Date date = new Date();
		PrintWriter out = new PrintWriter(resp.getOutputStream());
		out.println("This page was generated at: " + date);
		System.out.println("GENERATED CONTENT AT: " + date);
		out.close();
	}

}
