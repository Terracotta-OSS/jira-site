package org.tc;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;

public class ProgramaticallyCreateEhcache {

	CacheManager 	cacheManager = CacheManager.getInstance();
	Cache 			cache;
	
	public ProgramaticallyCreateEhcache(){
		System.out.println("Creating cache ...");
		cache = new Cache("regionName",         	// String name
		        1000,                       		// int maxElementsInMemory
		        MemoryStoreEvictionPolicy.LRU,    	// MemoryStoreEvictionPolicy
		        false,                            	// boolean overflowToDisk
		        null,                             	// String diskStorePath
		        false,                        		// boolean eternal
		        120,                				// long timeToLiveSeconds
		        120,                				// long timeToIdleSeconds
		        false,                            	// boolean diskPersistent
		        120,  								// long diskExpiryThreadIntervalSeconds
		        null,                             	// RegisteredEventListeners
		        null,                             	// BootstrapCacheLoader 
		        0,                                	// int maxElementsOnDisk
		        0,                                	// int diskSpoolBufferSizeMB
		        true,                             	// boolean clearOnFlush
		        true,                             	// boolean isTerracottaClustered
		        "serialization",                  	// String terracottaValueMode
		        false);                           	// boolean terracottaCoherentReads
			cacheManager.addCache(cache);
			System.out.println("Created cache ... " + cache.getName());
	}
	
	public static void main(String[] args) {
		new ProgramaticallyCreateEhcache();

	}

}
