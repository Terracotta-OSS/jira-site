Rename src/main/resources/ehcache.xml to any other name to get following exception

 Exception in thread "main" net.sf.ehcache.CacheException: no terracotta configuration has been initalized for this cache manager
  at net.sf.ehcache.CacheManager.createTerracottaStore(CacheManager.java:323)
  at net.sf.ehcache.Cache.initialise(Cache.java:698)
  at net.sf.ehcache.CacheManager.addCacheNoCheck(CacheManager.java:784)
  at net.sf.ehcache.CacheManager.addCache(CacheManager.java:774)
  at net.sf.ehcache.CacheManager.addCache(CacheManager.java:752)
  at org.tc.ProgramaticallyCreateEhcache.<init>(ProgramaticallyCreateEhcache.java:31)
  at org.tc.ProgramaticallyCreateEhcache.main(ProgramaticallyCreateEhcache.java:36)