package org.test.category;

import java.io.InputStream;
import java.io.ObjectInputStream;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Test;

public class CategoryTreeTest {

	private static final Log log = LogFactory
			.getLog(CategoryTreeTest.class);

	@Test
	public void testGetBuildCategoryTree() throws Exception {
		String key = "Foo";
//		Integer key = 123;
		CacheManager cacheManager = CacheManager.getInstance();
		Cache categoryTreeCache = cacheManager.getCache("categoryTree");
		
		log.info("Removing key");
		categoryTreeCache.remove(key);
		
		log.info("Testing cache put");
		InputStream inStream = CategoryTreeTest.class
				.getResourceAsStream("/tree.obj");
		ObjectInputStream ois = new ObjectInputStream(inStream);
		com.build.domain.category.CategoryTree categoryTree = (com.build.domain.category.CategoryTree) ois
				.readObject();
		categoryTreeCache.put(new Element(key, categoryTree));
		
		long cachePutMemorySize = 0;
		while (cachePutMemorySize == 0) {
			Thread.sleep(500);
			cachePutMemorySize = categoryTreeCache.calculateInMemorySize();
		}
		
		log.info("categoryTreeCache in memory size after put: "
			+ cachePutMemorySize);
		
		log.info("Testing cache get");
		categoryTreeCache.get(key);
		long cacheGetMemorySize = categoryTreeCache.calculateInMemorySize();
		log.info("categoryTreeCache in memory size after get: "
				+ cacheGetMemorySize);
		Assert.assertEquals("Cache memory size mismatch between get and put", cachePutMemorySize, cacheGetMemorySize);

	}

}
