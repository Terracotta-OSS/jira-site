package pl.contium;

import static org.fest.assertions.Assertions.assertThat;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;

import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class EhcacheHibernateTest {

	private InMemoryDb db;


	@Test
	public void shouldHaveOnlyMaxElementsInCacheAfterCreateAndDelete() throws Exception {

		// given
		Cache entityCache = CacheManager.getInstance().getCache(EntityImpl.REGION_NAME);
		long maxEntriesLocalHeap = 10;
		entityCache.getCacheConfiguration().setMaxEntriesLocalHeap(maxEntriesLocalHeap);

		// when
		createAndRemoveEntity(100);

		// then
		assertThat(entityCache.getCacheConfiguration().getMaxEntriesLocalHeap()).isEqualTo(maxEntriesLocalHeap);
		// BUG ?!
		assertThat(entityCache.getSize()).isEqualTo((int) maxEntriesLocalHeap);
	}

	private void createAndRemoveEntity(int i) {

		Session session = db.createSession();

		for (int j = 0; j < i; j++) {
			EntityImpl entity = new EntityImpl();
			session.save(entity);
			session.delete(entity);
		}

		session.flush();
		session.clear();
		session.close();
	}

	@Before
	public void setUp() throws Exception {
		db = new InMemoryDb();
	}

	@After
	public void tearDown() {
		db.close();
	}
}
