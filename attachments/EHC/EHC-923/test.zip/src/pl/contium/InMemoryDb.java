package pl.contium;

import java.util.Properties;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;


/**
 * DB for testing 
 */
public class InMemoryDb {

	private static final boolean DONT_PRINT_TO_SYSOUT = false;
	private static final boolean EXPORT_TO_DB = true;

	private String uid;
	private SessionFactory sessionFactory;


	public InMemoryDb() {
		uid = UUID.randomUUID().toString();
		initDb();
	}

	public Session createSession() {

		return sessionFactory.openSession();
	}

	private void initDb() {

		Configuration cfg = buildConfiguration();
		sessionFactory = cfg.buildSessionFactory();

		SchemaExport schemaExport = new SchemaExport(cfg);
		schemaExport.create(DONT_PRINT_TO_SYSOUT, EXPORT_TO_DB);
	}

	private Configuration buildConfiguration() {

		Configuration cfg = new Configuration();

		cfg.addAnnotatedClass(EntityImpl.class);

		cfg.addProperties(properties());

		return cfg;

	}

	private Properties properties() {

		Properties p = new Properties();

		p.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		p.setProperty("hibernate.connection.driver_class", "org.h2.Driver");
		p.setProperty("hibernate.connection.url", "jdbc:h2:mem:testdb-" + uid + ";MODE=PostgreSQL");
		p.setProperty("hibernate.connection.username", "sa");
		p.setProperty("hibernate.connection.password", "");
		p.setProperty("hibernate.connection.pool_size", "10");
		p.setProperty("hibernate.connection.autocommit", "true");
		p.setProperty("hibernate.show_sql", "true");
		p.setProperty("hibernate.cache.region.factory_class", "net.sf.ehcache.hibernate.SingletonEhCacheRegionFactory");
		p.setProperty("hibernate.cache.use_query_cache", "true");

		return p;
	}

	public void close() {

		if (sessionFactory != null && !sessionFactory.isClosed()) {
			sessionFactory.close();
		}
	}
}

