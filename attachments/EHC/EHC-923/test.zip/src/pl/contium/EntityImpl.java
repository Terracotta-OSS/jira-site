package pl.contium;

import static org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;


@Entity
@Table(name = "b24_entities")
@Cache(region = "EntityImpl", usage = READ_WRITE)
public class EntityImpl {

	public static final String REGION_NAME = "EntityImpl";

	long id;


	public void setId(long id) {
		this.id = id;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long getId() {
		return id;
	}
}
