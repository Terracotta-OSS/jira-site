import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.CacheConfiguration.TransactionalMode;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.DiskStoreConfiguration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.transaction.annotation.Transactional;

public class ECHXABug {
    private static final Logger LOGGER = LoggerFactory.getLogger(ECHXABug.class);
    
    private CacheManager        cacheManager;
    
    private CacheConfiguration  cacheConfiguration;
    
    private Cache               cache;
    
    /**
     * main.
     * 
     * @param args
     * @throws Exception
     */
    public static void main(final String[] args) throws Exception {
        try {
            final ApplicationContext context = new GenericXmlApplicationContext("/META-INF/applicationContext.xml");
            final ECHXABug main = context.getBean(ECHXABug.class);
            main.createCache();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            System.exit(0);
        }
    }
    
    @Transactional
    public void createCache() {
        this.cacheConfiguration = new CacheConfiguration("MyCache", 5000).diskPersistent(true).eternal(true)
                .diskExpiryThreadIntervalSeconds(1).maxElementsInMemory(70).transactionalMode(TransactionalMode.XA);
        final Configuration config = new Configuration();
        config.setDefaultCacheConfiguration(this.cacheConfiguration);
        final DiskStoreConfiguration diskStoreConfiguration = new DiskStoreConfiguration();
        diskStoreConfiguration.setPath("cache");
        config.addDiskStore(diskStoreConfiguration);
        this.cacheManager = new CacheManager(config);
        this.cacheConfiguration.name("primaryCache");
        this.cache = new Cache(this.cacheConfiguration);
        this.cacheManager.addCache(this.cache);
        
        for (int i = 0; i < 100; i++) {
            final Integer value = Integer.valueOf(i);
            this.cache.put(new Element(value, value));
        }
    }
}
