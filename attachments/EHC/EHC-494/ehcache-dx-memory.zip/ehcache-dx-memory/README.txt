Run the test without maven to get correct memory usage:

- Compile and package
	mvn clean package

- create classpath
	mvn dependency:build-classpath
	* will need to add target\ehcache-dx-memory.jar

- Enable yourkit profiler by adding agentlib
	http://www.yourkit.com/docs/75/help/getting_started/running_with_profiler/agent.jsp

- Run the test
	java -Xms64m -Xmx64m -agentlib:yjpagent -cp <CLASSPATH> org.terracotta.EhcacheDxMemory

- To run with Ehcache Dx Monitor 
	mvn -Pmonitor exec:java
	java -Dehcachedx.enabled=true -Xms64m -Xmx64m -agentlib:yjpagent -cp <CLASSPATH> org.terracotta.EhcacheDxMemory

- The test will be paused for 2 mins in the end.
- Take Memory Snapshots using Yourkit
- Compare the two snapshots