package org.terracotta;

/*
 * Do Not run it using maven as exec:java doesnt fork the process.
 */


import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.FactoryConfiguration;

public class EhcacheDxMemory {
	
	private static final boolean	EHCACHE_DX_ENABLED = Boolean.parseBoolean(System.getProperty("ehcachedx.enabled","false"));
	private static final int		CACHE_MGR_COUNT = 5;
	private static final int		CACHE_COUNT = 5;
	private static final int		ELEMENTS_COUNT = 1000;
	
	private static long		prevHeapUsed = 0;

	static public void heapStatus() throws InterruptedException{
		System.gc();
		Thread.sleep(2000);
		System.gc();
		Thread.sleep(2000);
		
		long max = Runtime.getRuntime().maxMemory();
		long free = Runtime.getRuntime().freeMemory();
		System.out.println("\n=============== HEAP STATUS ==============");
		System.out.println("  Max Heap: " + max);
		System.out.println("  Free Heap: " + free);
		System.out.println("  Used Heap: " + (max - free)/1000.0);
		System.out.println("  Heap Usage Increased: " + (max - free - prevHeapUsed)/1000.0);
		System.out.println("");
		prevHeapUsed = (max - free);
	}
	
	public static void main (String[] arg) throws InterruptedException{
		
		System.out.println("Test start:");
		heapStatus();
		
		for (int k=0; k < CACHE_MGR_COUNT; k++){
			Configuration cacheMgrConfig = new Configuration();
			cacheMgrConfig.setName("cacheMgr_" + k);
	        if (EHCACHE_DX_ENABLED){
	        	System.out.println("Enabling EhcacheDx Monitoring for cacheMgr_" + k);
		        FactoryConfiguration factory 	= new FactoryConfiguration();
		        factory.setClass("org.terracotta.ehcachedx.monitor.probe.ProbePeerListenerFactory");
		        factory.setProperties("probeName=cacheMgr_" + k + 
		        						", monitorAddress=localhost"+ 
		        						", monitorPort=9889");
		        cacheMgrConfig.addCacheManagerPeerListenerFactory(factory);
	        }
	        else
	        	System.out.println("EhcacheDx Monitoring DISABLED.");
	        
	        cacheMgrConfig.setDefaultCacheConfiguration(new CacheConfiguration("default",0));
	        CacheManager cacheMgr = new CacheManager(cacheMgrConfig);
	        System.out.println("Cache Manager created.");
	        
	        for (int i = 0; i < CACHE_COUNT; i++){
	        	CacheConfiguration config = new CacheConfiguration("cache_" + i, 0);
	        	config.setEternal(true);
	        	Cache cache = new Cache(config);
	        	cacheMgr.addCache(cache);
	        	System.out.println("Added cache: " + cache.getName() + " with " + ELEMENTS_COUNT + " elements.");
	        	
	        	for (int j=0; j < ELEMENTS_COUNT; j++){
	        		cache.put(new Element("key-"+j, "value-"+j));
	        	}
	        }
		}

		System.out.println("All cache managers/caches have been created.");
		if(EHCACHE_DX_ENABLED){
        	System.out.println("Start doing some operations on EhcacheDx monitor.");
        }
		System.out.println("Test will end in 120 secs.");
		Thread.sleep(120000);
        heapStatus();
        
	}
}
