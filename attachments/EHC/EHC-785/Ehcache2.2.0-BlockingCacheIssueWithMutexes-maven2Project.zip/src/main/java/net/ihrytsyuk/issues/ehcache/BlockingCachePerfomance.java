package net.ihrytsyuk.issues.ehcache;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.constructs.blocking.BlockingCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * @author ihrytsyuk
 */
public class BlockingCachePerfomance {

    private static final Logger LOG = LoggerFactory.getLogger(BlockingCachePerfomance.class);
    private static final int THREAD_COUNT = 1024;
    private static final int NUMBER_OF_STRIPES = 16384;
    private static final String TEST_CACHE_NAME = "test.METHOD_CACHE";

    /**
     * After method id done user can see all delayed requests on console and in ${user.dir}/EHCACHE-ISSUE/logs/issue.log 
     */
    public static void main(final String[] args) throws InterruptedException {
        LOG.info("Starting...");

        final ExecutorService executorService = Executors.newFixedThreadPool(THREAD_COUNT, new DaemonThreadFactory());
        final Ehcache testCache = CacheManager.getInstance().getCache(TEST_CACHE_NAME);
        final Ehcache blockingTestCache = new BlockingCache(testCache, NUMBER_OF_STRIPES);

        final List<Callable<Object>> parallelRequests = new ArrayList<Callable<Object>>();
        parallelRequests.add(new CacheOperationCallable(blockingTestCache, 3000));

        for (int i = 1; i < THREAD_COUNT; i++) {
            parallelRequests.add(new CacheOperationCallable(blockingTestCache, 0));
        }

        executorService.invokeAll(parallelRequests);
        LOG.info("Finished.");
    }

    private static class CacheOperationCallable implements Callable<Object> {
        private static final int MAX_ALLOWED_TIMEOUT = 100;

        private final int m_timeout;
        private final Ehcache m_cache;

        public CacheOperationCallable(final Ehcache cache, final int timeout) {
            m_cache = cache;
            m_timeout = timeout;
        }

        public Object call() throws Exception {
            final String uniqueKey = UUID.randomUUID().toString();
            final long startTime = System.currentTimeMillis();
            final Element element = m_cache.get(uniqueKey);
            final long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime <= MAX_ALLOWED_TIMEOUT) {
                LOG.debug("Retrieving element by key [{}] took [{}] ms.", uniqueKey, elapsedTime);
            } else {
                LOG.error("Retrieving element by key [{}] took [{}] ms.", uniqueKey, elapsedTime);
            }
            if (m_timeout > 0) {
                Thread.sleep(m_timeout);
            }
            m_cache.put(new Element(uniqueKey, uniqueKey));
            return element;
        }
    }

    private static class DaemonThreadFactory implements ThreadFactory {

        public Thread newThread(final Runnable runnable) {
            final Thread thread = new Thread(runnable);
            thread.setDaemon(true);
            return thread;
        }
    }
}
