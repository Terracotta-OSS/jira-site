package net.sf.ehcache;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EhCacheBugTest 
{
	private EhCacheWrapper<String, CachedChunk> unit = new ChunksCacheWrapper();
	
	private Logger log = LoggerFactory.getLogger(EhCacheBugTest.class);	
	private AtomicInteger idCounter = new AtomicInteger();
	
	final int targetCacheCapacityElements = 50000;
	final int putterThreads = 5;
	final int removerThreads = 5;
	final int chunkSize = 65536;
	final Random rand = new Random();		
	final AtomicBoolean keepRunning = new AtomicBoolean(true);
	final AtomicBoolean problemFound = new AtomicBoolean(false);
	final int[] putterMarks = new int[putterThreads];
	final List<String> existingKeys = new LinkedList<String>(); 
	
	@Test
	public void shouldPutAndReadDataFromCacheSafely() throws Exception
	{		
		startStuff();
		
		waitForErrorOrSuccessfulCompletion(60);
		
		verifyAndLog();
	}


	private void verifyAndLog() 
	{
		log.info("Elements stored and tested: {}", largestExisting());
		Assert.assertFalse(problemFound.get());
	}


	private void waitForErrorOrSuccessfulCompletion(int maxSecondsToWait)
			throws InterruptedException 
			{
		for (int i=0; i<maxSecondsToWait; i++)
		{
			Thread.sleep(1000);
			if (!keepRunning.get())
			{
				break;
			}
		}
		keepRunning.set(false);
	}


	private void startStuff() {
		Executor executor = Executors.newFixedThreadPool(10);
		for (int i=0; i<5; i++)
		{			
			executor.execute(new Putter(i));		
		}
		for (int i=0; i<removerThreads; i++)
		{
			executor.execute(new GetterAndRemover());
		}
	}
	
	class GetterAndRemover implements Runnable
	{
		public void run() 
		{
			while (keepRunning.get())
			{
				String key;
				int size;
				int numToCheck;
				synchronized (Putter.class) 
				{
					size = existingKeys.size();
					if (size == 0)
						continue;
					
					numToCheck = rand.nextInt(size);
					key = existingKeys.get(numToCheck);
				}
				if (unit.get(key) == null)
				{
					log.error("{} was missing", key);
					keepRunning.set(false);
					problemFound.set(true);
				}
				if (size < targetCacheCapacityElements)
					continue;
				
				synchronized (Putter.class) {
					existingKeys.remove(numToCheck);
				}
				unit.remove(key);					
			}
		}
	}
	
	class Putter implements Runnable 
	{
		final int number;
		
		public Putter(int number) {
			super();
			this.number = number;
		}

		public void run() 
		{
			while (keepRunning.get())
			{
				byte[] chunk = new byte[chunkSize];
				rand.nextBytes(chunk);
				CachedChunk value = new CachedChunk(chunk);
				int id = idCounter.incrementAndGet();
				String key = String.valueOf(id);
				unit.put(key, value);
				synchronized (Putter.class) 
				{
					putterMarks[number] = id;
					existingKeys.add(key);
				}
			}
		}
	};
	

	private int largestExisting() 
	{
		int[] marks;
		synchronized (Putter.class) 
		{
			marks = Arrays.copyOf(putterMarks, putterMarks.length);
		}
		Arrays.sort(marks);
		int largestExistingForSure = marks[0];
		return largestExistingForSure;
	}
}
