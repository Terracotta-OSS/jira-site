package net.sf.ehcache;
/**
 * 
 */


import java.io.Serializable;
import java.util.Arrays;

/**
 * @author kstoyanov
 *
 */
public class CachedChunk implements Serializable
{
	private static final long serialVersionUID = -5954559668994593121L;
	
	private final byte[] data;

	public CachedChunk(final byte[] data)
	{
		if (data == null)
		{
			throw new NullPointerException("data");
		}
		
		this.data = data;
	}


	public byte[] getData()
	{
		return data;
	}


	@Override
	public String toString()
	{
		return "CachedChunk [data=" + Arrays.toString(data) + ":" + Arrays.hashCode(data) + "]";
	}
}
