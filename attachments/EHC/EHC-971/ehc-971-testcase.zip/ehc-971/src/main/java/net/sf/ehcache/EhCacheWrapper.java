package net.sf.ehcache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class EhCacheWrapper<K, V>
{
	private static final Logger log = LoggerFactory.getLogger(EhCacheWrapper.class);

	private final String cacheName;
	private final CacheManager cacheManager;


	public EhCacheWrapper(final String cacheName, final CacheManager cacheManager)
	{
		this.cacheName = cacheName;
		this.cacheManager = cacheManager;
	}

	public void put(final K key, final V value)
	{
		log.trace("Putting to {}: {}", cacheName, key);
		// uncomment these to make test pass
		// synchronized (this)
		{
			getCache().put(new Element(key, value));
		}
	}
	
	public void remove(K key)
	{
		getCache().remove(key);
	}

	@SuppressWarnings("unchecked")
	public V get(final K key)
	{
		Element element;
		// uncomment these to make test pass
		// synchronized (this) 
		{
			element = getCache().get(key);
		}
		V value = null;
		if (element != null)
		{
			value = (V) element.getValue();
			log.trace("Retrieved by key {} from {}", key, cacheName);
		}
		else
		{
			log.trace("Retrieved null by key {} from {} ", key, cacheName);
		}
		return value;
	}


	public Ehcache getCache()
	{
		return cacheManager.getEhcache(cacheName);
	}
}
