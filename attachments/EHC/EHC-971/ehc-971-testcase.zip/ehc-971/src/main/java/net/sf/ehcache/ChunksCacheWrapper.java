package net.sf.ehcache;


import java.io.InputStream;


public class ChunksCacheWrapper extends EhCacheWrapper<String, CachedChunk>
{
	
	public static final String PARTS_CACHE_NAME = "chunksCache";
	public static final String CACHE_CONFIG_FILE = "ehcache.xml";

	public ChunksCacheWrapper()
	{
		super(PARTS_CACHE_NAME, createCacheManager());		
	}

	private static CacheManager createCacheManager()
	{
		InputStream is = ChunksCacheWrapper.class.getClassLoader().getResourceAsStream(CACHE_CONFIG_FILE);
		CacheManager cm = CacheManager.create(is);
		return cm;
	}
}
