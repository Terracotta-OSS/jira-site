package org.ehcache.patched;

import java.rmi.server.RMIFailureHandler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This handler returns always false, which causes the RMI thread to end.
 *
 * @author gwi</a>
 *
 */
public class SimpleRMIFailureHandler implements RMIFailureHandler
{

   /** Logger for this class. */
   private static final Log LOG = LogFactory.getLog(SimpleRMIFailureHandler.class);


   /* (non-Javadoc)
    * @see java.rmi.server.RMIFailureHandler#failure(java.lang.Exception)
    */
   public boolean failure(Exception argEx)
   {
      LOG.debug("RMIFailureHandler called - good!");
      return false;
   }

}
