package org.ehcache.patched;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.rmi.server.RMIServerSocketFactory;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * This class tries to work around this bug <a>http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4457683</a>
 * </p>
 *
 * This simply factory keeps track of all created ServerSockets and provides a method to close all of them.
 *
 * @author gwi</a>
 *
 **/
public class SimpleRMISocketFactory implements RMIServerSocketFactory

{

   /** Logger for this class. */
   static final Log LOG = LogFactory.getLog(SimpleRMISocketFactory.class);

   /** maps port number to ServerSocket */
   private final Map<Integer, ServerSocket> bindings = new HashMap<Integer, ServerSocket>();

   // implements RMIServerSocketFactory.createServerSocket
   public ServerSocket createServerSocket(int port) throws IOException
   {
      synchronized (this)
      {
         Integer key = Integer.valueOf(port);
         if (bindings.get(key) != null)
         {
            throw new BindException("port already bound: " + port);
         }
         ServerSocket sss = new ServerSocket(port);
         bindings.put(key, sss);
         if (LOG.isDebugEnabled())
         {
            LOG.debug("Created socket " + sss);
         }
         return sss;
      }
   }

   /**
    * Should be called, when the context is shutdown. Closes all ServerSockets created with this factory.
    */
   public void shutdown()
   {
      for (ServerSocket serverSocket : bindings.values())
      {
         try
         {
            LOG.debug("closing server socket " + serverSocket);
            serverSocket.close();
         } catch (IOException e)
         {
            // ignore
         }
      }
   }

}
