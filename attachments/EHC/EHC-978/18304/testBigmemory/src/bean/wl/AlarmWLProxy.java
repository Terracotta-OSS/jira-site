package bean.wl;

import java.util.List;

public class AlarmWLProxy {
	
	private AlarmWL[] alarms ;

	public AlarmWL[] getAlarms() {
		return alarms;
	}

	public void setAlarms(List<AlarmWL> alarmList) {
		alarmList.toArray(alarms = new AlarmWL[alarmList.size()]);
	}
	
}
