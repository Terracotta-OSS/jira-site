package bean.wl;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

import com.dyuproject.protostuff.LinkedBuffer;
import com.dyuproject.protostuff.ProtostuffIOUtil;
import com.dyuproject.protostuff.Schema;
import com.dyuproject.protostuff.runtime.RuntimeSchema;

public class ProtostuffTest {
	private static Logger logger = Logger.getLogger(ProtostuffTest.class);
	final int BUF_SIZE = 1024;

	private LinkedBuffer buf() {
		return LinkedBuffer.allocate(BUF_SIZE);
	}

	private <T> byte[] toByteArray(T message, Schema<T> schema) {
		return ProtostuffIOUtil.toByteArray(message, schema, buf());
	}
	
	
	public void serWL(List<AlarmWL> list,String newPath) {
		AlarmWLProxy alarmWLProxy = new AlarmWLProxy();
		alarmWLProxy.setAlarms(list);
		Schema<AlarmWLProxy> schema = RuntimeSchema.getSchema(AlarmWLProxy.class);
		byte[] deferred = toByteArray(alarmWLProxy, schema);
		buildFile(deferred,newPath);
	}
	
	public AlarmWL[] deserWL(String fileName) {
		AlarmWL[] alarmList = null;
		Schema<AlarmWLProxy> schema = RuntimeSchema.getSchema(AlarmWLProxy.class);
        long s = System.currentTimeMillis();
        byte[] bytes = getBytes(fileName);
        AlarmWLProxy dpojo = new AlarmWLProxy();
        ProtostuffIOUtil.mergeFrom(bytes, dpojo, schema);
        alarmList = dpojo.getAlarms();
        logger.info("deser :, cost " + (System.currentTimeMillis() -s));
        if(alarmList==null) {
        	logger.info(fileName + " return alarmList is null");
        }
        return alarmList;
	}
	
	
	 /**                                                                                
	  * 获得指定文件的byte数组                                                          
	  */                                                                                
	 private static byte[] getBytes(String filePath){                                    
	     byte[] buffer = null;                                                          
	     try {                                                                          
	         File file = new File(filePath);                                            
	         FileInputStream fis = new FileInputStream(file);                           
	         ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);               
	         byte[] b = new byte[1000];                                                 
	         int n;                                                                     
	         while ((n = fis.read(b)) != -1) {                                          
	             bos.write(b, 0, n);                                                    
	         }                                                                          
	         fis.close();                                                               
	         bos.close();                                                               
	         buffer = bos.toByteArray();                                                
	     } catch (FileNotFoundException e) {                                            
	         e.printStackTrace();                                                       
	     } catch (IOException e) {                                                      
	         e.printStackTrace();                                                       
	     }                                                                              
	     return buffer;                                                                 
	 }         
	
	 /**                                                                                
	  * 根据byte数组，生成文�?                                                         
	  */                                                                                
	 private static void buildFile(byte[] bfile, String filePath) {        
	     BufferedOutputStream bos = null;                                               
	     FileOutputStream fos = null;                                                   
	     File file = null;                                                              
	     try {                                                                          
	         File dir = new File(filePath);                                             
	         if(!dir.exists()&&dir.isDirectory()){//判断文件目录是否存在                
	             dir.mkdirs();                                                          
	         }                                                                          
	         file = new File(filePath);                                   
	         fos = new FileOutputStream(file);                                          
	         bos = new BufferedOutputStream(fos);                                       
	         bos.write(bfile);                                                          
	     } catch (Exception e) {                                                        
	         e.printStackTrace();                                                       
	     } finally {                                                                    
	         if (bos != null) {                                                         
	             try {                                                                  
	                 bos.close();                                                       
	             } catch (IOException e1) {                                             
	                 e1.printStackTrace();                                              
	             }                                                                      
	         }                                                                          
	         if (fos != null) {                                                         
	             try {                                                                  
	                 fos.close();                                                       
	             } catch (IOException e1) {                                             
	                 e1.printStackTrace();                                              
	             }                                                                      
	         }                                                                          
	     }                                                                              
	 }
	 
	
	public static void main(String[] args) {
		ProtostuffTest test = new ProtostuffTest();
		AlarmWL[] deserWL = test.deserWL("E:\\nosql\\filter\\serdata\\alarmwl1500000.dat");
		System.out.println("ok, alarms.length = " + deserWL.length);
	}
	
}
