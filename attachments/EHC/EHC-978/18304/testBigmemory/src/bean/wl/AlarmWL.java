package bean.wl;

import java.io.Serializable;
import java.util.Date;

public class AlarmWL implements Serializable {
	
	public static final long serialVersionUID = 5269173399224298044L;
	
	public Long       ALARM_ID;
	public Long       REC_VERSION;
	public Long       FP0;
	public Long       FP1;
	public Long       FP2;
	public Long       FP3;
	public Long       C_FP0;
	public Long       C_FP1;
	public Long       C_FP2;
	public Long       C_FP3;
	public Date       EVENT_TIME;
	public Long       TIME_STAMP;
	public Date       CANCEL_TIME;
	public Long       ACTIVE_STATUS;
	public Long       ORG_SEVERITY;
	public String     PROVINCE_NAME;
	public Long       REGION_ID;
	public String     REGION_NAME;
	public String     CITY_NAME;
	public Long       NETWORK_TYPE;
	public String     ALARM_SOURCE;
	public Long       OBJECT_CLASS;
	public Long       PROFESSIONAL_TYPE;
	public String     SHEET_NO;
	public Long       SHEET_STATUS;
	public Long       SHEET_SEND_STATUS;
	public Long       ORG_TYPE;
	public Long       LOGIC_ALARM_TYPE;
	public Long       LOGIC_SUB_ALARM_TYPE;
	public Long       SUB_ALARM_TYPE;
	public String     VENDOR_TYPE;
	public Long       OMC_ID;
	public Long       OMC_ALARM_ID;
	public Long       VENDOR_ID;
	public Long       PROBABLE_CAUSE;
	public String     PROBABLE_CAUSE_TXT;
	public Long       ALARM_ORIGIN;
	public Long       ACK_FLAG;
	public Long       ACK_USER;
	public Date       ACK_TIME;
	public String     NE_LABEL;
	public String     SITE_NO;
	public String     NE_LOCATION;
	public String     CIRCUIT_NO;
	public Long       CHANNEL_TYPE;
	public String     EQP_LABEL;
	public String     EQP_ALIAS;
	public String     NE_ALIAS;
	public Long       NE_STATUS;
	public Long       EQP_INT_ID;
	public Long       NE_ADMIN_STATUS;
	public Long       ALARM_NE_STATUS;
	public String     STANDARD_ALARM_NAME;
	public String     STANDARD_ALARM_ID;
	public Long       EFFECT_NE;
	public Long       EFFECT_SERVICE;
	public Long       SEND_JT_FLAG;
	public String     GCSS_CLIENT;
	public String     GCSS_CLIENT_NAME;
	public Long       GCSS_CLIENT_LEVEL;
	public Long       GCSS_CLIENT_NUM;
	public String     GCSS_SERVICE;
	public String     GCSS_SERVICE_TYPE;
	public Long       GCSS_SERVICE_LEVEL;
	public Long       GCSS_SERVICE_NUM;
	public Date       DEADLINE_TIME;
	public Long       EQP_OBJECT_CLASS;
	public String     EQP_VERSION;
	public Long       INT_ID;
	public String     NE_IP;
	public String     REMOTE_EQP_LABEL;
	public Double     REMOTE_RESOURCE_STATUS;
	public Double     REMOTE_PROJ_SUB_STATUS;
	public String     PROJ_OA_FILE_ID;
	public Long       OBJECT_LEVEL;
	public Long       INFECT_CUSTOMER_COUNT;
	public String     FAILED_REASON;
	public String     UNSEND_REASON;
	public String     LAYER_RETE;
	public String     RELATION_TYPE;
	public String     AC_RULE_NAME;
	public Long       ALARM_RESOURCE_STATUS;
	public Long       REMARK_EXIST;
	public String     ALARM_REASON;
	public Long       IS_ROOT;
	public Long       HAS_CHILD;
	public String     TITLE_TEXT;
	public Date       DEAL_TIME_LIMIT;
	public String     SHEET_DEAL_DEP;
	public String     SPECIAL_FIELD23;
	public Date       INSERT_TIME;
	public Long       ALARM_ACT_COUNT;
	public Long       RESOURCE_STATUS;
	public Long       CITY_ID;
	public String     NMS_NAME;
	public String     CIRCUIT_ID;
	public Long       ALARM_TITLE;
	public Long REDEFINE_TYPE;
	public Long REDEFINE_SEVERITY;
	public String VENDOR_SEVERITY;
	public Long STANDARD_FLAG;
	public Long EXTRA_ID1;
	public Long EXTRA_ID3;
	public String EXTRA_STRING3;
	public Long GCSS_CLIENT_GRADE;
	public Long GCSS_CLIENT_GRADE_MGT;
	public Long TMSC_CAT;
	public Long PREPROCESS_MANNER;
	public Long PREPROCESS_FLAG;
	public String ALARM_TEXT;
	

	public Long getREDEFINE_TYPE() {
		return REDEFINE_TYPE;
	}
	public void setREDEFINE_TYPE(Long rEDEFINE_TYPE) {
		REDEFINE_TYPE = rEDEFINE_TYPE;
	}
	public Long getREDEFINE_SEVERITY() {
		return REDEFINE_SEVERITY;
	}
	public void setREDEFINE_SEVERITY(Long rEDEFINE_SEVERITY) {
		REDEFINE_SEVERITY = rEDEFINE_SEVERITY;
	}
	public String getVENDOR_SEVERITY() {
		return VENDOR_SEVERITY;
	}
	public void setVENDOR_SEVERITY(String vENDOR_SEVERITY) {
		VENDOR_SEVERITY = vENDOR_SEVERITY;
	}
	public Long getSTANDARD_FLAG() {
		return STANDARD_FLAG;
	}
	public void setSTANDARD_FLAG(Long sTANDARD_FLAG) {
		STANDARD_FLAG = sTANDARD_FLAG;
	}
	public Long getEXTRA_ID1() {
		return EXTRA_ID1;
	}
	public void setEXTRA_ID1(Long eXTRA_ID1) {
		EXTRA_ID1 = eXTRA_ID1;
	}
	public Long getEXTRA_ID3() {
		return EXTRA_ID3;
	}
	public void setEXTRA_ID3(Long eXTRA_ID3) {
		EXTRA_ID3 = eXTRA_ID3;
	}
	public String getEXTRA_STRING3() {
		return EXTRA_STRING3;
	}
	public void setEXTRA_STRING3(String eXTRA_STRING3) {
		EXTRA_STRING3 = eXTRA_STRING3;
	}
	public Long getGCSS_CLIENT_GRADE() {
		return GCSS_CLIENT_GRADE;
	}
	public void setGCSS_CLIENT_GRADE(Long gCSS_CLIENT_GRADE) {
		GCSS_CLIENT_GRADE = gCSS_CLIENT_GRADE;
	}
	public Long getGCSS_CLIENT_GRADE_MGT() {
		return GCSS_CLIENT_GRADE_MGT;
	}
	public void setGCSS_CLIENT_GRADE_MGT(Long gCSS_CLIENT_GRADE_MGT) {
		GCSS_CLIENT_GRADE_MGT = gCSS_CLIENT_GRADE_MGT;
	}
	public Long getTMSC_CAT() {
		return TMSC_CAT;
	}
	public void setTMSC_CAT(Long tMSC_CAT) {
		TMSC_CAT = tMSC_CAT;
	}
	public Long getPREPROCESS_MANNER() {
		return PREPROCESS_MANNER;
	}
	public void setPREPROCESS_MANNER(Long pREPROCESS_MANNER) {
		PREPROCESS_MANNER = pREPROCESS_MANNER;
	}
	public Long getPREPROCESS_FLAG() {
		return PREPROCESS_FLAG;
	}
	public void setPREPROCESS_FLAG(Long pREPROCESS_FLAG) {
		PREPROCESS_FLAG = pREPROCESS_FLAG;
	}
	public String getALARM_TEXT() {
		return ALARM_TEXT;
	}
	public void setALARM_TEXT(String aLARM_TEXT) {
		ALARM_TEXT = aLARM_TEXT;
	}
	public Long getALARM_ID() {
		return ALARM_ID;
	}
	public void setALARM_ID(Long aLARM_ID) {
		ALARM_ID = aLARM_ID;
	}
	public Long getREC_VERSION() {
		return REC_VERSION;
	}
	public void setREC_VERSION(Long rEC_VERSION) {
		REC_VERSION = rEC_VERSION;
	}
	public Long getFP0() {
		return FP0;
	}
	public void setFP0(Long fP0) {
		FP0 = fP0;
	}
	public Long getFP1() {
		return FP1;
	}
	public void setFP1(Long fP1) {
		FP1 = fP1;
	}
	public Long getFP2() {
		return FP2;
	}
	public void setFP2(Long fP2) {
		FP2 = fP2;
	}
	public Long getFP3() {
		return FP3;
	}
	public void setFP3(Long fP3) {
		FP3 = fP3;
	}
	public Long getC_FP0() {
		return C_FP0;
	}
	public void setC_FP0(Long c_FP0) {
		C_FP0 = c_FP0;
	}
	public Long getC_FP1() {
		return C_FP1;
	}
	public void setC_FP1(Long c_FP1) {
		C_FP1 = c_FP1;
	}
	public Long getC_FP2() {
		return C_FP2;
	}
	public void setC_FP2(Long c_FP2) {
		C_FP2 = c_FP2;
	}
	public Long getC_FP3() {
		return C_FP3;
	}
	public void setC_FP3(Long c_FP3) {
		C_FP3 = c_FP3;
	}
	public Date getEVENT_TIME() {
		return EVENT_TIME;
	}
	public void setEVENT_TIME(Date eVENT_TIME) {
		EVENT_TIME = eVENT_TIME;
	}
	public Long getTIME_STAMP() {
		return TIME_STAMP;
	}
	public void setTIME_STAMP(Long tIME_STAMP) {
		TIME_STAMP = tIME_STAMP;
	}
	public Date getCANCEL_TIME() {
		return CANCEL_TIME;
	}
	public void setCANCEL_TIME(Date cANCEL_TIME) {
		CANCEL_TIME = cANCEL_TIME;
	}
	public Long getACTIVE_STATUS() {
		return ACTIVE_STATUS;
	}
	public void setACTIVE_STATUS(Long aCTIVE_STATUS) {
		ACTIVE_STATUS = aCTIVE_STATUS;
	}
	public Long getORG_SEVERITY() {
		return ORG_SEVERITY;
	}
	public void setORG_SEVERITY(Long oRG_SEVERITY) {
		ORG_SEVERITY = oRG_SEVERITY;
	}
	public String getPROVINCE_NAME() {
		return PROVINCE_NAME;
	}
	public void setPROVINCE_NAME(String pROVINCE_NAME) {
		PROVINCE_NAME = pROVINCE_NAME;
	}
	public Long getREGION_ID() {
		return REGION_ID;
	}
	public void setREGION_ID(Long rEGION_ID) {
		REGION_ID = rEGION_ID;
	}
	public String getREGION_NAME() {
		return REGION_NAME;
	}
	public void setREGION_NAME(String rEGION_NAME) {
		REGION_NAME = rEGION_NAME;
	}
	public String getCITY_NAME() {
		return CITY_NAME;
	}
	public void setCITY_NAME(String cITY_NAME) {
		CITY_NAME = cITY_NAME;
	}
	public Long getNETWORK_TYPE() {
		return NETWORK_TYPE;
	}
	public void setNETWORK_TYPE(Long nETWORK_TYPE) {
		NETWORK_TYPE = nETWORK_TYPE;
	}
	public String getALARM_SOURCE() {
		return ALARM_SOURCE;
	}
	public void setALARM_SOURCE(String aLARM_SOURCE) {
		ALARM_SOURCE = aLARM_SOURCE;
	}
	public Long getOBJECT_CLASS() {
		return OBJECT_CLASS;
	}
	public void setOBJECT_CLASS(Long oBJECT_CLASS) {
		OBJECT_CLASS = oBJECT_CLASS;
	}
	public Long getPROFESSIONAL_TYPE() {
		return PROFESSIONAL_TYPE;
	}
	public void setPROFESSIONAL_TYPE(Long pROFESSIONAL_TYPE) {
		PROFESSIONAL_TYPE = pROFESSIONAL_TYPE;
	}
	public String getSHEET_NO() {
		return SHEET_NO;
	}
	public void setSHEET_NO(String sHEET_NO) {
		SHEET_NO = sHEET_NO;
	}
	public Long getSHEET_STATUS() {
		return SHEET_STATUS;
	}
	public void setSHEET_STATUS(Long sHEET_STATUS) {
		SHEET_STATUS = sHEET_STATUS;
	}
	public Long getSHEET_SEND_STATUS() {
		return SHEET_SEND_STATUS;
	}
	public void setSHEET_SEND_STATUS(Long sHEET_SEND_STATUS) {
		SHEET_SEND_STATUS = sHEET_SEND_STATUS;
	}
	public Long getORG_TYPE() {
		return ORG_TYPE;
	}
	public void setORG_TYPE(Long oRG_TYPE) {
		ORG_TYPE = oRG_TYPE;
	}
	public Long getLOGIC_ALARM_TYPE() {
		return LOGIC_ALARM_TYPE;
	}
	public void setLOGIC_ALARM_TYPE(Long lOGIC_ALARM_TYPE) {
		LOGIC_ALARM_TYPE = lOGIC_ALARM_TYPE;
	}
	public Long getLOGIC_SUB_ALARM_TYPE() {
		return LOGIC_SUB_ALARM_TYPE;
	}
	public void setLOGIC_SUB_ALARM_TYPE(Long lOGIC_SUB_ALARM_TYPE) {
		LOGIC_SUB_ALARM_TYPE = lOGIC_SUB_ALARM_TYPE;
	}
	public Long getSUB_ALARM_TYPE() {
		return SUB_ALARM_TYPE;
	}
	public void setSUB_ALARM_TYPE(Long sUB_ALARM_TYPE) {
		SUB_ALARM_TYPE = sUB_ALARM_TYPE;
	}
	public String getVENDOR_TYPE() {
		return VENDOR_TYPE;
	}
	public void setVENDOR_TYPE(String vENDOR_TYPE) {
		VENDOR_TYPE = vENDOR_TYPE;
	}
	public Long getOMC_ID() {
		return OMC_ID;
	}
	public void setOMC_ID(Long oMC_ID) {
		OMC_ID = oMC_ID;
	}
	public Long getOMC_ALARM_ID() {
		return OMC_ALARM_ID;
	}
	public void setOMC_ALARM_ID(Long oMC_ALARM_ID) {
		OMC_ALARM_ID = oMC_ALARM_ID;
	}
	public Long getVENDOR_ID() {
		return VENDOR_ID;
	}
	public void setVENDOR_ID(Long vENDOR_ID) {
		VENDOR_ID = vENDOR_ID;
	}
	public Long getPROBABLE_CAUSE() {
		return PROBABLE_CAUSE;
	}
	public void setPROBABLE_CAUSE(Long pROBABLE_CAUSE) {
		PROBABLE_CAUSE = pROBABLE_CAUSE;
	}
	public String getPROBABLE_CAUSE_TXT() {
		return PROBABLE_CAUSE_TXT;
	}
	public void setPROBABLE_CAUSE_TXT(String pROBABLE_CAUSE_TXT) {
		PROBABLE_CAUSE_TXT = pROBABLE_CAUSE_TXT;
	}
	public Long getALARM_ORIGIN() {
		return ALARM_ORIGIN;
	}
	public void setALARM_ORIGIN(Long aLARM_ORIGIN) {
		ALARM_ORIGIN = aLARM_ORIGIN;
	}
	public Long getACK_FLAG() {
		return ACK_FLAG;
	}
	public void setACK_FLAG(Long aCK_FLAG) {
		ACK_FLAG = aCK_FLAG;
	}
	public Long getACK_USER() {
		return ACK_USER;
	}
	public void setACK_USER(Long aCK_USER) {
		ACK_USER = aCK_USER;
	}
	public Date getACK_TIME() {
		return ACK_TIME;
	}
	public void setACK_TIME(Date aCK_TIME) {
		ACK_TIME = aCK_TIME;
	}
	public String getNE_LABEL() {
		return NE_LABEL;
	}
	public void setNE_LABEL(String nE_LABEL) {
		NE_LABEL = nE_LABEL;
	}
	public String getSITE_NO() {
		return SITE_NO;
	}
	public void setSITE_NO(String sITE_NO) {
		SITE_NO = sITE_NO;
	}
	public String getNE_LOCATION() {
		return NE_LOCATION;
	}
	public void setNE_LOCATION(String nE_LOCATION) {
		NE_LOCATION = nE_LOCATION;
	}
	public String getCIRCUIT_NO() {
		return CIRCUIT_NO;
	}
	public void setCIRCUIT_NO(String cIRCUIT_NO) {
		CIRCUIT_NO = cIRCUIT_NO;
	}
	public Long getCHANNEL_TYPE() {
		return CHANNEL_TYPE;
	}
	public void setCHANNEL_TYPE(Long cHANNEL_TYPE) {
		CHANNEL_TYPE = cHANNEL_TYPE;
	}
	public String getEQP_LABEL() {
		return EQP_LABEL;
	}
	public void setEQP_LABEL(String eQP_LABEL) {
		EQP_LABEL = eQP_LABEL;
	}
	public String getEQP_ALIAS() {
		return EQP_ALIAS;
	}
	public void setEQP_ALIAS(String eQP_ALIAS) {
		EQP_ALIAS = eQP_ALIAS;
	}
	public String getNE_ALIAS() {
		return NE_ALIAS;
	}
	public void setNE_ALIAS(String nE_ALIAS) {
		NE_ALIAS = nE_ALIAS;
	}
	public Long getNE_STATUS() {
		return NE_STATUS;
	}
	public void setNE_STATUS(Long nE_STATUS) {
		NE_STATUS = nE_STATUS;
	}
	public Long getEQP_INT_ID() {
		return EQP_INT_ID;
	}
	public void setEQP_INT_ID(Long eQP_INT_ID) {
		EQP_INT_ID = eQP_INT_ID;
	}
	public Long getNE_ADMIN_STATUS() {
		return NE_ADMIN_STATUS;
	}
	public void setNE_ADMIN_STATUS(Long nE_ADMIN_STATUS) {
		NE_ADMIN_STATUS = nE_ADMIN_STATUS;
	}
	public Long getALARM_NE_STATUS() {
		return ALARM_NE_STATUS;
	}
	public void setALARM_NE_STATUS(Long aLARM_NE_STATUS) {
		ALARM_NE_STATUS = aLARM_NE_STATUS;
	}
	public String getSTANDARD_ALARM_NAME() {
		return STANDARD_ALARM_NAME;
	}
	public void setSTANDARD_ALARM_NAME(String sTANDARD_ALARM_NAME) {
		STANDARD_ALARM_NAME = sTANDARD_ALARM_NAME;
	}
	public String getSTANDARD_ALARM_ID() {
		return STANDARD_ALARM_ID;
	}
	public void setSTANDARD_ALARM_ID(String sTANDARD_ALARM_ID) {
		STANDARD_ALARM_ID = sTANDARD_ALARM_ID;
	}
	public Long getEFFECT_NE() {
		return EFFECT_NE;
	}
	public void setEFFECT_NE(Long eFFECT_NE) {
		EFFECT_NE = eFFECT_NE;
	}
	public Long getEFFECT_SERVICE() {
		return EFFECT_SERVICE;
	}
	public void setEFFECT_SERVICE(Long eFFECT_SERVICE) {
		EFFECT_SERVICE = eFFECT_SERVICE;
	}
	public Long getSEND_JT_FLAG() {
		return SEND_JT_FLAG;
	}
	public void setSEND_JT_FLAG(Long sEND_JT_FLAG) {
		SEND_JT_FLAG = sEND_JT_FLAG;
	}
	public String getGCSS_CLIENT() {
		return GCSS_CLIENT;
	}
	public void setGCSS_CLIENT(String gCSS_CLIENT) {
		GCSS_CLIENT = gCSS_CLIENT;
	}
	public String getGCSS_CLIENT_NAME() {
		return GCSS_CLIENT_NAME;
	}
	public void setGCSS_CLIENT_NAME(String gCSS_CLIENT_NAME) {
		GCSS_CLIENT_NAME = gCSS_CLIENT_NAME;
	}
	public Long getGCSS_CLIENT_LEVEL() {
		return GCSS_CLIENT_LEVEL;
	}
	public void setGCSS_CLIENT_LEVEL(Long gCSS_CLIENT_LEVEL) {
		GCSS_CLIENT_LEVEL = gCSS_CLIENT_LEVEL;
	}
	public Long getGCSS_CLIENT_NUM() {
		return GCSS_CLIENT_NUM;
	}
	public void setGCSS_CLIENT_NUM(Long gCSS_CLIENT_NUM) {
		GCSS_CLIENT_NUM = gCSS_CLIENT_NUM;
	}
	public String getGCSS_SERVICE() {
		return GCSS_SERVICE;
	}
	public void setGCSS_SERVICE(String gCSS_SERVICE) {
		GCSS_SERVICE = gCSS_SERVICE;
	}
	public String getGCSS_SERVICE_TYPE() {
		return GCSS_SERVICE_TYPE;
	}
	public void setGCSS_SERVICE_TYPE(String gCSS_SERVICE_TYPE) {
		GCSS_SERVICE_TYPE = gCSS_SERVICE_TYPE;
	}
	public Long getGCSS_SERVICE_LEVEL() {
		return GCSS_SERVICE_LEVEL;
	}
	public void setGCSS_SERVICE_LEVEL(Long gCSS_SERVICE_LEVEL) {
		GCSS_SERVICE_LEVEL = gCSS_SERVICE_LEVEL;
	}
	public Long getGCSS_SERVICE_NUM() {
		return GCSS_SERVICE_NUM;
	}
	public void setGCSS_SERVICE_NUM(Long gCSS_SERVICE_NUM) {
		GCSS_SERVICE_NUM = gCSS_SERVICE_NUM;
	}
	public Date getDEADLINE_TIME() {
		return DEADLINE_TIME;
	}
	public void setDEADLINE_TIME(Date dEADLINE_TIME) {
		DEADLINE_TIME = dEADLINE_TIME;
	}
	public Long getEQP_OBJECT_CLASS() {
		return EQP_OBJECT_CLASS;
	}
	public void setEQP_OBJECT_CLASS(Long eQP_OBJECT_CLASS) {
		EQP_OBJECT_CLASS = eQP_OBJECT_CLASS;
	}
	public String getEQP_VERSION() {
		return EQP_VERSION;
	}
	public void setEQP_VERSION(String eQP_VERSION) {
		EQP_VERSION = eQP_VERSION;
	}
	public Long getINT_ID() {
		return INT_ID;
	}
	public void setINT_ID(Long iNT_ID) {
		INT_ID = iNT_ID;
	}
	public String getNE_IP() {
		return NE_IP;
	}
	public void setNE_IP(String nE_IP) {
		NE_IP = nE_IP;
	}
	public String getREMOTE_EQP_LABEL() {
		return REMOTE_EQP_LABEL;
	}
	public void setREMOTE_EQP_LABEL(String rEMOTE_EQP_LABEL) {
		REMOTE_EQP_LABEL = rEMOTE_EQP_LABEL;
	}
	public Double getREMOTE_RESOURCE_STATUS() {
		return REMOTE_RESOURCE_STATUS;
	}
	public void setREMOTE_RESOURCE_STATUS(Double rEMOTE_RESOURCE_STATUS) {
		REMOTE_RESOURCE_STATUS = rEMOTE_RESOURCE_STATUS;
	}
	public Double getREMOTE_PROJ_SUB_STATUS() {
		return REMOTE_PROJ_SUB_STATUS;
	}
	public void setREMOTE_PROJ_SUB_STATUS(Double rEMOTE_PROJ_SUB_STATUS) {
		REMOTE_PROJ_SUB_STATUS = rEMOTE_PROJ_SUB_STATUS;
	}
	public String getPROJ_OA_FILE_ID() {
		return PROJ_OA_FILE_ID;
	}
	public void setPROJ_OA_FILE_ID(String pROJ_OA_FILE_ID) {
		PROJ_OA_FILE_ID = pROJ_OA_FILE_ID;
	}
	public Long getOBJECT_LEVEL() {
		return OBJECT_LEVEL;
	}
	public void setOBJECT_LEVEL(Long oBJECT_LEVEL) {
		OBJECT_LEVEL = oBJECT_LEVEL;
	}
	public Long getINFECT_CUSTOMER_COUNT() {
		return INFECT_CUSTOMER_COUNT;
	}
	public void setINFECT_CUSTOMER_COUNT(Long iNFECT_CUSTOMER_COUNT) {
		INFECT_CUSTOMER_COUNT = iNFECT_CUSTOMER_COUNT;
	}
	public String getFAILED_REASON() {
		return FAILED_REASON;
	}
	public void setFAILED_REASON(String fAILED_REASON) {
		FAILED_REASON = fAILED_REASON;
	}
	public String getUNSEND_REASON() {
		return UNSEND_REASON;
	}
	public void setUNSEND_REASON(String uNSEND_REASON) {
		UNSEND_REASON = uNSEND_REASON;
	}
	public String getLAYER_RETE() {
		return LAYER_RETE;
	}
	public void setLAYER_RETE(String lAYER_RETE) {
		LAYER_RETE = lAYER_RETE;
	}
	public String getRELATION_TYPE() {
		return RELATION_TYPE;
	}
	public void setRELATION_TYPE(String rELATION_TYPE) {
		RELATION_TYPE = rELATION_TYPE;
	}
	public String getAC_RULE_NAME() {
		return AC_RULE_NAME;
	}
	public void setAC_RULE_NAME(String aC_RULE_NAME) {
		AC_RULE_NAME = aC_RULE_NAME;
	}
	public Long getALARM_RESOURCE_STATUS() {
		return ALARM_RESOURCE_STATUS;
	}
	public void setALARM_RESOURCE_STATUS(Long aLARM_RESOURCE_STATUS) {
		ALARM_RESOURCE_STATUS = aLARM_RESOURCE_STATUS;
	}
	public Long getREMARK_EXIST() {
		return REMARK_EXIST;
	}
	public void setREMARK_EXIST(Long rEMARK_EXIST) {
		REMARK_EXIST = rEMARK_EXIST;
	}
	public String getALARM_REASON() {
		return ALARM_REASON;
	}
	public void setALARM_REASON(String aLARM_REASON) {
		ALARM_REASON = aLARM_REASON;
	}
	public Long getIS_ROOT() {
		return IS_ROOT;
	}
	public void setIS_ROOT(Long iS_ROOT) {
		IS_ROOT = iS_ROOT;
	}
	public Long getHAS_CHILD() {
		return HAS_CHILD;
	}
	public void setHAS_CHILD(Long hAS_CHILD) {
		HAS_CHILD = hAS_CHILD;
	}
	public String getTITLE_TEXT() {
		return TITLE_TEXT;
	}
	public void setTITLE_TEXT(String tITLE_TEXT) {
		TITLE_TEXT = tITLE_TEXT;
	}
	public Date getDEAL_TIME_LIMIT() {
		return DEAL_TIME_LIMIT;
	}
	public void setDEAL_TIME_LIMIT(Date dEAL_TIME_LIMIT) {
		DEAL_TIME_LIMIT = dEAL_TIME_LIMIT;
	}
	public String getSHEET_DEAL_DEP() {
		return SHEET_DEAL_DEP;
	}
	public void setSHEET_DEAL_DEP(String sHEET_DEAL_DEP) {
		SHEET_DEAL_DEP = sHEET_DEAL_DEP;
	}
	public String getSPECIAL_FIELD23() {
		return SPECIAL_FIELD23;
	}
	public void setSPECIAL_FIELD23(String sPECIAL_FIELD23) {
		SPECIAL_FIELD23 = sPECIAL_FIELD23;
	}
	public Date getINSERT_TIME() {
		return INSERT_TIME;
	}
	public void setINSERT_TIME(Date iNSERT_TIME) {
		INSERT_TIME = iNSERT_TIME;
	}
	public Long getALARM_ACT_COUNT() {
		return ALARM_ACT_COUNT;
	}
	public void setALARM_ACT_COUNT(Long aLARM_ACT_COUNT) {
		ALARM_ACT_COUNT = aLARM_ACT_COUNT;
	}
	public Long getRESOURCE_STATUS() {
		return RESOURCE_STATUS;
	}
	public void setRESOURCE_STATUS(Long rESOURCE_STATUS) {
		RESOURCE_STATUS = rESOURCE_STATUS;
	}
	public Long getCITY_ID() {
		return CITY_ID;
	}
	public void setCITY_ID(Long cITY_ID) {
		CITY_ID = cITY_ID;
	}
	public String getNMS_NAME() {
		return NMS_NAME;
	}
	public void setNMS_NAME(String nMS_NAME) {
		NMS_NAME = nMS_NAME;
	}
	public String getCIRCUIT_ID() {
		return CIRCUIT_ID;
	}
	public void setCIRCUIT_ID(String cIRCUIT_ID) {
		CIRCUIT_ID = cIRCUIT_ID;
	}
	public Long getALARM_TITLE() {
		return ALARM_TITLE;
	}
	public void setALARM_TITLE(Long aLARM_TITLE) {
		ALARM_TITLE = aLARM_TITLE;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ACK_FLAG == null) ? 0 : ACK_FLAG.hashCode());
		result = prime * result
				+ ((ACK_TIME == null) ? 0 : ACK_TIME.hashCode());
		result = prime * result
				+ ((ACK_USER == null) ? 0 : ACK_USER.hashCode());
		result = prime * result
				+ ((ACTIVE_STATUS == null) ? 0 : ACTIVE_STATUS.hashCode());
		result = prime * result
				+ ((AC_RULE_NAME == null) ? 0 : AC_RULE_NAME.hashCode());
		result = prime * result
				+ ((ALARM_ACT_COUNT == null) ? 0 : ALARM_ACT_COUNT.hashCode());
		result = prime * result
				+ ((ALARM_ID == null) ? 0 : ALARM_ID.hashCode());
		result = prime * result
				+ ((ALARM_NE_STATUS == null) ? 0 : ALARM_NE_STATUS.hashCode());
		result = prime * result
				+ ((ALARM_ORIGIN == null) ? 0 : ALARM_ORIGIN.hashCode());
		result = prime * result
				+ ((ALARM_REASON == null) ? 0 : ALARM_REASON.hashCode());
		result = prime
				* result
				+ ((ALARM_RESOURCE_STATUS == null) ? 0 : ALARM_RESOURCE_STATUS
						.hashCode());
		result = prime * result
				+ ((ALARM_SOURCE == null) ? 0 : ALARM_SOURCE.hashCode());
		result = prime * result
				+ ((ALARM_TEXT == null) ? 0 : ALARM_TEXT.hashCode());
		result = prime * result
				+ ((ALARM_TITLE == null) ? 0 : ALARM_TITLE.hashCode());
		result = prime * result
				+ ((CANCEL_TIME == null) ? 0 : CANCEL_TIME.hashCode());
		result = prime * result
				+ ((CHANNEL_TYPE == null) ? 0 : CHANNEL_TYPE.hashCode());
		result = prime * result
				+ ((CIRCUIT_ID == null) ? 0 : CIRCUIT_ID.hashCode());
		result = prime * result
				+ ((CIRCUIT_NO == null) ? 0 : CIRCUIT_NO.hashCode());
		result = prime * result + ((CITY_ID == null) ? 0 : CITY_ID.hashCode());
		result = prime * result
				+ ((CITY_NAME == null) ? 0 : CITY_NAME.hashCode());
		result = prime * result + ((C_FP0 == null) ? 0 : C_FP0.hashCode());
		result = prime * result + ((C_FP1 == null) ? 0 : C_FP1.hashCode());
		result = prime * result + ((C_FP2 == null) ? 0 : C_FP2.hashCode());
		result = prime * result + ((C_FP3 == null) ? 0 : C_FP3.hashCode());
		result = prime * result
				+ ((DEADLINE_TIME == null) ? 0 : DEADLINE_TIME.hashCode());
		result = prime * result
				+ ((DEAL_TIME_LIMIT == null) ? 0 : DEAL_TIME_LIMIT.hashCode());
		result = prime * result
				+ ((EFFECT_NE == null) ? 0 : EFFECT_NE.hashCode());
		result = prime * result
				+ ((EFFECT_SERVICE == null) ? 0 : EFFECT_SERVICE.hashCode());
		result = prime * result
				+ ((EQP_ALIAS == null) ? 0 : EQP_ALIAS.hashCode());
		result = prime * result
				+ ((EQP_INT_ID == null) ? 0 : EQP_INT_ID.hashCode());
		result = prime * result
				+ ((EQP_LABEL == null) ? 0 : EQP_LABEL.hashCode());
		result = prime
				* result
				+ ((EQP_OBJECT_CLASS == null) ? 0 : EQP_OBJECT_CLASS.hashCode());
		result = prime * result
				+ ((EQP_VERSION == null) ? 0 : EQP_VERSION.hashCode());
		result = prime * result
				+ ((EVENT_TIME == null) ? 0 : EVENT_TIME.hashCode());
		result = prime * result
				+ ((EXTRA_ID1 == null) ? 0 : EXTRA_ID1.hashCode());
		result = prime * result
				+ ((EXTRA_ID3 == null) ? 0 : EXTRA_ID3.hashCode());
		result = prime * result
				+ ((EXTRA_STRING3 == null) ? 0 : EXTRA_STRING3.hashCode());
		result = prime * result
				+ ((FAILED_REASON == null) ? 0 : FAILED_REASON.hashCode());
		result = prime * result + ((FP0 == null) ? 0 : FP0.hashCode());
		result = prime * result + ((FP1 == null) ? 0 : FP1.hashCode());
		result = prime * result + ((FP2 == null) ? 0 : FP2.hashCode());
		result = prime * result + ((FP3 == null) ? 0 : FP3.hashCode());
		result = prime * result
				+ ((GCSS_CLIENT == null) ? 0 : GCSS_CLIENT.hashCode());
		result = prime
				* result
				+ ((GCSS_CLIENT_GRADE == null) ? 0 : GCSS_CLIENT_GRADE
						.hashCode());
		result = prime
				* result
				+ ((GCSS_CLIENT_GRADE_MGT == null) ? 0 : GCSS_CLIENT_GRADE_MGT
						.hashCode());
		result = prime
				* result
				+ ((GCSS_CLIENT_LEVEL == null) ? 0 : GCSS_CLIENT_LEVEL
						.hashCode());
		result = prime
				* result
				+ ((GCSS_CLIENT_NAME == null) ? 0 : GCSS_CLIENT_NAME.hashCode());
		result = prime * result
				+ ((GCSS_CLIENT_NUM == null) ? 0 : GCSS_CLIENT_NUM.hashCode());
		result = prime * result
				+ ((GCSS_SERVICE == null) ? 0 : GCSS_SERVICE.hashCode());
		result = prime
				* result
				+ ((GCSS_SERVICE_LEVEL == null) ? 0 : GCSS_SERVICE_LEVEL
						.hashCode());
		result = prime
				* result
				+ ((GCSS_SERVICE_NUM == null) ? 0 : GCSS_SERVICE_NUM.hashCode());
		result = prime
				* result
				+ ((GCSS_SERVICE_TYPE == null) ? 0 : GCSS_SERVICE_TYPE
						.hashCode());
		result = prime * result
				+ ((HAS_CHILD == null) ? 0 : HAS_CHILD.hashCode());
		result = prime
				* result
				+ ((INFECT_CUSTOMER_COUNT == null) ? 0 : INFECT_CUSTOMER_COUNT
						.hashCode());
		result = prime * result
				+ ((INSERT_TIME == null) ? 0 : INSERT_TIME.hashCode());
		result = prime * result + ((INT_ID == null) ? 0 : INT_ID.hashCode());
		result = prime * result + ((IS_ROOT == null) ? 0 : IS_ROOT.hashCode());
		result = prime * result
				+ ((LAYER_RETE == null) ? 0 : LAYER_RETE.hashCode());
		result = prime
				* result
				+ ((LOGIC_ALARM_TYPE == null) ? 0 : LOGIC_ALARM_TYPE.hashCode());
		result = prime
				* result
				+ ((LOGIC_SUB_ALARM_TYPE == null) ? 0 : LOGIC_SUB_ALARM_TYPE
						.hashCode());
		result = prime * result
				+ ((NETWORK_TYPE == null) ? 0 : NETWORK_TYPE.hashCode());
		result = prime * result
				+ ((NE_ADMIN_STATUS == null) ? 0 : NE_ADMIN_STATUS.hashCode());
		result = prime * result
				+ ((NE_ALIAS == null) ? 0 : NE_ALIAS.hashCode());
		result = prime * result + ((NE_IP == null) ? 0 : NE_IP.hashCode());
		result = prime * result
				+ ((NE_LABEL == null) ? 0 : NE_LABEL.hashCode());
		result = prime * result
				+ ((NE_LOCATION == null) ? 0 : NE_LOCATION.hashCode());
		result = prime * result
				+ ((NE_STATUS == null) ? 0 : NE_STATUS.hashCode());
		result = prime * result
				+ ((NMS_NAME == null) ? 0 : NMS_NAME.hashCode());
		result = prime * result
				+ ((OBJECT_CLASS == null) ? 0 : OBJECT_CLASS.hashCode());
		result = prime * result
				+ ((OBJECT_LEVEL == null) ? 0 : OBJECT_LEVEL.hashCode());
		result = prime * result
				+ ((OMC_ALARM_ID == null) ? 0 : OMC_ALARM_ID.hashCode());
		result = prime * result + ((OMC_ID == null) ? 0 : OMC_ID.hashCode());
		result = prime * result
				+ ((ORG_SEVERITY == null) ? 0 : ORG_SEVERITY.hashCode());
		result = prime * result
				+ ((ORG_TYPE == null) ? 0 : ORG_TYPE.hashCode());
		result = prime * result
				+ ((PREPROCESS_FLAG == null) ? 0 : PREPROCESS_FLAG.hashCode());
		result = prime
				* result
				+ ((PREPROCESS_MANNER == null) ? 0 : PREPROCESS_MANNER
						.hashCode());
		result = prime * result
				+ ((PROBABLE_CAUSE == null) ? 0 : PROBABLE_CAUSE.hashCode());
		result = prime
				* result
				+ ((PROBABLE_CAUSE_TXT == null) ? 0 : PROBABLE_CAUSE_TXT
						.hashCode());
		result = prime
				* result
				+ ((PROFESSIONAL_TYPE == null) ? 0 : PROFESSIONAL_TYPE
						.hashCode());
		result = prime * result
				+ ((PROJ_OA_FILE_ID == null) ? 0 : PROJ_OA_FILE_ID.hashCode());
		result = prime * result
				+ ((PROVINCE_NAME == null) ? 0 : PROVINCE_NAME.hashCode());
		result = prime * result
				+ ((REC_VERSION == null) ? 0 : REC_VERSION.hashCode());
		result = prime
				* result
				+ ((REDEFINE_SEVERITY == null) ? 0 : REDEFINE_SEVERITY
						.hashCode());
		result = prime * result
				+ ((REDEFINE_TYPE == null) ? 0 : REDEFINE_TYPE.hashCode());
		result = prime * result
				+ ((REGION_ID == null) ? 0 : REGION_ID.hashCode());
		result = prime * result
				+ ((REGION_NAME == null) ? 0 : REGION_NAME.hashCode());
		result = prime * result
				+ ((RELATION_TYPE == null) ? 0 : RELATION_TYPE.hashCode());
		result = prime * result
				+ ((REMARK_EXIST == null) ? 0 : REMARK_EXIST.hashCode());
		result = prime
				* result
				+ ((REMOTE_EQP_LABEL == null) ? 0 : REMOTE_EQP_LABEL.hashCode());
		result = prime
				* result
				+ ((REMOTE_PROJ_SUB_STATUS == null) ? 0
						: REMOTE_PROJ_SUB_STATUS.hashCode());
		result = prime
				* result
				+ ((REMOTE_RESOURCE_STATUS == null) ? 0
						: REMOTE_RESOURCE_STATUS.hashCode());
		result = prime * result
				+ ((RESOURCE_STATUS == null) ? 0 : RESOURCE_STATUS.hashCode());
		result = prime * result
				+ ((SEND_JT_FLAG == null) ? 0 : SEND_JT_FLAG.hashCode());
		result = prime * result
				+ ((SHEET_DEAL_DEP == null) ? 0 : SHEET_DEAL_DEP.hashCode());
		result = prime * result
				+ ((SHEET_NO == null) ? 0 : SHEET_NO.hashCode());
		result = prime
				* result
				+ ((SHEET_SEND_STATUS == null) ? 0 : SHEET_SEND_STATUS
						.hashCode());
		result = prime * result
				+ ((SHEET_STATUS == null) ? 0 : SHEET_STATUS.hashCode());
		result = prime * result + ((SITE_NO == null) ? 0 : SITE_NO.hashCode());
		result = prime * result
				+ ((SPECIAL_FIELD23 == null) ? 0 : SPECIAL_FIELD23.hashCode());
		result = prime
				* result
				+ ((STANDARD_ALARM_ID == null) ? 0 : STANDARD_ALARM_ID
						.hashCode());
		result = prime
				* result
				+ ((STANDARD_ALARM_NAME == null) ? 0 : STANDARD_ALARM_NAME
						.hashCode());
		result = prime * result
				+ ((STANDARD_FLAG == null) ? 0 : STANDARD_FLAG.hashCode());
		result = prime * result
				+ ((SUB_ALARM_TYPE == null) ? 0 : SUB_ALARM_TYPE.hashCode());
		result = prime * result
				+ ((TIME_STAMP == null) ? 0 : TIME_STAMP.hashCode());
		result = prime * result
				+ ((TITLE_TEXT == null) ? 0 : TITLE_TEXT.hashCode());
		result = prime * result
				+ ((TMSC_CAT == null) ? 0 : TMSC_CAT.hashCode());
		result = prime * result
				+ ((UNSEND_REASON == null) ? 0 : UNSEND_REASON.hashCode());
		result = prime * result
				+ ((VENDOR_ID == null) ? 0 : VENDOR_ID.hashCode());
		result = prime * result
				+ ((VENDOR_SEVERITY == null) ? 0 : VENDOR_SEVERITY.hashCode());
		result = prime * result
				+ ((VENDOR_TYPE == null) ? 0 : VENDOR_TYPE.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlarmWL other = (AlarmWL) obj;
		if (ACK_FLAG == null) {
			if (other.ACK_FLAG != null)
				return false;
		} else if (!ACK_FLAG.equals(other.ACK_FLAG))
			return false;
		if (ACK_TIME == null) {
			if (other.ACK_TIME != null)
				return false;
		} else if (!ACK_TIME.equals(other.ACK_TIME))
			return false;
		if (ACK_USER == null) {
			if (other.ACK_USER != null)
				return false;
		} else if (!ACK_USER.equals(other.ACK_USER))
			return false;
		if (ACTIVE_STATUS == null) {
			if (other.ACTIVE_STATUS != null)
				return false;
		} else if (!ACTIVE_STATUS.equals(other.ACTIVE_STATUS))
			return false;
		if (AC_RULE_NAME == null) {
			if (other.AC_RULE_NAME != null)
				return false;
		} else if (!AC_RULE_NAME.equals(other.AC_RULE_NAME))
			return false;
		if (ALARM_ACT_COUNT == null) {
			if (other.ALARM_ACT_COUNT != null)
				return false;
		} else if (!ALARM_ACT_COUNT.equals(other.ALARM_ACT_COUNT))
			return false;
		if (ALARM_ID == null) {
			if (other.ALARM_ID != null)
				return false;
		} else if (!ALARM_ID.equals(other.ALARM_ID))
			return false;
		if (ALARM_NE_STATUS == null) {
			if (other.ALARM_NE_STATUS != null)
				return false;
		} else if (!ALARM_NE_STATUS.equals(other.ALARM_NE_STATUS))
			return false;
		if (ALARM_ORIGIN == null) {
			if (other.ALARM_ORIGIN != null)
				return false;
		} else if (!ALARM_ORIGIN.equals(other.ALARM_ORIGIN))
			return false;
		if (ALARM_REASON == null) {
			if (other.ALARM_REASON != null)
				return false;
		} else if (!ALARM_REASON.equals(other.ALARM_REASON))
			return false;
		if (ALARM_RESOURCE_STATUS == null) {
			if (other.ALARM_RESOURCE_STATUS != null)
				return false;
		} else if (!ALARM_RESOURCE_STATUS.equals(other.ALARM_RESOURCE_STATUS))
			return false;
		if (ALARM_SOURCE == null) {
			if (other.ALARM_SOURCE != null)
				return false;
		} else if (!ALARM_SOURCE.equals(other.ALARM_SOURCE))
			return false;
		if (ALARM_TEXT == null) {
			if (other.ALARM_TEXT != null)
				return false;
		} else if (!ALARM_TEXT.equals(other.ALARM_TEXT))
			return false;
		if (ALARM_TITLE == null) {
			if (other.ALARM_TITLE != null)
				return false;
		} else if (!ALARM_TITLE.equals(other.ALARM_TITLE))
			return false;
		if (CANCEL_TIME == null) {
			if (other.CANCEL_TIME != null)
				return false;
		} else if (!CANCEL_TIME.equals(other.CANCEL_TIME))
			return false;
		if (CHANNEL_TYPE == null) {
			if (other.CHANNEL_TYPE != null)
				return false;
		} else if (!CHANNEL_TYPE.equals(other.CHANNEL_TYPE))
			return false;
		if (CIRCUIT_ID == null) {
			if (other.CIRCUIT_ID != null)
				return false;
		} else if (!CIRCUIT_ID.equals(other.CIRCUIT_ID))
			return false;
		if (CIRCUIT_NO == null) {
			if (other.CIRCUIT_NO != null)
				return false;
		} else if (!CIRCUIT_NO.equals(other.CIRCUIT_NO))
			return false;
		if (CITY_ID == null) {
			if (other.CITY_ID != null)
				return false;
		} else if (!CITY_ID.equals(other.CITY_ID))
			return false;
		if (CITY_NAME == null) {
			if (other.CITY_NAME != null)
				return false;
		} else if (!CITY_NAME.equals(other.CITY_NAME))
			return false;
		if (C_FP0 == null) {
			if (other.C_FP0 != null)
				return false;
		} else if (!C_FP0.equals(other.C_FP0))
			return false;
		if (C_FP1 == null) {
			if (other.C_FP1 != null)
				return false;
		} else if (!C_FP1.equals(other.C_FP1))
			return false;
		if (C_FP2 == null) {
			if (other.C_FP2 != null)
				return false;
		} else if (!C_FP2.equals(other.C_FP2))
			return false;
		if (C_FP3 == null) {
			if (other.C_FP3 != null)
				return false;
		} else if (!C_FP3.equals(other.C_FP3))
			return false;
		if (DEADLINE_TIME == null) {
			if (other.DEADLINE_TIME != null)
				return false;
		} else if (!DEADLINE_TIME.equals(other.DEADLINE_TIME))
			return false;
		if (DEAL_TIME_LIMIT == null) {
			if (other.DEAL_TIME_LIMIT != null)
				return false;
		} else if (!DEAL_TIME_LIMIT.equals(other.DEAL_TIME_LIMIT))
			return false;
		if (EFFECT_NE == null) {
			if (other.EFFECT_NE != null)
				return false;
		} else if (!EFFECT_NE.equals(other.EFFECT_NE))
			return false;
		if (EFFECT_SERVICE == null) {
			if (other.EFFECT_SERVICE != null)
				return false;
		} else if (!EFFECT_SERVICE.equals(other.EFFECT_SERVICE))
			return false;
		if (EQP_ALIAS == null) {
			if (other.EQP_ALIAS != null)
				return false;
		} else if (!EQP_ALIAS.equals(other.EQP_ALIAS))
			return false;
		if (EQP_INT_ID == null) {
			if (other.EQP_INT_ID != null)
				return false;
		} else if (!EQP_INT_ID.equals(other.EQP_INT_ID))
			return false;
		if (EQP_LABEL == null) {
			if (other.EQP_LABEL != null)
				return false;
		} else if (!EQP_LABEL.equals(other.EQP_LABEL))
			return false;
		if (EQP_OBJECT_CLASS == null) {
			if (other.EQP_OBJECT_CLASS != null)
				return false;
		} else if (!EQP_OBJECT_CLASS.equals(other.EQP_OBJECT_CLASS))
			return false;
		if (EQP_VERSION == null) {
			if (other.EQP_VERSION != null)
				return false;
		} else if (!EQP_VERSION.equals(other.EQP_VERSION))
			return false;
		if (EVENT_TIME == null) {
			if (other.EVENT_TIME != null)
				return false;
		} else if (!EVENT_TIME.equals(other.EVENT_TIME))
			return false;
		if (EXTRA_ID1 == null) {
			if (other.EXTRA_ID1 != null)
				return false;
		} else if (!EXTRA_ID1.equals(other.EXTRA_ID1))
			return false;
		if (EXTRA_ID3 == null) {
			if (other.EXTRA_ID3 != null)
				return false;
		} else if (!EXTRA_ID3.equals(other.EXTRA_ID3))
			return false;
		if (EXTRA_STRING3 == null) {
			if (other.EXTRA_STRING3 != null)
				return false;
		} else if (!EXTRA_STRING3.equals(other.EXTRA_STRING3))
			return false;
		if (FAILED_REASON == null) {
			if (other.FAILED_REASON != null)
				return false;
		} else if (!FAILED_REASON.equals(other.FAILED_REASON))
			return false;
		if (FP0 == null) {
			if (other.FP0 != null)
				return false;
		} else if (!FP0.equals(other.FP0))
			return false;
		if (FP1 == null) {
			if (other.FP1 != null)
				return false;
		} else if (!FP1.equals(other.FP1))
			return false;
		if (FP2 == null) {
			if (other.FP2 != null)
				return false;
		} else if (!FP2.equals(other.FP2))
			return false;
		if (FP3 == null) {
			if (other.FP3 != null)
				return false;
		} else if (!FP3.equals(other.FP3))
			return false;
		if (GCSS_CLIENT == null) {
			if (other.GCSS_CLIENT != null)
				return false;
		} else if (!GCSS_CLIENT.equals(other.GCSS_CLIENT))
			return false;
		if (GCSS_CLIENT_GRADE == null) {
			if (other.GCSS_CLIENT_GRADE != null)
				return false;
		} else if (!GCSS_CLIENT_GRADE.equals(other.GCSS_CLIENT_GRADE))
			return false;
		if (GCSS_CLIENT_GRADE_MGT == null) {
			if (other.GCSS_CLIENT_GRADE_MGT != null)
				return false;
		} else if (!GCSS_CLIENT_GRADE_MGT.equals(other.GCSS_CLIENT_GRADE_MGT))
			return false;
		if (GCSS_CLIENT_LEVEL == null) {
			if (other.GCSS_CLIENT_LEVEL != null)
				return false;
		} else if (!GCSS_CLIENT_LEVEL.equals(other.GCSS_CLIENT_LEVEL))
			return false;
		if (GCSS_CLIENT_NAME == null) {
			if (other.GCSS_CLIENT_NAME != null)
				return false;
		} else if (!GCSS_CLIENT_NAME.equals(other.GCSS_CLIENT_NAME))
			return false;
		if (GCSS_CLIENT_NUM == null) {
			if (other.GCSS_CLIENT_NUM != null)
				return false;
		} else if (!GCSS_CLIENT_NUM.equals(other.GCSS_CLIENT_NUM))
			return false;
		if (GCSS_SERVICE == null) {
			if (other.GCSS_SERVICE != null)
				return false;
		} else if (!GCSS_SERVICE.equals(other.GCSS_SERVICE))
			return false;
		if (GCSS_SERVICE_LEVEL == null) {
			if (other.GCSS_SERVICE_LEVEL != null)
				return false;
		} else if (!GCSS_SERVICE_LEVEL.equals(other.GCSS_SERVICE_LEVEL))
			return false;
		if (GCSS_SERVICE_NUM == null) {
			if (other.GCSS_SERVICE_NUM != null)
				return false;
		} else if (!GCSS_SERVICE_NUM.equals(other.GCSS_SERVICE_NUM))
			return false;
		if (GCSS_SERVICE_TYPE == null) {
			if (other.GCSS_SERVICE_TYPE != null)
				return false;
		} else if (!GCSS_SERVICE_TYPE.equals(other.GCSS_SERVICE_TYPE))
			return false;
		if (HAS_CHILD == null) {
			if (other.HAS_CHILD != null)
				return false;
		} else if (!HAS_CHILD.equals(other.HAS_CHILD))
			return false;
		if (INFECT_CUSTOMER_COUNT == null) {
			if (other.INFECT_CUSTOMER_COUNT != null)
				return false;
		} else if (!INFECT_CUSTOMER_COUNT.equals(other.INFECT_CUSTOMER_COUNT))
			return false;
		if (INSERT_TIME == null) {
			if (other.INSERT_TIME != null)
				return false;
		} else if (!INSERT_TIME.equals(other.INSERT_TIME))
			return false;
		if (INT_ID == null) {
			if (other.INT_ID != null)
				return false;
		} else if (!INT_ID.equals(other.INT_ID))
			return false;
		if (IS_ROOT == null) {
			if (other.IS_ROOT != null)
				return false;
		} else if (!IS_ROOT.equals(other.IS_ROOT))
			return false;
		if (LAYER_RETE == null) {
			if (other.LAYER_RETE != null)
				return false;
		} else if (!LAYER_RETE.equals(other.LAYER_RETE))
			return false;
		if (LOGIC_ALARM_TYPE == null) {
			if (other.LOGIC_ALARM_TYPE != null)
				return false;
		} else if (!LOGIC_ALARM_TYPE.equals(other.LOGIC_ALARM_TYPE))
			return false;
		if (LOGIC_SUB_ALARM_TYPE == null) {
			if (other.LOGIC_SUB_ALARM_TYPE != null)
				return false;
		} else if (!LOGIC_SUB_ALARM_TYPE.equals(other.LOGIC_SUB_ALARM_TYPE))
			return false;
		if (NETWORK_TYPE == null) {
			if (other.NETWORK_TYPE != null)
				return false;
		} else if (!NETWORK_TYPE.equals(other.NETWORK_TYPE))
			return false;
		if (NE_ADMIN_STATUS == null) {
			if (other.NE_ADMIN_STATUS != null)
				return false;
		} else if (!NE_ADMIN_STATUS.equals(other.NE_ADMIN_STATUS))
			return false;
		if (NE_ALIAS == null) {
			if (other.NE_ALIAS != null)
				return false;
		} else if (!NE_ALIAS.equals(other.NE_ALIAS))
			return false;
		if (NE_IP == null) {
			if (other.NE_IP != null)
				return false;
		} else if (!NE_IP.equals(other.NE_IP))
			return false;
		if (NE_LABEL == null) {
			if (other.NE_LABEL != null)
				return false;
		} else if (!NE_LABEL.equals(other.NE_LABEL))
			return false;
		if (NE_LOCATION == null) {
			if (other.NE_LOCATION != null)
				return false;
		} else if (!NE_LOCATION.equals(other.NE_LOCATION))
			return false;
		if (NE_STATUS == null) {
			if (other.NE_STATUS != null)
				return false;
		} else if (!NE_STATUS.equals(other.NE_STATUS))
			return false;
		if (NMS_NAME == null) {
			if (other.NMS_NAME != null)
				return false;
		} else if (!NMS_NAME.equals(other.NMS_NAME))
			return false;
		if (OBJECT_CLASS == null) {
			if (other.OBJECT_CLASS != null)
				return false;
		} else if (!OBJECT_CLASS.equals(other.OBJECT_CLASS))
			return false;
		if (OBJECT_LEVEL == null) {
			if (other.OBJECT_LEVEL != null)
				return false;
		} else if (!OBJECT_LEVEL.equals(other.OBJECT_LEVEL))
			return false;
		if (OMC_ALARM_ID == null) {
			if (other.OMC_ALARM_ID != null)
				return false;
		} else if (!OMC_ALARM_ID.equals(other.OMC_ALARM_ID))
			return false;
		if (OMC_ID == null) {
			if (other.OMC_ID != null)
				return false;
		} else if (!OMC_ID.equals(other.OMC_ID))
			return false;
		if (ORG_SEVERITY == null) {
			if (other.ORG_SEVERITY != null)
				return false;
		} else if (!ORG_SEVERITY.equals(other.ORG_SEVERITY))
			return false;
		if (ORG_TYPE == null) {
			if (other.ORG_TYPE != null)
				return false;
		} else if (!ORG_TYPE.equals(other.ORG_TYPE))
			return false;
		if (PREPROCESS_FLAG == null) {
			if (other.PREPROCESS_FLAG != null)
				return false;
		} else if (!PREPROCESS_FLAG.equals(other.PREPROCESS_FLAG))
			return false;
		if (PREPROCESS_MANNER == null) {
			if (other.PREPROCESS_MANNER != null)
				return false;
		} else if (!PREPROCESS_MANNER.equals(other.PREPROCESS_MANNER))
			return false;
		if (PROBABLE_CAUSE == null) {
			if (other.PROBABLE_CAUSE != null)
				return false;
		} else if (!PROBABLE_CAUSE.equals(other.PROBABLE_CAUSE))
			return false;
		if (PROBABLE_CAUSE_TXT == null) {
			if (other.PROBABLE_CAUSE_TXT != null)
				return false;
		} else if (!PROBABLE_CAUSE_TXT.equals(other.PROBABLE_CAUSE_TXT))
			return false;
		if (PROFESSIONAL_TYPE == null) {
			if (other.PROFESSIONAL_TYPE != null)
				return false;
		} else if (!PROFESSIONAL_TYPE.equals(other.PROFESSIONAL_TYPE))
			return false;
		if (PROJ_OA_FILE_ID == null) {
			if (other.PROJ_OA_FILE_ID != null)
				return false;
		} else if (!PROJ_OA_FILE_ID.equals(other.PROJ_OA_FILE_ID))
			return false;
		if (PROVINCE_NAME == null) {
			if (other.PROVINCE_NAME != null)
				return false;
		} else if (!PROVINCE_NAME.equals(other.PROVINCE_NAME))
			return false;
		if (REC_VERSION == null) {
			if (other.REC_VERSION != null)
				return false;
		} else if (!REC_VERSION.equals(other.REC_VERSION))
			return false;
		if (REDEFINE_SEVERITY == null) {
			if (other.REDEFINE_SEVERITY != null)
				return false;
		} else if (!REDEFINE_SEVERITY.equals(other.REDEFINE_SEVERITY))
			return false;
		if (REDEFINE_TYPE == null) {
			if (other.REDEFINE_TYPE != null)
				return false;
		} else if (!REDEFINE_TYPE.equals(other.REDEFINE_TYPE))
			return false;
		if (REGION_ID == null) {
			if (other.REGION_ID != null)
				return false;
		} else if (!REGION_ID.equals(other.REGION_ID))
			return false;
		if (REGION_NAME == null) {
			if (other.REGION_NAME != null)
				return false;
		} else if (!REGION_NAME.equals(other.REGION_NAME))
			return false;
		if (RELATION_TYPE == null) {
			if (other.RELATION_TYPE != null)
				return false;
		} else if (!RELATION_TYPE.equals(other.RELATION_TYPE))
			return false;
		if (REMARK_EXIST == null) {
			if (other.REMARK_EXIST != null)
				return false;
		} else if (!REMARK_EXIST.equals(other.REMARK_EXIST))
			return false;
		if (REMOTE_EQP_LABEL == null) {
			if (other.REMOTE_EQP_LABEL != null)
				return false;
		} else if (!REMOTE_EQP_LABEL.equals(other.REMOTE_EQP_LABEL))
			return false;
		if (REMOTE_PROJ_SUB_STATUS == null) {
			if (other.REMOTE_PROJ_SUB_STATUS != null)
				return false;
		} else if (!REMOTE_PROJ_SUB_STATUS.equals(other.REMOTE_PROJ_SUB_STATUS))
			return false;
		if (REMOTE_RESOURCE_STATUS == null) {
			if (other.REMOTE_RESOURCE_STATUS != null)
				return false;
		} else if (!REMOTE_RESOURCE_STATUS.equals(other.REMOTE_RESOURCE_STATUS))
			return false;
		if (RESOURCE_STATUS == null) {
			if (other.RESOURCE_STATUS != null)
				return false;
		} else if (!RESOURCE_STATUS.equals(other.RESOURCE_STATUS))
			return false;
		if (SEND_JT_FLAG == null) {
			if (other.SEND_JT_FLAG != null)
				return false;
		} else if (!SEND_JT_FLAG.equals(other.SEND_JT_FLAG))
			return false;
		if (SHEET_DEAL_DEP == null) {
			if (other.SHEET_DEAL_DEP != null)
				return false;
		} else if (!SHEET_DEAL_DEP.equals(other.SHEET_DEAL_DEP))
			return false;
		if (SHEET_NO == null) {
			if (other.SHEET_NO != null)
				return false;
		} else if (!SHEET_NO.equals(other.SHEET_NO))
			return false;
		if (SHEET_SEND_STATUS == null) {
			if (other.SHEET_SEND_STATUS != null)
				return false;
		} else if (!SHEET_SEND_STATUS.equals(other.SHEET_SEND_STATUS))
			return false;
		if (SHEET_STATUS == null) {
			if (other.SHEET_STATUS != null)
				return false;
		} else if (!SHEET_STATUS.equals(other.SHEET_STATUS))
			return false;
		if (SITE_NO == null) {
			if (other.SITE_NO != null)
				return false;
		} else if (!SITE_NO.equals(other.SITE_NO))
			return false;
		if (SPECIAL_FIELD23 == null) {
			if (other.SPECIAL_FIELD23 != null)
				return false;
		} else if (!SPECIAL_FIELD23.equals(other.SPECIAL_FIELD23))
			return false;
		if (STANDARD_ALARM_ID == null) {
			if (other.STANDARD_ALARM_ID != null)
				return false;
		} else if (!STANDARD_ALARM_ID.equals(other.STANDARD_ALARM_ID))
			return false;
		if (STANDARD_ALARM_NAME == null) {
			if (other.STANDARD_ALARM_NAME != null)
				return false;
		} else if (!STANDARD_ALARM_NAME.equals(other.STANDARD_ALARM_NAME))
			return false;
		if (STANDARD_FLAG == null) {
			if (other.STANDARD_FLAG != null)
				return false;
		} else if (!STANDARD_FLAG.equals(other.STANDARD_FLAG))
			return false;
		if (SUB_ALARM_TYPE == null) {
			if (other.SUB_ALARM_TYPE != null)
				return false;
		} else if (!SUB_ALARM_TYPE.equals(other.SUB_ALARM_TYPE))
			return false;
		if (TIME_STAMP == null) {
			if (other.TIME_STAMP != null)
				return false;
		} else if (!TIME_STAMP.equals(other.TIME_STAMP))
			return false;
		if (TITLE_TEXT == null) {
			if (other.TITLE_TEXT != null)
				return false;
		} else if (!TITLE_TEXT.equals(other.TITLE_TEXT))
			return false;
		if (TMSC_CAT == null) {
			if (other.TMSC_CAT != null)
				return false;
		} else if (!TMSC_CAT.equals(other.TMSC_CAT))
			return false;
		if (UNSEND_REASON == null) {
			if (other.UNSEND_REASON != null)
				return false;
		} else if (!UNSEND_REASON.equals(other.UNSEND_REASON))
			return false;
		if (VENDOR_ID == null) {
			if (other.VENDOR_ID != null)
				return false;
		} else if (!VENDOR_ID.equals(other.VENDOR_ID))
			return false;
		if (VENDOR_SEVERITY == null) {
			if (other.VENDOR_SEVERITY != null)
				return false;
		} else if (!VENDOR_SEVERITY.equals(other.VENDOR_SEVERITY))
			return false;
		if (VENDOR_TYPE == null) {
			if (other.VENDOR_TYPE != null)
				return false;
		} else if (!VENDOR_TYPE.equals(other.VENDOR_TYPE))
			return false;
		return true;
	}
	
	
}
