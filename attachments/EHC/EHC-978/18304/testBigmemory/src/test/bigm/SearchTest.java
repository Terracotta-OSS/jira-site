package test.bigm;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.search.Attribute;
import net.sf.ehcache.search.Query;
import net.sf.ehcache.search.Result;
import net.sf.ehcache.search.Results;
import net.sf.ehcache.search.aggregator.Aggregators;
import net.sf.ehcache.search.expression.Criteria;

import org.apache.log4j.Logger;

import bean.wl.AlarmWL;

public class SearchTest {
	private static Logger logger = Logger.getLogger(SearchTest.class);
	/**
	 * 执行超过1分钟.txt
select  count(a.alarm_id) as count 
from tfa_alarm_act a , tfa_alarm_act_txt t 
where a.active_status=1 and a.alarm_id=t.alarm_id and ( (((t.alarm_text like '%mhytest0101001mhy%') )  ) ) ;
	 */

	void query1(Cache cache) {
		Attribute<Long> active_status = cache.getSearchAttribute("ACTIVE_STATUS");
		Attribute<String> alarm_text = cache.getSearchAttribute("ALARM_TEXT");
		Criteria c1 = active_status.eq(0L).and(alarm_text.ilike("*呼叫拥塞率超门限告警*"));
		Query query = cache.createQuery();
//		query.includeAttribute(alarm_text);
		long start = System.currentTimeMillis();
		query.addCriteria(c1);
		query.includeAggregator(Aggregators.count());
		Results rs = query.execute();
		if(rs.size()>0) {
			int count = (Integer) rs.all().get(0).getAggregatorResults().get(0);
			logger.info("query1 count = " + count + ", costs = " + (System.currentTimeMillis() - start) + "ms");
		} else {
			logger.info("query1 count = 0, costs = " + (System.currentTimeMillis() - start) + "ms");
		}
//		for(Result r : rs.all()) {
//			logger.info(r.getAttribute(alarm_text));
//		}
	}
	
	void query1TopN(Cache cache) {
		Attribute<Long> active_status = cache.getSearchAttribute("ACTIVE_STATUS");
		Attribute<String> alarm_text = cache.getSearchAttribute("ALARM_TEXT");
		Criteria c1 = active_status.eq(0L).and(alarm_text.ilike("*呼叫拥塞率超门限告警*"));
		Query query = cache.createQuery();
		query.maxResults(1000);
		query.includeValues();
		long start = System.currentTimeMillis();
		query.addCriteria(c1);
		Results rs = query.execute();
		if(rs.size()>0) {
			List<AlarmWL> list = new ArrayList<AlarmWL>();
			for(Result r : rs.all()) {
				list.add((AlarmWL) r.getValue());
			}
			logger.info("query1TopN return " + list.size() + ", costs = " + (System.currentTimeMillis() - start) + "ms");
		} else {
			logger.info("query1TopN return 0, costs = " + (System.currentTimeMillis() - start) + "ms");
		}
	}
	
	public static void main(String[] args) {
		long st = System.currentTimeMillis();

		System.setProperty("java.io.tmpdir", "D:\\Temp\\b0");
		EhcacheManger ehcacheManger = new EhcacheManger("1024m");
		String path = "E:\\nosql\\filter\\serdata";
		int fileCount = 1;
		
		Cache mostIndexsCache = ehcacheManger.getMostIndexesCache();
		File[] fileNames = new File(path).listFiles();
		int i = 0;
		if(mostIndexsCache.getSize()==0) {	
			LoadData loadData = new LoadData();
			for(File file : fileNames) {
				String fileName = file.getAbsolutePath();
				loadData.loadData(mostIndexsCache,fileName);
				i++;
				logger.info(fileName + ", cache size = " + mostIndexsCache.getSize() + "\n");
				if(fileCount > 0 && i==fileCount) {
					break;
				}
			}
			logger.info("load cost = " + (System.currentTimeMillis() - st) + " ms");
		} else {
			logger.info("recover cost = " + (System.currentTimeMillis() - st) + " ms, cache.size = " + mostIndexsCache.getSize());
		} 
		SearchTest searchTest = new SearchTest();
		for(int j=0; j<3;j++) {			
			searchTest.query1(mostIndexsCache);
		}
		for(int j=0; j<3;j++) {			
			searchTest.query1TopN(mostIndexsCache);
		}
		ehcacheManger.shutdonw();
	}
}
