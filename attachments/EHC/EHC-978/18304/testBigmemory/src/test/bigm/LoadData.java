package test.bigm;

import org.apache.log4j.Logger;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import bean.wl.AlarmWL;
import bean.wl.ProtostuffTest;

public class LoadData {
	static Logger logger = Logger.getLogger(LoadData.class);
	void loadData(Cache cache,String fileName) {
		ProtostuffTest protostuffTest = new  ProtostuffTest();
		AlarmWL[] deserWL = protostuffTest.deserWL(fileName);
		
		long st = System.currentTimeMillis();
		for(AlarmWL alarm : deserWL) {
			cache.put(new Element(alarm.getALARM_ID(), alarm));
		}
		logger.info("load data cost = " + (System.currentTimeMillis() -st) + "ms"
				+" per " + 1000*deserWL.length/(System.currentTimeMillis() -st));
	}
	
	public static void main(String[] args) {
		EhcacheManger ehcacheManger = new EhcacheManger("100m");
		Cache mostIndexsCache = ehcacheManger.getMostIndexesCache();
		String fileName = "E:/nosql/filter/serdataalarmwl50000.dat";
		new LoadData().loadData(mostIndexsCache,fileName);
	}
}
