package test.bigm;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;
import net.sf.ehcache.config.SearchAttribute;
import net.sf.ehcache.config.Searchable;
import net.sf.ehcache.config.PersistenceConfiguration.Strategy;

import org.apache.log4j.Logger;

import bean.wl.AlarmWL;

import com.esotericsoftware.reflectasm.FieldAccess;

public class EhcacheManger {
	
	private Logger logger = Logger.getLogger(EhcacheManger.class);
	
	public static int MAX_ELEMENTS_IN_MEMORY = 5000;
	public static String MAX_MEMORY_OFF_HEAP ;
	public static String CACHE_NAME ="alarmcache";
	
	private Cache cache;
	private CacheManager cm;
	private CacheConfiguration ccf;
	FieldAccess fieldAccess;
	String[] fieldNames;

	public EhcacheManger(String max_memory_off_heap) {
		EhcacheManger.MAX_MEMORY_OFF_HEAP = max_memory_off_heap;
		fieldAccess = FieldAccess.get(AlarmWL.class);
		fieldNames = fieldAccess.getFieldNames();
	}
	
	
	public Cache getMostIndexesCache() {
		cm = CacheManager.create();
		Cache cache2 = cm.getCache(CACHE_NAME);
		if(cache2!=null && cache2.getSize()>0) {
			return cache2;
		}
		ccf = new CacheConfiguration();
		ccf.persistence(new PersistenceConfiguration().strategy(Strategy.LOCALRESTARTABLE).synchronousWrites(false));
		ccf.setName(CACHE_NAME);
		ccf.setMaxEntriesLocalHeap(MAX_ELEMENTS_IN_MEMORY);
		ccf.setOverflowToOffHeap(Boolean.TRUE);
		ccf.setMaxMemoryOffHeap(MAX_MEMORY_OFF_HEAP);
		Searchable searchable = new Searchable();
		
		for(String fieldName : fieldNames) {			
			searchable.addSearchAttribute(new SearchAttribute().name(fieldName));
		}
		ccf.addSearchable(searchable);
		cache = new Cache(ccf);
		cm.addCache(cache);
		logger.info("Printing Ehchache configuration:");
		logger.info(cm.getActiveConfigurationText(CACHE_NAME));
		return cache;
	}
	
	public void shutdonw() {
		cm.shutdown();
	}
}
