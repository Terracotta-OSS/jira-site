package test;

/**
 * ReaderFactory
 * A non serializable class
 */
public class ReaderFactory {
}
