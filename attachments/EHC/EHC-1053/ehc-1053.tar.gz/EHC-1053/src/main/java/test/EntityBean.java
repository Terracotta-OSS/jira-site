package test;

import java.io.Serializable;

/**
 * EntityBean
 */
public class EntityBean implements Serializable {

	private static final long serialVersionUID = -3289049540217053566L;

	private Integer id;

	private String name;

	protected transient ReaderFactory readerFactory = new ReaderFactory();

  public EntityBean(Integer id, String name) {
    this.id = id;
    this.name = name;
  }
}