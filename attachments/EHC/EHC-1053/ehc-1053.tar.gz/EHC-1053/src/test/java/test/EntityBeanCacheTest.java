package test;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * EntityBeanCacheTest
 */
public class EntityBeanCacheTest {

  private CacheManager cacheManager;

  @Before
  public void setUp() {
    cacheManager = CacheManager.create();
  }

  @After
  public void tearDown() {
    cacheManager.shutdown();
  }

  @Test
  public void addEntityBeanToCache() throws Exception {
    EntityBean test = new EntityBean(100, "test");
    Cache cache = cacheManager.getCache("DATA_SERVICE");
    cache.put(new Element(100, test));

    // Dirty way to make sure persistence of entry is performed, as it is async
    TimeUnit.SECONDS.sleep(1);

    assertThat(cache.getStatistics().getDiskStoreObjectCount(), is(1L));
  }
}
