package net.dahanne.osgi.ehcache.consumer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
public class Activator implements BundleActivator {

	//if a slf4j implementation was deployed, it would make sense to use slf4j
//	Logger logger = LoggerFactory.getLogger(Activator.class);
	
	public void start(BundleContext context) throws Exception {
		System.out.println(String.format("Start - %s", this.getClass().getName()));
//		logger.info(String.format("Start - %s", this.getClass().getName()));
		
		Demo demo = new Demo();
		try {
			demo.go();
		} catch (Exception e) {
//			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public void stop(BundleContext context) throws Exception {
		System.out.println(String.format("Stop - %s", this.getClass().getName()));
//		logger.info(String.format("Stop - %s", this.getClass().getName()));
	}
}
