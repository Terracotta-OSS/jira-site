import java.util.Properties;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.extension.CacheExtension;
import net.sf.ehcache.extension.CacheExtensionFactory;

/**
 * A <code>CacheExtensionFactory</code> for {@link ExpiryThreadCacheExtension}.
 *
 */
public class ExpiryThreadCacheExtensionFactory extends CacheExtensionFactory {

	// ----------------------------------------------------------------------
	// Public methods
	// ----------------------------------------------------------------------

	/**
	 * Creates a new cache extension for the given cache.
	 *
	 * @param cache
	 *            a cache.
	 */
	public CacheExtension createCacheExtension(Ehcache cache,
			Properties properties) {

		return new ExpiryThreadCacheExtension(cache);
	}
}
