package org.tc;
import org.apache.log4j.Logger;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.TerracottaConfiguration;

public class ProgramaticallyCreateEhcache {

	private static final Logger	LOG	= Logger.getLogger(ProgramaticallyCreateEhcache.class);
	CacheManager 	cacheManager;
	Cache 			cache;
	
	public ProgramaticallyCreateEhcache(){

	    Configuration ehcacheConfig = new Configuration();
	    ehcacheConfig.setDefaultCacheConfiguration(createDefaultCacheConfiguration());
	    ehcacheConfig.setName("cachetest");
	    cacheManager = new CacheManager(ehcacheConfig);
	    
	    CacheConfiguration  cacheConfiguration  = new CacheConfiguration("userCache", 1000);
	    cacheConfiguration.setStatistics(false);
	    LOG.info("setting statistics: " + cacheConfiguration.getStatistics());
	    
	    TerracottaConfiguration   tcConfiguration = new TerracottaConfiguration();
	    tcConfiguration.setClustered(true);
	    cacheConfiguration.addTerracotta(tcConfiguration);
		
	    cache 	= new Cache(cacheConfiguration);
	    
		LOG.info("Creating cache ...");
		cacheManager.addCache(cache);
		LOG.info("Created cache ... " + cache.getName());
		LOG.info("cache statistics enabled: " + cache.isStatisticsEnabled());
	}

	private static CacheConfiguration createDefaultCacheConfiguration() {
		    CacheConfiguration result = new CacheConfiguration("default",0);
		    result.setEternal(false);
		    result.setTimeToIdleSeconds(1200);
		    result.setTimeToLiveSeconds(3600);
		    result.setOverflowToDisk(false);
		    result.setDiskPersistent(false);
		    result.setMaxElementsOnDisk(10000);
		    result.setMemoryStoreEvictionPolicy("LRU");
		    return result;
		  }
	
	public static void main(String[] args) throws InterruptedException {
		new ProgramaticallyCreateEhcache();
		Thread.sleep(100000);
	}

}
